// VDB Web 프런트엔드 (빌드 도구 없음, 바닐라 JS)
// 사용자 데이터는 항상 textContent 로 넣는다 (innerHTML 금지 → XSS 방지)
"use strict";

const PAGE_SIZE = 20;
const MAX_FILE_BYTES = 20 * 1024 * 1024;

const SAMPLE_DOCS = [
  { id: "sample-pet", document: "고양이가 소파 위에서 낮잠을 자고 있다.", metadata: { category: "생활" } },
  { id: "sample-rate", document: "한국은행이 물가 상승을 억제하기 위해 기준금리를 인상했다.", metadata: { category: "경제", year: 2024 } },
  { id: "sample-space", document: "누리호가 인공위성을 지구 저궤도에 올려놓았다.", metadata: { category: "과학", year: 2023 } },
  { id: "sample-food", document: "김치찌개는 돼지고기와 묵은지를 넣고 끓인다.", metadata: { category: "생활" } },
  { id: "sample-vdb", document: "벡터 데이터베이스는 임베딩 간 유사도로 문서를 검색한다.", metadata: { category: "IT", year: 2025 } },
  { id: "sample-stock", document: "반도체 수출 호조로 코스피 지수가 사상 최고치를 기록했다.", metadata: { category: "경제", year: 2025 } },
];

const state = {
  status: null,
  collections: [],
  current: null,          // 선택된 컬렉션 이름
  tab: "search",
  browse: { offset: 0, total: 0, contains: "", selected: new Set() },
  importFile: null,
  editing: null,          // 수정 중인 문서 id
};

// ---------- 유틸 ----------

const $ = (sel) => document.querySelector(sel);

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? "" : value);
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

async function api(method, path, body) {
  const options = { method, headers: {} };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(`/api${path}`, options);
  } catch (e) {
    throw new Error("웹 서버에 연결할 수 없습니다.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = data?.response?.message || data?.detail || `${res.status} ${res.statusText}`;
    throw new Error(message);
  }
  return data;
}

const enc = encodeURIComponent;
const colPath = (suffix = "") => `/collections/${enc(state.current)}${suffix}`;

function toast(message, isError = false) {
  const node = el("div", { class: `toast${isError ? " toast-error" : ""}`, text: message });
  $("#toasts").append(node);
  setTimeout(() => node.remove(), isError ? 7000 : 3500);
}

async function withBusy(button, fn) {
  const label = button.textContent;
  button.disabled = true;
  button.replaceChildren(el("span", { class: "spinner" }), " 처리 중");
  try {
    return await fn();
  } catch (e) {
    toast(e.message, true);
  } finally {
    button.disabled = false;
    button.textContent = label;
  }
}

function confirmDialog(title, message, okLabel = "삭제") {
  const dlg = $("#dlg-confirm");
  $("#confirm-title").textContent = title;
  $("#confirm-message").textContent = message;
  dlg.querySelector("button[value=ok]").textContent = okLabel;
  dlg.returnValue = "";
  dlg.showModal();
  return new Promise((resolve) => dlg.addEventListener("close", () => resolve(dlg.returnValue === "ok"), { once: true }));
}

function parseJsonObject(text, label) {
  if (!text.trim()) return null;
  let value;
  try {
    value = JSON.parse(text);
  } catch {
    throw new Error(`${label}: JSON 형식이 올바르지 않습니다.`);
  }
  if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error(`${label}: { } 객체여야 합니다.`);
  return value;
}

// "12" → 12, "true" → true, 그 외 문자열
function inferValue(raw) {
  const text = raw.trim();
  if (text === "true") return true;
  if (text === "false") return false;
  if (text !== "" && !Number.isNaN(Number(text))) return Number(text);
  return text;
}

function metaChips(metadata) {
  if (!metadata || !Object.keys(metadata).length) return null;
  return el("div", { class: "chips" },
    Object.entries(metadata).map(([k, v]) => el("span", { class: "chip" }, `${k}: `, el("b", { text: String(v) }))));
}

// ---------- 상태 / 컬렉션 ----------

async function loadStatus() {
  const pill = $("#status-pill");
  try {
    state.status = await api("GET", "/status");
    const s = state.status;
    pill.className = `pill ${s.chroma_ok ? "pill-ok" : "pill-bad"}`;
    pill.textContent = s.chroma_ok ? `Chroma 연결됨 · v${s.chroma_version}` : "Chroma 연결 안 됨";
    pill.title = `${s.chroma_mode} · ${s.chroma_target}`;
  } catch (e) {
    pill.className = "pill pill-bad";
    pill.textContent = "웹 서버 오류";
    pill.title = e.message;
  }
}

async function loadCollections() {
  try {
    const data = await api("GET", "/collections");
    state.collections = data.collections;
  } catch (e) {
    state.collections = [];
    toast(`컬렉션 목록을 불러오지 못했습니다: ${e.message}`, true);
  }
  if (state.current && !state.collections.some((c) => c.name === state.current)) state.current = null;
  renderCollections();
  renderWorkspace();
}

function currentInfo() {
  return state.collections.find((c) => c.name === state.current) || null;
}

function renderCollections() {
  const list = $("#collection-list");
  list.replaceChildren(...state.collections.map((c) =>
    el("li", {
      class: c.name === state.current ? "active" : "",
      title: c.description || c.name,
      onclick: () => selectCollection(c.name),
    },
    el("span", { class: "c-name", text: c.name }),
    el("span", { class: "c-sub", text: `${c.count.toLocaleString()}건 · ${c.model}` }))));
  $("#collection-empty").classList.toggle("hidden", state.collections.length > 0);
}

function renderWorkspace() {
  const info = currentInfo();
  $("#welcome").classList.toggle("hidden", !!info);
  $("#workspace").classList.toggle("hidden", !info);
  if (!info) return;
  $("#col-name").textContent = info.name;
  $("#col-meta").replaceChildren(
    el("span", { class: "tag" }, "문서 ", el("b", { text: info.count.toLocaleString() })),
    el("span", { class: "tag" }, "모델 ", el("b", { text: info.model })),
    el("span", { class: "tag" }, "거리 ", el("b", { text: info.space })));
  $("#col-desc").textContent = info.description || "";
}

function selectCollection(name) {
  if (state.current !== name) {
    state.current = name;
    state.browse = { offset: 0, total: 0, contains: "", selected: new Set() };
    $("#browse-contains").value = "";
    $("#search-results").replaceChildren();
    $("#search-info").textContent = "";
    history.replaceState(null, "", `#${enc(name)}`);
  }
  renderCollections();
  renderWorkspace();
  showTab(state.tab);
}

async function refreshCurrentInfo() {
  await loadCollections();
}

function showTab(tab) {
  state.tab = tab;
  document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  for (const name of ["search", "add", "browse"]) $(`#panel-${name}`).classList.toggle("hidden", name !== tab);
  if (tab === "search") {
    if (!$("#search-results").children.length) renderSearchEmptyHint();
    $("#search-query").focus();
  }
  if (tab === "browse") loadDocuments();
}

// ---------- 컬렉션 생성 / 삭제 ----------

function openCreateCollection() {
  $("#collection-form").reset();
  if (state.status?.default_model) $("#new-col-model").value = state.status.default_model;
  $("#dlg-collection").showModal();
  $("#new-col-name").focus();
}

async function submitCreateCollection(event) {
  event.preventDefault();
  const form = event.target;
  if (!form.reportValidity()) return;
  const body = {
    name: $("#new-col-name").value.trim(),
    model: $("#new-col-model").value,
    space: $("#new-col-space").value,
    description: $("#new-col-desc").value.trim(),
  };
  await withBusy(form.querySelector("button[type=submit]"), async () => {
    await api("POST", "/collections", body);
    $("#dlg-collection").close();
    toast(`컬렉션 '${body.name}' 을(를) 만들었습니다.`);
    state.current = body.name;
    state.tab = "add";
    await loadCollections();
    selectCollection(body.name);
  });
}

async function deleteCollection() {
  const info = currentInfo();
  if (!info) return;
  const ok = await confirmDialog("컬렉션 삭제",
    `'${info.name}' 컬렉션과 문서 ${info.count.toLocaleString()}건이 모두 삭제됩니다. 되돌릴 수 없습니다.`);
  if (!ok) return;
  try {
    await api("DELETE", colPath());
    toast(`'${info.name}' 을(를) 삭제했습니다.`);
    state.current = null;
    history.replaceState(null, "", location.pathname);
    await loadCollections();
  } catch (e) {
    toast(e.message, true);
  }
}

// ---------- 검색 ----------

function renderSearchEmptyHint() {
  const info = currentInfo();
  if (!info || info.count > 0) return;
  $("#search-results").replaceChildren(el("li", { class: "empty" },
    "아직 문서가 없습니다.",
    el("br"),
    el("button", { class: "btn btn-ghost btn-sm", text: "예제 문서 6건 넣기", onclick: (e) => addSamples(e.target) }),
    " ",
    el("button", { class: "btn btn-ghost btn-sm", text: "데이터 등록하러 가기", onclick: () => showTab("add") })));
}

async function addSamples(button) {
  await withBusy(button, async () => {
    const res = await api("POST", colPath("/documents"), { documents: SAMPLE_DOCS });
    toast(`예제 문서 ${res.count}건을 넣었습니다. '이자율 정책' 을 검색해 보세요.`);
    $("#search-results").replaceChildren();
    $("#search-query").value = "이자율 정책";
    await refreshCurrentInfo();
  });
}

async function submitSearch(event) {
  event.preventDefault();
  const query = $("#search-query").value.trim();
  if (!query) return;
  let where;
  try {
    where = parseJsonObject($("#search-where").value, "메타데이터 조건");
  } catch (e) {
    toast(e.message, true);
    return;
  }
  const body = { query, n_results: Number($("#search-k").value), where, contains: $("#search-contains").value.trim() || null };
  const button = event.target.querySelector("button[type=submit]");
  const info = $("#search-info");
  info.replaceChildren(el("span", { class: "spinner" }), " 검색 중… (모델을 처음 쓰면 로딩에 시간이 걸립니다)");
  await withBusy(button, async () => {
    try {
      const res = await api("POST", colPath("/search"), body);
      renderSearchResults(res);
    } catch (e) {
      info.textContent = "";
      throw e;
    }
  });
}

function renderSearchResults(res) {
  $("#search-info").textContent = `${res.hits.length}건 · ${res.elapsed_ms} ms · ${res.model} / ${res.space}`
    + (res.space === "cosine" ? " · 유사도 = 1 − 거리" : " · 거리가 작을수록 가까움");
  const list = $("#search-results");
  if (!res.hits.length) {
    list.replaceChildren(el("li", { class: "empty", text: "조건에 맞는 문서가 없습니다." }));
    renderSearchEmptyHint();
    return;
  }
  list.replaceChildren(...res.hits.map((hit) => {
    const score = hit.similarity !== null && hit.similarity !== undefined
      ? el("span", { class: "score", title: `distance ${hit.distance.toFixed(4)}` },
        el("span", { class: "score-bar" }, el("span", { style: `width:${Math.max(0, Math.min(1, hit.similarity)) * 100}%` })),
        `유사도 ${hit.similarity.toFixed(3)}`)
      : el("span", { class: "score", text: `거리 ${hit.distance.toFixed(4)}` });
    return el("li", { class: "hit" },
      el("div", { class: "hit-top" },
        el("span", { class: "hit-rank", text: hit.rank }),
        score,
        el("span", { class: "hit-id", text: hit.id })),
      el("div", { class: "hit-doc", text: hit.document ?? "" }),
      metaChips(hit.metadata));
  }));
}

// ---------- 등록: 직접 입력 ----------

function addMetaRow(key = "", value = "") {
  const row = el("div", { class: "meta-row" },
    el("input", { type: "text", placeholder: "키 (예: category)", value: key, "data-role": "key" }),
    el("input", { type: "text", placeholder: "값 (예: 경제)", value: value, "data-role": "value" }),
    el("button", { type: "button", class: "btn-icon", title: "삭제", text: "✕", onclick: () => row.remove() }));
  $("#add-meta-rows").append(row);
}

function collectMetaRows() {
  const metadata = {};
  for (const row of document.querySelectorAll("#add-meta-rows .meta-row")) {
    const key = row.querySelector("[data-role=key]").value.trim();
    const raw = row.querySelector("[data-role=value]").value;
    if (!key && !raw.trim()) continue;
    if (!key) throw new Error("메타데이터 키가 비어 있습니다.");
    if (key in metadata) throw new Error(`메타데이터 키가 중복됩니다: ${key}`);
    metadata[key] = inferValue(raw);
  }
  return metadata;
}

async function submitAdd(event) {
  event.preventDefault();
  let metadata;
  try {
    metadata = collectMetaRows();
  } catch (e) {
    toast(e.message, true);
    return;
  }
  const doc = { document: $("#add-document").value.trim(), metadata };
  const id = $("#add-id").value.trim();
  if (id) doc.id = id;
  if (!doc.document) return;
  await withBusy(event.target.querySelector("button[type=submit]"), async () => {
    const res = await api("POST", colPath("/documents"), { documents: [doc] });
    toast(`등록했습니다 (ID: ${res.ids[0]})`);
    $("#add-document").value = "";
    $("#add-id").value = "";
    $("#search-results").replaceChildren();
    await refreshCurrentInfo();
  });
}

// ---------- 등록: 파일 ----------

function guessFormat(fileName) {
  const ext = fileName.split(".").pop().toLowerCase();
  if (ext === "csv") return "csv";
  if (ext === "jsonl" || ext === "json") return "jsonl";
  if (ext === "html" || ext === "htm") return "html";
  return "text";
}

function setImportFile(file) {
  if (!file) return;
  if (file.size > MAX_FILE_BYTES) {
    toast(`파일이 너무 큽니다 (최대 ${MAX_FILE_BYTES / 1024 / 1024}MB).`, true);
    return;
  }
  state.importFile = file;
  $("#import-format").value = guessFormat(file.name);
  updateChunkOptions();
  $("#dropzone").classList.add("has-file");
  $("#dropzone-text").replaceChildren(el("b", { text: file.name }), el("br"),
    el("span", { class: "muted small", text: `${(file.size / 1024).toFixed(1)} KB · 다른 파일을 고르려면 클릭` }));
}

function updateChunkOptions() {
  $("#chunk-options").classList.toggle("hidden", !["text", "html"].includes($("#import-format").value));
}

async function submitImport(event) {
  event.preventDefault();
  const file = state.importFile;
  if (!file) {
    toast("업로드할 파일을 선택하세요.", true);
    return;
  }
  let metadata;
  try {
    metadata = parseJsonObject($("#import-metadata").value, "공통 메타데이터") || {};
  } catch (e) {
    toast(e.message, true);
    return;
  }
  await withBusy($("#btn-import"), async () => {
    const content = await file.text();
    const body = {
      format: $("#import-format").value,
      content,
      source_name: file.name,
      chunk_size: Number($("#import-chunk-size").value),
      chunk_overlap: Number($("#import-chunk-overlap").value),
      metadata,
    };
    const res = await api("POST", colPath("/documents/import"), body);
    toast(`'${file.name}' 에서 문서 ${res.count.toLocaleString()}건을 등록했습니다.`);
    state.importFile = null;
    $("#import-file").value = "";
    $("#dropzone").classList.remove("has-file");
    $("#dropzone-text").replaceChildren("파일을 끌어다 놓거나 ", el("u", { text: "클릭해서 선택" }), el("br"),
      el("span", { class: "muted small", text: "txt · md · csv · jsonl · html (UTF-8)" }));
    $("#search-results").replaceChildren();
    await refreshCurrentInfo();
  });
}

// ---------- 등록: 웹페이지 링크 ----------

async function submitUrl(event) {
  event.preventDefault();
  const url = $("#url-input").value.trim();
  if (!url) return;
  let metadata;
  try {
    metadata = parseJsonObject($("#url-metadata").value, "공통 메타데이터") || {};
  } catch (e) {
    toast(e.message, true);
    return;
  }
  const body = {
    url,
    chunk_size: Number($("#url-chunk-size").value),
    chunk_overlap: Number($("#url-chunk-overlap").value),
    metadata,
    replace: $("#url-replace").checked,
  };
  const result = $("#url-result");
  result.classList.add("hidden");
  await withBusy($("#btn-url"), async () => {
    const res = await api("POST", colPath("/documents/url"), body);
    result.replaceChildren(
      el("b", { text: res.title }), el("br"),
      el("span", { class: "muted", text: res.url }), el("br"),
      `본문 ${res.chars.toLocaleString()}자 → 청크 ${res.count}건 등록`,
      res.replaced ? ` (기존 ${res.replaced}건 교체)` : "");
    result.classList.remove("hidden");
    toast(`웹페이지에서 ${res.count}건을 등록했습니다.`);
    $("#url-input").value = "";
    $("#url-replace").checked = false;
    $("#search-results").replaceChildren();
    await refreshCurrentInfo();
  });
}

// ---------- 조회 ----------

async function loadDocuments() {
  if (!state.current) return;
  const b = state.browse;
  const params = new URLSearchParams({ offset: b.offset, limit: PAGE_SIZE });
  if (b.contains) params.set("contains", b.contains);
  const body = $("#browse-body");
  body.replaceChildren(el("tr", {}, el("td", { colspan: 5, class: "muted" }, el("span", { class: "spinner" }), " 불러오는 중…")));
  try {
    const res = await api("GET", colPath(`/documents?${params}`));
    b.total = res.total;
    b.selected.clear();
    renderDocuments(res.documents);
  } catch (e) {
    body.replaceChildren(el("tr", {}, el("td", { colspan: 5, class: "muted", text: e.message })));
  }
}

function renderDocuments(docs) {
  const b = state.browse;
  const body = $("#browse-body");
  if (!docs.length) {
    body.replaceChildren(el("tr", {}, el("td", { colspan: 5, class: "muted",
      text: b.contains ? "조건에 맞는 문서가 없습니다." : "문서가 없습니다. '데이터 등록' 탭에서 추가하세요." })));
  } else {
    body.replaceChildren(...docs.map((doc) => el("tr", {},
      el("td", {}, el("input", { type: "checkbox", "aria-label": "선택", onchange: (e) => toggleSelect(doc.id, e.target.checked) })),
      el("td", { text: doc.id }),
      el("td", { class: "doc", text: doc.document ?? "" }),
      el("td", {}, metaChips(doc.metadata)),
      el("td", {},
        el("button", { class: "btn-icon", text: "수정", onclick: () => openEdit(doc) }),
        el("button", { class: "btn-icon", text: "삭제", onclick: () => deleteDocument(doc.id) })))));
  }
  const from = b.total ? b.offset + 1 : 0;
  const to = Math.min(b.offset + PAGE_SIZE, b.total);
  $("#page-info").textContent = `${from.toLocaleString()}–${to.toLocaleString()} / ${b.total.toLocaleString()}건`;
  $("#btn-prev").disabled = b.offset === 0;
  $("#btn-next").disabled = b.offset + PAGE_SIZE >= b.total;
  $("#browse-check-all").checked = false;
  updateSelectedButton();
}

function toggleSelect(id, checked) {
  if (checked) state.browse.selected.add(id);
  else state.browse.selected.delete(id);
  updateSelectedButton();
}

function updateSelectedButton() {
  const n = state.browse.selected.size;
  const button = $("#btn-delete-selected");
  button.disabled = n === 0;
  button.textContent = n ? `선택 삭제 (${n})` : "선택 삭제";
}

async function deleteDocument(id) {
  if (!(await confirmDialog("문서 삭제", `'${id}' 문서를 삭제합니다.`))) return;
  try {
    await api("DELETE", colPath(`/documents/${enc(id)}`));
    toast("삭제했습니다.");
    await afterBrowseChange();
  } catch (e) {
    toast(e.message, true);
  }
}

async function deleteSelected() {
  const ids = [...state.browse.selected];
  if (!ids.length || !(await confirmDialog("문서 삭제", `선택한 문서 ${ids.length}건을 삭제합니다.`))) return;
  try {
    const res = await api("POST", colPath("/documents/delete"), { ids });
    toast(`${res.count}건을 삭제했습니다.`);
    await afterBrowseChange();
  } catch (e) {
    toast(e.message, true);
  }
}

async function afterBrowseChange() {
  await refreshCurrentInfo();
  const b = state.browse;
  const total = currentInfo()?.count ?? 0;
  if (b.offset >= total && b.offset > 0) b.offset = Math.max(0, b.offset - PAGE_SIZE);
  $("#search-results").replaceChildren();
  await loadDocuments();
}

function openEdit(doc) {
  state.editing = doc.id;
  $("#edit-id").textContent = doc.id;
  $("#edit-document").value = doc.document ?? "";
  $("#edit-metadata").value = doc.metadata ? JSON.stringify(doc.metadata, null, 2) : "{}";
  $("#dlg-edit").showModal();
}

async function submitEdit(event) {
  event.preventDefault();
  let metadata;
  try {
    metadata = parseJsonObject($("#edit-metadata").value, "메타데이터") || {};
  } catch (e) {
    toast(e.message, true);
    return;
  }
  const body = { document: $("#edit-document").value.trim(), metadata };
  if (!body.document) return;
  await withBusy(event.target.querySelector("button[type=submit]"), async () => {
    await api("PUT", colPath(`/documents/${enc(state.editing)}`), body);
    $("#dlg-edit").close();
    toast("저장했습니다.");
    $("#search-results").replaceChildren();
    await loadDocuments();
  });
}

// ---------- 이벤트 연결 ----------

function bindEvents() {
  $("#btn-new-collection").addEventListener("click", openCreateCollection);
  $("#btn-welcome-create").addEventListener("click", openCreateCollection);
  $("#collection-form").addEventListener("submit", submitCreateCollection);
  $("#btn-delete-collection").addEventListener("click", deleteCollection);
  document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => b.closest("dialog").close()));
  document.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));

  $("#search-form").addEventListener("submit", submitSearch);

  $("#add-form").addEventListener("submit", submitAdd);
  $("#btn-add-meta-row").addEventListener("click", () => addMetaRow());

  $("#import-form").addEventListener("submit", submitImport);
  $("#url-form").addEventListener("submit", submitUrl);
  $("#import-file").addEventListener("change", (e) => setImportFile(e.target.files[0]));
  $("#import-format").addEventListener("change", updateChunkOptions);
  const dropzone = $("#dropzone");
  dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("drag"); });
  dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag"));
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("drag");
    setImportFile(e.dataTransfer.files[0]);
  });

  $("#browse-form").addEventListener("submit", (e) => {
    e.preventDefault();
    state.browse.contains = $("#browse-contains").value.trim();
    state.browse.offset = 0;
    loadDocuments();
  });
  $("#btn-prev").addEventListener("click", () => { state.browse.offset = Math.max(0, state.browse.offset - PAGE_SIZE); loadDocuments(); });
  $("#btn-next").addEventListener("click", () => { state.browse.offset += PAGE_SIZE; loadDocuments(); });
  $("#btn-delete-selected").addEventListener("click", deleteSelected);
  $("#browse-check-all").addEventListener("change", (e) => {
    document.querySelectorAll("#browse-body input[type=checkbox]").forEach((box) => {
      box.checked = e.target.checked;
      box.dispatchEvent(new Event("change"));
    });
  });
  $("#edit-form").addEventListener("submit", submitEdit);
}

async function init() {
  bindEvents();
  addMetaRow();
  updateChunkOptions();
  await loadStatus();
  const fromHash = decodeURIComponent(location.hash.slice(1));
  if (fromHash) state.current = fromHash;
  await loadCollections();
  if (state.current) selectCollection(state.current);
  setInterval(loadStatus, 30000);
}

init();
