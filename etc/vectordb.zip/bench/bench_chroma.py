"""Chroma HNSW 벤치마크: 적재 처리량, Recall@k, 지연시간(p50/p95/p99), QPS.

정답(ground truth)은 numpy 브루트포스(정확 검색)로 계산한다.

주의(chromadb 1.5.9 에서 확인): collection.modify() 로 ef_search 를 바꾸면 설정값은 저장되지만
이미 메모리에 로드된 HNSW 인덱스에는 반영되지 않는다(클라이언트/서버 재시작 후 반영).
  - embedded 모드: ef_search 값마다 클라이언트를 다시 열어 측정(재적재 없음)
  - http 모드    : 서버를 재시작할 수 없으므로 ef_search 값마다 컬렉션을 새로 만들어 측정(재적재)

예)
  python bench/bench_chroma.py                                # 기본: 50k x 128d, 임베디드
  python bench/bench_chroma.py -n 200000 --dim 384 --ef-search 32 64 128 256
  python bench/bench_chroma.py --mode http --port 8000        # 실행 중인 서버 대상
"""
from __future__ import annotations

import argparse
import json
import shutil
import statistics
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

import chromadb
import numpy as np
from chromadb.api.shared_system_client import SharedSystemClient
from chromadb.config import Settings

ROOT = Path(__file__).resolve().parents[1]


def make_data(kind: str, n: int, nq: int, dim: int, seed: int):
    rng = np.random.default_rng(seed)
    if kind == "clustered":  # 실제 임베딩과 비슷하게 군집 구조를 가진 데이터
        centers = rng.standard_normal((max(16, n // 1000), dim)).astype(np.float32)
        def sample(m):
            idx = rng.integers(0, len(centers), m)
            return centers[idx] + 0.35 * rng.standard_normal((m, dim)).astype(np.float32)
        base, queries = sample(n), sample(nq)
    else:  # 균등 랜덤(고차원에서 ANN 에 가장 불리한 최악 조건)
        base = rng.standard_normal((n, dim)).astype(np.float32)
        queries = rng.standard_normal((nq, dim)).astype(np.float32)
    base /= np.linalg.norm(base, axis=1, keepdims=True)
    queries /= np.linalg.norm(queries, axis=1, keepdims=True)
    return base, queries


def ground_truth(base: np.ndarray, queries: np.ndarray, k: int, chunk: int = 256) -> np.ndarray:
    out = []
    for i in range(0, len(queries), chunk):
        sims = queries[i:i + chunk] @ base.T
        top = np.argpartition(-sims, k, axis=1)[:, :k]
        order = np.argsort(-np.take_along_axis(sims, top, axis=1), axis=1)
        out.append(np.take_along_axis(top, order, axis=1))
    return np.vstack(out)


def pct(values, p):
    return float(np.percentile(values, p))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-n", type=int, default=50_000, help="적재 벡터 수")
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--queries", type=int, default=500)
    ap.add_argument("-k", type=int, default=10)
    ap.add_argument("--data", choices=["clustered", "random"], default="clustered")
    ap.add_argument("--space", choices=["cosine", "l2", "ip"], default="cosine")
    ap.add_argument("--max-neighbors", type=int, default=16, help="HNSW M")
    ap.add_argument("--ef-construction", type=int, default=100)
    ap.add_argument("--ef-search", type=int, nargs="+", default=[10, 20, 50, 100, 200])
    ap.add_argument("--batch", type=int, default=5000)
    ap.add_argument("--mode", choices=["embedded", "http"], default="embedded")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    print(f"[data] {args.data} n={args.n:,} dim={args.dim} queries={args.queries} k={args.k}")
    base, queries = make_data(args.data, args.n, args.queries, args.dim, args.seed)
    t = time.perf_counter()
    gt = ground_truth(base, queries, args.k)
    print(f"[gt]   brute-force ground truth {time.perf_counter() - t:.2f}s")

    def settings() -> Settings:  # HttpClient 가 Settings 객체를 변경하므로 매번 새로 생성
        return Settings(anonymized_telemetry=False)

    tmpdir = tempfile.mkdtemp(prefix="chroma-bench-") if args.mode == "embedded" else None

    def open_client():
        if args.mode == "http":
            return chromadb.HttpClient(host=args.host, port=args.port, settings=settings())
        SharedSystemClient.clear_system_cache()
        return chromadb.PersistentClient(path=tmpdir, settings=settings())

    run_id = f"bench-{datetime.now():%Y%m%d%H%M%S}"
    created: list[str] = []

    def build(name: str, ef: int) -> float:
        client = open_client()
        col = client.create_collection(name, embedding_function=None, configuration={"hnsw": {
            "space": args.space, "max_neighbors": args.max_neighbors,
            "ef_construction": args.ef_construction, "ef_search": ef}})
        created.append(name)
        batch = min(args.batch, client.get_max_batch_size())
        t = time.perf_counter()
        for i in range(0, args.n, batch):
            j = min(i + batch, args.n)
            col.add(ids=[str(x) for x in range(i, j)], embeddings=base[i:j])
        sec = time.perf_counter() - t
        print(f"[load] {name}: {args.n:,} vectors in {sec:.1f}s ({args.n / sec:,.0f} vec/s, batch={batch})")
        return sec

    def measure(col, ef: int) -> dict:
        for q in queries[:20]:  # 워밍업
            col.query(query_embeddings=[q], n_results=args.k, include=[])
        lat, hits = [], 0
        for qi, q in enumerate(queries):
            t0 = time.perf_counter()
            r = col.query(query_embeddings=[q], n_results=args.k, include=[])
            lat.append((time.perf_counter() - t0) * 1000)
            hits += len({int(x) for x in r["ids"][0]} & set(gt[qi].tolist()))
        actual = col.configuration["hnsw"]["ef_search"]
        assert actual == ef, f"ef_search mismatch: expected {ef}, got {actual}"
        return {"ef_search": ef, "recall": hits / (len(queries) * args.k),
                "p50_ms": pct(lat, 50), "p95_ms": pct(lat, 95), "p99_ms": pct(lat, 99),
                "qps": 1000 / statistics.mean(lat)}

    rows, ingest = [], []
    try:
        if args.mode == "embedded":
            ingest.append(build(run_id, args.ef_search[0]))
        header = f"{'ef_search':>9} | {'recall@' + str(args.k):>9} | {'p50 ms':>7} | {'p95 ms':>7} | {'p99 ms':>7} | {'QPS':>7}"
        lines = []
        for ef in args.ef_search:
            if args.mode == "embedded":
                open_client().get_collection(run_id).modify(configuration={"hnsw": {"ef_search": ef}})
                col = open_client().get_collection(run_id)  # 재오픈 → 새 ef_search 로 인덱스 로드
            else:
                name = f"{run_id}-ef{ef}"
                ingest.append(build(name, ef))
                col = open_client().get_collection(name)
            row = measure(col, ef)
            rows.append(row)
            lines.append(f"{ef:>9} | {row['recall']:>9.4f} | {row['p50_ms']:>7.2f} | {row['p95_ms']:>7.2f} "
                         f"| {row['p99_ms']:>7.2f} | {row['qps']:>7.0f}")
        print("\n" + header + "\n" + "-" * len(header) + "\n" + "\n".join(lines))
        ingest_s = statistics.mean(ingest)

        out_dir = ROOT / "bench" / "results"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"{run_id}.json"
        out.write_text(json.dumps({
            "params": vars(args), "chromadb": chromadb.__version__, "python": sys.version.split()[0],
            "ingest_seconds": ingest_s, "ingest_vps": args.n / ingest_s, "results": rows,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\n[save] {out}")
    finally:
        try:
            client = open_client()
            for name in created:
                client.delete_collection(name)
        except Exception:
            pass
        if tmpdir:
            SharedSystemClient.clear_system_cache()
            shutil.rmtree(tmpdir, ignore_errors=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
