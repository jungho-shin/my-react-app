"""Chroma HNSW 벤치마크: 적재 처리량, Recall@k, 지연시간(p50/p95/p99), QPS.

정답(ground truth)은 numpy 브루트포스(정확 검색)로 계산한다.

주의(chromadb 1.5.9 에서 확인): collection.modify() 로 ef_search 를 바꾸면 설정값은 저장되지만
이미 메모리에 로드된 HNSW 인덱스에는 반영되지 않는다(클라이언트/서버 재시작 후 반영).
  - embedded 모드: ef_search 값마다 클라이언트를 다시 열어 측정(재적재 없음)
  - http 모드    : 서버를 재시작할 수 없으므로 ef_search 값마다 컬렉션을 새로 만들어 측정(재적재)

예)
  python bench/bench_chroma.py                                # 기본: 50k x 128d, 임베디드
  python bench/bench_chroma.py -n 200000 --dim 384 --ef-search 32 64 128 256
  python bench/bench_chroma.py --mode http --port 8000        # 실행 중인 서버 대상
"""
import argparse
import json
import shutil
import statistics
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from vdb.Defines.VdbDefine import VdbDefine  # noqa: E402
from vdb.Enum.IENUM import IENUM  # noqa: E402


class E_DATA_KIND(IENUM):
    CLUSTERED = "clustered"  # 실제 임베딩과 비슷하게 군집 구조를 가진 데이터
    RANDOM = "random"        # 균등 랜덤(고차원에서 ANN 에 가장 불리한 최악 조건)


class BenchDataHelper:
    """벤치마크용 데이터 생성·정답 계산 정적 유틸."""

    @staticmethod
    def MakeData(kind: str, n: int, query_count: int, dim: int, seed: int):
        """정규화된 (적재 벡터, 질의 벡터) 를 만든다."""
        rng = np.random.default_rng(seed)
        if kind == E_DATA_KIND.CLUSTERED:
            centers = rng.standard_normal((max(16, n // 1000), dim)).astype(np.float32)
            baseVectors = BenchDataHelper._SampleAroundCenters(rng=rng, centers=centers, count=n)
            queryVectors = BenchDataHelper._SampleAroundCenters(rng=rng, centers=centers, count=query_count)
        else:
            baseVectors = rng.standard_normal((n, dim)).astype(np.float32)
            queryVectors = rng.standard_normal((query_count, dim)).astype(np.float32)
        baseVectors /= np.linalg.norm(baseVectors, axis=1, keepdims=True)
        queryVectors /= np.linalg.norm(queryVectors, axis=1, keepdims=True)
        return baseVectors, queryVectors

    @staticmethod
    def _SampleAroundCenters(rng, centers: np.ndarray, count: int) -> np.ndarray:
        index = rng.integers(0, len(centers), count)
        return centers[index] + 0.35 * rng.standard_normal((count, centers.shape[1])).astype(np.float32)

    @staticmethod
    def GetGroundTruth(baseVectors: np.ndarray, queryVectors: np.ndarray, k: int, chunk: int = 256) -> np.ndarray:
        """브루트포스 내적 기준 질의별 top-k 인덱스."""
        topLists = []
        for start in range(0, len(queryVectors), chunk):
            sims = queryVectors[start:start + chunk] @ baseVectors.T
            top = np.argpartition(-sims, k, axis=1)[:, :k]
            order = np.argsort(-np.take_along_axis(sims, top, axis=1), axis=1)
            topLists.append(np.take_along_axis(top, order, axis=1))
        return np.vstack(topLists)

    @staticmethod
    def GetPercentile(values: List[float], percent: float) -> float:
        return float(np.percentile(values, percent))


class ChromaBenchmark:
    """적재 → ef_search 별 질의 측정 → 결과 JSON 저장."""

    WARMUP_QUERY_COUNT = 20

    def __init__(self, args: argparse.Namespace):
        self._args = args
        self._runID = f"bench-{datetime.now():%Y%m%d%H%M%S}"
        self._tmpDir = tempfile.mkdtemp(prefix="chroma-bench-") if self._IsEmbedded() else None
        self._createdCollections: List[str] = []
        self._baseVectors = None
        self._queryVectors = None
        self._groundTruth = None

    def Run(self) -> int:
        args = self._args
        try:
            ## 데이터 · 정답 준비
            print(f"[data] {args.data} n={args.n:,} dim={args.dim} queries={args.queries} k={args.k}")
            self._baseVectors, self._queryVectors = BenchDataHelper.MakeData(
                kind=args.data, n=args.n, query_count=args.queries, dim=args.dim, seed=args.seed)
            startTime = time.perf_counter()
            self._groundTruth = BenchDataHelper.GetGroundTruth(
                baseVectors=self._baseVectors, queryVectors=self._queryVectors, k=args.k)
            print(f"[gt]   brute-force ground truth {time.perf_counter() - startTime:.2f}s")

            ## ef_search 별 측정
            resultRows, ingestSeconds = self._MeasureAll()
            self._PrintTable(resultRows)

            ## 결과 저장
            self._SaveResult(resultRows=resultRows, ingest_seconds=statistics.mean(ingestSeconds))
        finally:
            self._Cleanup()
        return 0

    def _IsEmbedded(self) -> bool:
        return self._args.mode == VdbDefine.E_MODE.EMBEDDED

    def _OpenClient(self):
        import chromadb
        from chromadb.api.shared_system_client import SharedSystemClient
        from chromadb.config import Settings

        # HttpClient 가 Settings 객체를 변경하므로 매번 새로 생성
        chromaSettings = Settings(anonymized_telemetry=False)
        if not self._IsEmbedded():
            return chromadb.HttpClient(host=self._args.host, port=self._args.port, settings=chromaSettings)
        SharedSystemClient.clear_system_cache()
        return chromadb.PersistentClient(path=self._tmpDir, settings=chromaSettings)

    def _MeasureAll(self):
        args = self._args
        resultRows: List[Dict[str, Any]] = []
        ingestSeconds: List[float] = []
        if self._IsEmbedded():
            ingestSeconds.append(self._BuildCollection(name=self._runID, ef_search=args.ef_search[0]))

        for efSearch in args.ef_search:
            if self._IsEmbedded():
                self._OpenClient().get_collection(self._runID).modify(
                    configuration={"hnsw": {"ef_search": efSearch}})
                collection = self._OpenClient().get_collection(self._runID)  # 재오픈 → 새 ef_search 로 인덱스 로드
            else:
                name = f"{self._runID}-ef{efSearch}"
                ingestSeconds.append(self._BuildCollection(name=name, ef_search=efSearch))
                collection = self._OpenClient().get_collection(name)
            resultRows.append(self._Measure(collection=collection, ef_search=efSearch))
        return resultRows, ingestSeconds

    def _BuildCollection(self, name: str, ef_search: int) -> float:
        args = self._args
        client = self._OpenClient()
        collection = client.create_collection(name, embedding_function=None, configuration={"hnsw": {
            "space": args.space, "max_neighbors": args.max_neighbors,
            "ef_construction": args.ef_construction, "ef_search": ef_search}})
        self._createdCollections.append(name)

        batchSize = min(args.batch, client.get_max_batch_size())
        startTime = time.perf_counter()
        for start in range(0, args.n, batchSize):
            end = min(start + batchSize, args.n)
            collection.add(ids=[str(x) for x in range(start, end)], embeddings=self._baseVectors[start:end])
        seconds = time.perf_counter() - startTime
        print(f"[load] {name}: {args.n:,} vectors in {seconds:.1f}s "
              f"({args.n / seconds:,.0f} vec/s, batch={batchSize})")
        return seconds

    def _Measure(self, collection, ef_search: int) -> Dict[str, Any]:
        k = self._args.k
        for queryVector in self._queryVectors[:self.WARMUP_QUERY_COUNT]:  # 워밍업
            collection.query(query_embeddings=[queryVector], n_results=k, include=[])

        latencies: List[float] = []
        hitCount = 0
        for queryIndex, queryVector in enumerate(self._queryVectors):
            startTime = time.perf_counter()
            result = collection.query(query_embeddings=[queryVector], n_results=k, include=[])
            latencies.append((time.perf_counter() - startTime) * 1000)
            hitCount += len({int(x) for x in result["ids"][0]} & set(self._groundTruth[queryIndex].tolist()))

        actualEfSearch = collection.configuration["hnsw"]["ef_search"]
        if actualEfSearch != ef_search:
            raise RuntimeError(f"ef_search mismatch: expected {ef_search}, got {actualEfSearch}")
        return {
            "ef_search": ef_search,
            "recall": hitCount / (len(self._queryVectors) * k),
            "p50_ms": BenchDataHelper.GetPercentile(values=latencies, percent=50),
            "p95_ms": BenchDataHelper.GetPercentile(values=latencies, percent=95),
            "p99_ms": BenchDataHelper.GetPercentile(values=latencies, percent=99),
            "qps": 1000 / statistics.mean(latencies),
        }

    def _PrintTable(self, resultRows: List[Dict[str, Any]]):
        header = (f"{'ef_search':>9} | {'recall@' + str(self._args.k):>9} | {'p50 ms':>7} | "
                  f"{'p95 ms':>7} | {'p99 ms':>7} | {'QPS':>7}")
        lines = [f"{row['ef_search']:>9} | {row['recall']:>9.4f} | {row['p50_ms']:>7.2f} | {row['p95_ms']:>7.2f} "
                 f"| {row['p99_ms']:>7.2f} | {row['qps']:>7.0f}" for row in resultRows]
        print("\n" + header + "\n" + "-" * len(header) + "\n" + "\n".join(lines))

    def _SaveResult(self, resultRows: List[Dict[str, Any]], ingest_seconds: float):
        import chromadb

        outDir = ROOT / "bench" / "results"
        outDir.mkdir(parents=True, exist_ok=True)
        outFile = outDir / f"{self._runID}.json"
        outFile.write_text(json.dumps({
            "params": vars(self._args), "chromadb": chromadb.__version__, "python": sys.version.split()[0],
            "ingest_seconds": ingest_seconds, "ingest_vps": self._args.n / ingest_seconds, "results": resultRows,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\n[save] {outFile}")

    def _Cleanup(self):
        from chromadb.api.shared_system_client import SharedSystemClient

        try:
            client = self._OpenClient()
            for name in self._createdCollections:
                client.delete_collection(name)
        except Exception:
            pass  # 정리 단계 실패는 무시 (임시 디렉터리는 아래에서 통째로 삭제)
        if self._tmpDir:
            SharedSystemClient.clear_system_cache()
            shutil.rmtree(self._tmpDir, ignore_errors=True)


def ParseArgs() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("-n", type=int, default=50_000, help="적재 벡터 수")
    parser.add_argument("--dim", type=int, default=128)
    parser.add_argument("--queries", type=int, default=500)
    parser.add_argument("-k", type=int, default=10)
    parser.add_argument("--data", choices=[E_DATA_KIND.CLUSTERED, E_DATA_KIND.RANDOM], default=E_DATA_KIND.CLUSTERED)
    parser.add_argument("--space", choices=[VdbDefine.E_SPACE.COSINE, VdbDefine.E_SPACE.L2, VdbDefine.E_SPACE.IP],
                        default=VdbDefine.E_SPACE.COSINE)
    parser.add_argument("--max-neighbors", type=int, default=16, help="HNSW M")
    parser.add_argument("--ef-construction", type=int, default=100)
    parser.add_argument("--ef-search", type=int, nargs="+", default=[10, 20, 50, 100, 200])
    parser.add_argument("--batch", type=int, default=5000)
    parser.add_argument("--mode", choices=[VdbDefine.E_MODE.EMBEDDED, VdbDefine.E_MODE.HTTP],
                        default=VdbDefine.E_MODE.EMBEDDED)
    parser.add_argument("--host", default=VdbDefine.DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=VdbDefine.DEFAULT_PORT)
    parser.add_argument("--seed", type=int, default=7)
    return parser.parse_args()


def main() -> int:
    return ChromaBenchmark(args=ParseArgs()).Run()


if __name__ == "__main__":
    raise SystemExit(main())
