# ChromaDB 개발·테스트 환경 (Windows 10 네이티브)

Docker / WSL2 / 관리자 권한 **없이** Windows 10 에서 동작하는 무료(Apache 2.0) ChromaDB 환경.

| 항목 | 버전 |
|---|---|
| Python | 3.11 (프로젝트 venv `.venv`) |
| chromadb | 1.5.9 (Rust 코어, Windows wheel) |
| 기본 임베딩 | all-MiniLM-L6-v2 (ONNX, CPU, 384차원, 영어) |

## 구성

```
vectordb/
├─ requirements.txt
├─ pytest.ini
├─ scripts/
│  ├─ setup.ps1          # venv 생성 + 의존성 설치 + 임베딩 모델(기본·한국어) 사전 다운로드
│  ├─ start_server.ps1   # chroma HTTP 서버 백그라운드 기동 (PID: run\chroma.pid, 로그: logs\)
│  ├─ stop_server.ps1
│  ├─ status.ps1
│  └─ test.ps1           # pytest 실행 래퍼
├─ src/vdb/              # 설정(env) + 클라이언트 팩토리 + 한국어 임베딩 함수
├─ examples/             # quickstart.py (영어), korean_search.py (한국어)
├─ tests/                # pytest 통합 테스트 (embedded + http 양쪽 모드 자동 실행)
└─ bench/bench_chroma.py # Recall@k / 지연시간 / QPS / 적재속도 벤치마크
```

## 빠른 시작 (PowerShell)

```powershell
cd D:\TAOS9938\Workspace\vectordb
.\scripts\setup.ps1                      # 최초 1회

# 1) 임베디드 모드 (서버 불필요, 데이터: .\data\chroma)
.\.venv\Scripts\python.exe examples\quickstart.py

# 2) 서버 모드
.\scripts\start_server.ps1               # 기본 127.0.0.1:8000, -Port / -DataDir 로 변경 가능
$env:VDB_MODE = "http"
.\.venv\Scripts\python.exe examples\quickstart.py
Remove-Item Env:VDB_MODE
.\scripts\stop_server.ps1
```

환경변수: `VDB_MODE`(embedded|http), `VDB_DATA_DIR`, `VDB_HOST`, `VDB_PORT`, `VDB_EMBED`(e5-small|bge-m3|default)

## 한국어 임베딩

PyTorch 없이 `onnxruntime` + `tokenizers` 로 다국어 모델을 돌린다 (`src/vdb/embeddings.py`).

| `VDB_EMBED` | 모델 | 차원 | 다운로드 | 비고 |
|---|---|---|---|---|
| `e5-small` (기본) | intfloat/multilingual-e5-small | 384 | ~470MB | CPU 에서 빠름, 한·영 교차 검색 가능 |
| `bge-m3` | BAAI/bge-m3 | 1024 | ~2.2GB | 품질 우선, 느림 |
| `default` | Chroma 기본 all-MiniLM-L6-v2 | 384 | ~80MB | 영어 전용 |

```python
from vdb import get_client, get_embedding_function

client = get_client()
col = client.get_or_create_collection("ko-docs", embedding_function=get_embedding_function(),
                                      configuration={"hnsw": {"space": "cosine"}})
col.add(ids=["1"], documents=["한국은행이 기준금리를 인상했다."])
col.query(query_texts=["이자율 정책"], n_results=5)
```

- e5 의 `passage: ` / `query: ` 접두어는 자동으로 붙는다 (적재는 `__call__`, 질의는 `embed_query`).
- 임베딩 함수 설정이 컬렉션에 저장되므로 이후엔 `client.get_collection("ko-docs")` 만으로 같은 모델이 복원된다
  (단, `vdb` 패키지를 import 한 프로세스여야 함 — import 시 Chroma 에 등록됨).
- **모델은 컬렉션 생성 후 바꿀 수 없다.** 다른 모델을 쓰려면 새 컬렉션에 다시 적재한다.
- 모델 캐시: `%USERPROFILE%\.cache\huggingface\hub\`. 폐쇄망은 이 폴더를 복사하고 `HF_HUB_OFFLINE=1` 설정.
- 예제: `.\.venv\Scripts\python.exe examples\korean_search.py`

## 테스트

```powershell
.\scripts\test.ps1                 # 전체 (embedded + http 서버 자동 기동/종료)
.\scripts\test.ps1 -m "not server" # 임베디드만 (빠름)
.\scripts\test.ps1 -m "not model"  # 임베딩 모델 없이 (오프라인)
```

| 파일 | 검증 내용 |
|---|---|
| `test_crud.py` | add / get / update / upsert / delete(id·where), 차원 불일치 거부, 컬렉션 생성·삭제 |
| `test_query.py` | 자기 자신 top-1, 거리 정렬, 브루트포스 대비 정확도, where / where_document 필터, 배치 질의, l2·ip·cosine |
| `test_config.py` | HNSW 파라미터 적용·변경, ef_search 변경 반영 조건 |
| `test_persistence.py` | 임베디드 재오픈 / 서버 재시작 후 데이터 유지 |
| `test_embedding.py` | 기본 임베딩 함수로 텍스트 의미 검색 |
| `test_korean_embedding.py` | multilingual-e5 로 한국어·한영 교차 의미 검색, 재오픈 시 임베딩 함수 복원 |

`http` 모드 테스트는 conftest 가 빈 포트·임시 디렉터리로 `chroma.exe run` 을 띄우고 끝나면 종료한다.

## 벤치마크

```powershell
.\.venv\Scripts\python.exe bench\bench_chroma.py                                  # 50k x 128d
.\.venv\Scripts\python.exe bench\bench_chroma.py -n 200000 --dim 384 --ef-search 32 64 128 256
.\.venv\Scripts\python.exe bench\bench_chroma.py --data random                    # 최악 조건(균등 랜덤)
.\.venv\Scripts\python.exe bench\bench_chroma.py --mode http --port 8000          # 실행 중인 서버 대상
```

결과는 `bench\results\*.json` 에 저장된다. 참고값 (i7-1255U, 20k x 128d clustered, embedded, k=10):

| ef_search | recall@10 | p50 ms | p95 ms |
|---|---|---|---|
| 10 | 0.693 | 1.1 | 1.6 |
| 50 | 0.973 | 1.1 | 1.7 |
| 100 | 0.997 | 1.5 | 2.2 |
| 200 | 1.000 | 1.4 | 2.2 |

## 주의사항 (chromadb 1.5.9 에서 확인)

1. **`collection.modify()` 로 바꾼 `ef_search` 는 로드된 인덱스에 즉시 반영되지 않는다.**
   설정값은 저장되지만 클라이언트 재오픈(임베디드) 또는 서버 재시작 후 적용된다.
   → 튜닝 시 재오픈 필요. `test_config.py::test_ef_search_modify_takes_effect_after_reopen` 참고.
2. **`HttpClient` 는 넘겨받은 `Settings` 객체에 host/port 를 기록한다.**
   하나의 `Settings` 인스턴스를 여러 클라이언트가 공유하면 포트 충돌 오류가 난다 → 매번 새로 생성.
3. **임베딩 함수 없이(`embedding_function=None`) 만든 컬렉션에서 `documents` 만 update 하면 오류.**
   벡터를 재계산할 수 없으므로 `embeddings` 를 함께 넘겨야 한다.
4. **기본 임베딩 모델은 영어 전용.** 한국어는 위 "한국어 임베딩" 절의 `get_embedding_function()` 을 쓴다.
5. 컬렉션 이름은 3~512자, `[a-zA-Z0-9._-]`, 영숫자로 시작·끝.
6. 기본 모델은 최초 실행 시 `%USERPROFILE%\.cache\chroma\onnx_models\` 로 다운로드된다(약 80MB).
   폐쇄망에서는 이 폴더를 그대로 복사하면 된다.
7. PowerShell 5.1 은 BOM 없는 UTF-8 `.ps1` 의 한글을 깨뜨리므로 스크립트는 UTF-8 **with BOM** 으로 저장한다.
