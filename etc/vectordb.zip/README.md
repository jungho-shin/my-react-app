# ChromaDB 개발·테스트 환경 (Windows 10 네이티브)

Docker / WSL2 / 관리자 권한 **없이** Windows 10 에서 동작하는 무료(Apache 2.0) ChromaDB 환경.

| 항목 | 버전 |
|---|---|
| Python | 3.11 (프로젝트 venv `.venv`) |
| chromadb | 1.5.9 (Rust 코어, Windows wheel) |
| 기본 임베딩 | all-MiniLM-L6-v2 (ONNX, CPU, 384차원, 영어) |

## 구성

```
vectordb/
├─ requirements.txt
├─ pytest.ini
├─ scripts/
│  ├─ setup.ps1          # venv 생성 + 의존성 설치 + 임베딩 모델(기본·한국어) 사전 다운로드
│  ├─ start_server.ps1   # chroma HTTP 서버 백그라운드 기동 (PID: run\chroma.pid, 로그: logs\)
│  ├─ stop_server.ps1
│  ├─ status.ps1
│  ├─ test.ps1           # pytest 실행 래퍼
│  ├─ start_web.ps1      # Chroma 서버 + 웹 서버(백엔드·프런트엔드) 기동 (PID: run\web.pid)
│  ├─ stop_web.ps1       # 웹 서버 종료 (-All: Chroma 서버도 종료)
│  ├─ web_server.py      # 웹 서버 진입점 (uvicorn)
│  └─ mcp_server.py      # Claude Code 용 MCP 서버 진입점 (stdio, .mcp.json 에서 실행)
├─ src/vdb/              # 라이브러리 (.claude/skills/python-convention 준수, 파일 1개 = 클래스 1개)
│  ├─ Config/VdbConfigHelper.py         # 환경변수 → VdbSettingsDto
│  ├─ Defines/                          # VdbDefine, EmbeddingDefine(IENUM 상수), EmbeddingModelMeta(모델 사양 표)
│  ├─ Dtos/                             # VdbSettingsDto, EmbeddingModelSpecDto
│  ├─ Embedding/                        # MultilingualOnnxEmbeddingFunction, OnnxEncoder, OnnxEncoderManager(싱글톤)
│  ├─ Factory/                          # VdbClientFactory, EmbeddingFunctionFactory
│  ├─ Enum/IENUM.py, Utils/Singleton.py # Haerujil24 common_lib 최소 복제
│  ├─ Utils/                            # QueryResultHelper, TextChunkHelper, DocumentImportHelper, MetadataHelper
│  ├─ Serving/                          # 웹 백엔드 (FastAPI): VdbWebServer, Controller/, Service/, Models/
│  └─ Mcp/VdbMcpServer.py               # Claude Code 용 MCP 서버 (웹 API 호출, 읽기 전용)
├─ frontend/             # 웹 화면 (index.html, app.js, style.css — 빌드 불필요, 백엔드가 서빙)
├─ examples/             # quickstart.py (영어), korean_search.py (한국어), tutorial_beginner.py (입문 실습)
├─ tests/                # pytest 통합 테스트 (embedded + http 양쪽 모드 자동 실행)
└─ bench/bench_chroma.py # Recall@k / 지연시간 / QPS / 적재속도 벤치마크
```

`src/vdb/__init__.py` 는 비어 있다(re-export 없음). 클래스는 전체 경로로 import 한다:
`from vdb.Factory.VdbClientFactory import VdbClientFactory`

## 빠른 시작 (PowerShell)

```powershell
cd D:\TAOS9938\Workspace\vectordb
.\scripts\setup.ps1                      # 최초 1회

# 1) 임베디드 모드 (서버 불필요, 데이터: .\data\chroma)
.\.venv\Scripts\python.exe examples\quickstart.py

# 2) 서버 모드
.\scripts\start_server.ps1               # 기본 0.0.0.0:8000 (다른 PC 접속 허용). 이 PC 전용: -BindHost 127.0.0.1
$env:VDB_MODE = "http"
.\.venv\Scripts\python.exe examples\quickstart.py
Remove-Item Env:VDB_MODE
.\scripts\stop_server.ps1
```

## 서버 실행 요약

| 서버 | 포트 | 시작 | 종료 | 상태 확인 | 로그 / PID |
|---|---|---|---|---|---|
| Chroma 서버 (벡터 DB) | 8000 | `.\scripts\start_server.ps1` | `.\scripts\stop_server.ps1` | `.\scripts\status.ps1` | `logs\chroma.*.log` / `run\chroma.pid` |
| 웹 서버 (API + 화면) | 8080 | `.\scripts\start_web.ps1` | `.\scripts\stop_web.ps1` | `Invoke-RestMethod http://127.0.0.1:8080/api/status` | `logs\web.*.log` / `run\web.pid` |

- 프런트엔드(화면)는 별도 서버가 없다. 웹 서버가 `frontend\` 를 함께 서빙한다.
- **웹 화면만 쓸 때는 `start_web.ps1` 하나로 충분하다.** Chroma 가 꺼져 있으면 이 PC 전용(127.0.0.1)으로 함께 띄운다.
- 모든 서버는 백그라운드로 뜨며 PC 를 재부팅하면 꺼진다. 재부팅 후 다시 `start_web.ps1` 을 실행한다.
- 최초 1회 `.\scripts\setup.ps1` (venv·패키지·임베딩 모델 설치)이 필요하다.

스크립트 옵션:

```powershell
.\scripts\start_server.ps1 -BindHost 127.0.0.1 -Port 8000 -DataDir D:\data\chroma   # 기본: 0.0.0.0, 8000, .\data\chroma
.\scripts\status.ps1 -BindHost 127.0.0.1 -Port 8000
.\scripts\start_web.ps1 -WebHost 0.0.0.0 -WebPort 8080 -ChromaPort 8000            # 기본값
.\scripts\stop_web.ps1 -All                                                         # 웹 + Chroma 모두 종료
```

> 주의: `start_server.ps1` 을 기본값(0.0.0.0)으로 먼저 띄운 뒤 `start_web.ps1` 을 실행하면 그 Chroma 서버를 그대로 쓰므로
> Chroma 도 다른 PC 에 열린 상태가 된다. 웹으로만 쓰려면 `start_web.ps1` 만 실행하거나 `-BindHost 127.0.0.1` 로 띄운다.

디버깅용 포그라운드 실행 (콘솔에 로그가 바로 보임, `Ctrl+C` 로 종료):

```powershell
.\.venv\Scripts\chroma.exe run --path .\data\chroma --host 127.0.0.1 --port 8000
$env:VDB_MODE = "http"; .\.venv\Scripts\python.exe scripts\web_server.py --host 0.0.0.0 --port 8080
```

### 다른 PC 에서 접속

`start_server.ps1` 은 기본으로 `0.0.0.0` 에 바인딩하고, 기동 시 접속 주소(`http://<이 PC IP>:8000`)를 출력한다.
접속하는 PC 에서는 `$env:VDB_MODE="http"; $env:VDB_HOST="<이 PC IP>"` 또는 `chromadb.HttpClient(host="<IP>", port=8000)`.

- **Windows 방화벽**이 외부 인바운드를 막는다. 8000 포트 허용 규칙은 관리자 권한이 필요하므로 IT 담당자에게 요청:
  `New-NetFirewallRule -DisplayName "Chroma 8000" -Direction Inbound -Protocol TCP -LocalPort 8000 -Action Allow -Profile Domain,Private`
- 네트워크 프로필이 **공용(Public)** 이면 기본 차단된다. 사내/가정망이면 개인(Private)으로 바꿀 것.
- Chroma 서버에는 **인증이 없다.** 신뢰할 수 있는 내부망에서만 사용한다.

환경변수: `VDB_MODE`(embedded|http), `VDB_DATA_DIR`, `VDB_HOST`, `VDB_PORT`, `VDB_EMBED`(e5-small|bge-m3|default)

## 웹 화면 (데이터 등록 · 검색)

브라우저에서 컬렉션을 만들고, 문서를 등록하고, 의미 검색을 할 수 있다.

```
브라우저 ──HTTP──▶ 웹 서버 :8080 (FastAPI: /api/* + 화면) ──▶ Chroma 서버 127.0.0.1:8000
                    └ 임베딩 계산(e5-small 등)도 웹 서버에서 수행
```

```powershell
.\scripts\start_web.ps1                    # Chroma(이 PC 전용) + 웹(0.0.0.0:8080) 기동 → http://127.0.0.1:8080
.\scripts\start_web.ps1 -WebHost 127.0.0.1 # 웹도 이 PC 에서만
.\scripts\stop_web.ps1                     # 웹 서버만 종료
.\scripts\stop_web.ps1 -All                # Chroma 서버까지 종료
```

- Chroma 서버가 꺼져 있으면 `127.0.0.1` 로 먼저 띄운다(외부에서 Chroma 직접 접근 불가). 이미 떠 있으면 그대로 쓴다.
- 로그: `logs\web.out.log`, `logs\web.err.log`.
- **다른 PC 접속**: 기동 시 출력되는 `http://<이 PC IP>:8080` 으로 접속한다. 웹 서버 프로세스는
  `%LOCALAPPDATA%\Programs\Python\Python311\python.exe` 이므로, 이 프로그램의 인바운드 허용 규칙이 있으면
  (Python 을 처음 네트워크에 열 때 Windows 가 묻는 "액세스 허용"으로 생김) 추가 설정 없이 접속된다.
  확인: `netsh advfirewall firewall show rule name=python.exe dir=in`.
  규칙이 없거나 현재 네트워크 프로필(공용/개인)에 해당하지 않으면 관리자에게 8080 포트 허용을 요청한다:
  `New-NetFirewallRule -DisplayName "VDB Web 8080" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow`
- 공유기의 **AP 격리(무선 단말 간 통신 차단)** 가 켜져 있으면 같은 Wi-Fi 라도 접속되지 않는다.
- IP 는 DHCP 로 바뀔 수 있다. 바뀌면 `start_web.ps1` 출력 또는 `ipconfig` 로 다시 확인한다.
- **로그인 기능이 없다.** 누구나 등록·삭제할 수 있으므로 신뢰할 수 있는 내부망에서만 사용한다.

| 화면 | 기능 |
|---|---|
| 컬렉션 | 생성(이름·임베딩 모델·거리 방식·설명), 삭제, 목록(문서 수·모델) |
| 검색 | 문장으로 의미 검색, 결과 개수, 메타데이터 조건(JSON, `$gte` 등), 본문 포함 단어 필터, 유사도 표시 |
| 데이터 등록 | 직접 입력(ID·본문·메타데이터) / 파일 업로드: 긴 텍스트 자동 분할, 한 줄=문서, CSV, JSONL / 웹페이지 링크 |
| 데이터 조회 | 페이지 목록, 본문 필터, 수정(벡터 재계산), 개별·선택 삭제 |

파일 업로드 형식:

| 형식 | 내용 |
|---|---|
| 긴 텍스트 (`.txt`, `.md`) | 문단·문장 경계로 `청크 크기` 글자 이하로 나눔. 메타데이터 `source`(파일명), `chunk_index` 자동 |
| 한 줄 = 문서 | 빈 줄 제외, 각 줄이 문서 1개 |
| CSV | `document` 열 필수, `id` 열 선택, 나머지 열은 메타데이터 (숫자는 숫자로 저장) |
| JSONL | 줄마다 `{"id": "...", "document": "...", "metadata": {...}}` (`id`·`metadata` 선택) |
| 저장한 웹페이지 (`.html`) | 브라우저에서 저장한 페이지. 본문만 추출(링크 등록과 같은 방식) 후 분할, `title` 자동 |

웹페이지 링크 등록:

- 웹 서버가 페이지를 받아 본문만 추출(script·메뉴·푸터 제외, `<article>`/`<main>` 우선)하고 청크로 나눠 저장한다.
- 메타데이터 자동: `source`(최종 URL), `title`, `domain`, `fetched_date`(YYYYMMDD 정수), `chunk_index`. 공통 메타데이터에 `title` 을 주면 그 값을 쓴다.
- 문서 ID 는 `url-<URL 해시>-<번호>`. 같은 URL 을 다시 넣으면 409, "기존 데이터 교체"를 체크하면 지우고 다시 가져온다.
- HTML·일반 텍스트만 지원(PDF 불가). 로그인이 필요하거나 JavaScript 로만 그려지는 페이지는 본문이 없다. 최대 5MB, 15초.
- EUC-KR 페이지는 `<meta charset>` 으로 판별해 디코딩한다.
- **보안**: `127.0.0.1`·`localhost`·`169.254.x.x` 등 로컬/예약 주소는 거부한다(웹을 통한 Chroma 서버 우회 접근 방지). 사내망(192.168.x.x 등)은 허용.
- **봇 차단(Cloudflare 등) 사이트**(예: wikidocs.net)는 가져올 수 없다(차단 우회는 하지 않는다). 브라우저에서 열고
  `Ctrl+S`(웹페이지, HTML만)로 저장한 뒤 파일 업로드로 올린다.
- 일부 사이트(예: 위키백과)는 연락처 없는 수집기를 403 으로 막는다. 필요하면 웹 서버 기동 전에
  `$env:VDB_URL_USER_AGENT = "VDB-Web/1.0 (담당자 이메일)"` 처럼 설정한다.

REST API 문서(Swagger): `http://127.0.0.1:8080/api/docs`

| 메서드 | 경로 | 설명 |
|---|---|---|
| GET | `/api/status` | Chroma 연결 상태 |
| GET / POST | `/api/collections` | 목록 / 생성 |
| GET / DELETE | `/api/collections/{name}` | 정보 / 삭제 |
| GET / POST | `/api/collections/{name}/documents` | 목록(`offset`,`limit`,`contains`) / 등록 |
| POST | `/api/collections/{name}/documents/import` | 파일 내용 일괄 등록 |
| POST | `/api/collections/{name}/documents/url` | 웹페이지 링크로 등록 (`{"url", "replace"?, "metadata"?}`) |
| POST | `/api/collections/{name}/documents/delete` | 여러 건 삭제 (`{"ids": [...]}`) |
| GET / PUT / DELETE | `/api/collections/{name}/documents/{id}` | 1건 조회 / 수정 / 삭제 |
| POST | `/api/collections/{name}/search` | 의미 검색 |

```powershell
# 예: PowerShell 에서 API 로 검색
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8080/api/collections/demo-ko/search `
  -ContentType "application/json; charset=utf-8" `
  -Body ([Text.Encoding]::UTF8.GetBytes('{"query": "이자율 정책", "n_results": 3}'))
```

오류 응답은 `{"response": {"code": "...", "message": "..."}}` 형태다 (400 잘못된 요청, 404 없음, 409 ID·이름 중복, 503 Chroma 서버 연결 불가).

## Claude Code 에서 RAG (MCP 서버)

Claude Code 가 VDB 를 검색 도구로 써서 **등록한 문서를 근거로 답하게** 한다. API 키·추가 비용 없음.

```
Claude Code ─(stdio)─▶ scripts\mcp_server.py ─HTTP─▶ 웹 서버 :8080 /api/.../search ─▶ Chroma
```

| 도구 | 설명 |
|---|---|
| `vdb_list_collections` | 컬렉션 목록 (문서 수·모델·설명) |
| `vdb_search` | 의미 검색 (`collection`, `query`, `n_results`, `where`, `contains`) → 번호·id·유사도·title·source·본문 |
| `vdb_get_document` | 조각 1건 전체 본문·메타데이터 |

읽기 전용이다(등록·삭제 도구 없음). 사용 방법:

1. 웹 서버를 띄운다: `.\scripts\start_web.ps1` (MCP 서버는 웹 서버의 검색 API 를 쓴다)
2. 이 폴더에서 Claude Code 를 새로 연다. 처음 한 번 `.mcp.json` 의 `vdb` 서버 사용 승인 창에서 승인한다.
   (VS Code 확장에서는 새 대화를 시작하면 적용된다. 상태 확인: `claude mcp list`)
3. 질문한다. 예: "demo-ko 컬렉션에서 찾아서 벡터 데이터베이스가 뭔지 설명해줘"

- 설정 파일: [.mcp.json](.mcp.json) (프로젝트 범위). 웹 서버 주소를 바꾸면 `VDB_WEB_URL` 을 수정한다.
- 웹 서버가 꺼져 있으면 도구가 "VDB web server is not reachable … start_web.ps1" 오류를 돌려준다.
- 검색된 문서 조각은 Claude(Anthropic)로 전송된다. 외부 전송이 안 되는 자료는 넣지 않는다.

## 한국어 임베딩

PyTorch 없이 `onnxruntime` + `tokenizers` 로 다국어 모델을 돌린다 (`src/vdb/Embedding/`).

| `VDB_EMBED` | 모델 | 차원 | 다운로드 | 비고 |
|---|---|---|---|---|
| `e5-small` (기본) | intfloat/multilingual-e5-small | 384 | ~470MB | CPU 에서 빠름, 한·영 교차 검색 가능 |
| `bge-m3` | BAAI/bge-m3 | 1024 | ~2.2GB | 품질 우선, 느림 |
| `default` | Chroma 기본 all-MiniLM-L6-v2 | 384 | ~80MB | 영어 전용 |

```python
from vdb.Factory.EmbeddingFunctionFactory import EmbeddingFunctionFactory
from vdb.Factory.VdbClientFactory import VdbClientFactory

client = VdbClientFactory.CreateClient()          # VDB_MODE 에 따라 임베디드 / HTTP
col = client.get_or_create_collection("ko-docs",
                                      embedding_function=EmbeddingFunctionFactory.CreateEmbeddingFunction(),
                                      configuration={"hnsw": {"space": "cosine"}})
col.add(ids=["1"], documents=["한국은행이 기준금리를 인상했다."])
col.query(query_texts=["이자율 정책"], n_results=5)
```

- e5 의 `passage: ` / `query: ` 접두어는 자동으로 붙는다 (적재는 `__call__`, 질의는 `embed_query`).
- 임베딩 함수 설정이 컬렉션에 저장되므로 이후엔 `client.get_collection("ko-docs")` 만으로 같은 모델이 복원된다
  (단, `vdb.Factory.EmbeddingFunctionFactory` 또는 `vdb.Embedding.MultilingualOnnxEmbeddingFunction` 을
  import 한 프로세스여야 함 — import 시 Chroma 에 등록됨).
- 같은 프로세스에서는 모델(ONNX 세션)을 `OnnxEncoderManager` 가 1개만 올려 공유한다.
- **모델은 컬렉션 생성 후 바꿀 수 없다.** 다른 모델을 쓰려면 새 컬렉션에 다시 적재한다.
- 모델 캐시: `%USERPROFILE%\.cache\huggingface\hub\`. 폐쇄망은 이 폴더를 복사하고 `HF_HUB_OFFLINE=1` 설정.
- 예제: `.\.venv\Scripts\python.exe examples\korean_search.py`

## 테스트

```powershell
.\scripts\test.ps1                 # 전체 (embedded + http 서버 자동 기동/종료)
.\scripts\test.ps1 -m "not server" # 임베디드만 (빠름)
.\scripts\test.ps1 -m "not model"  # 임베딩 모델 없이 (오프라인)
```

| 파일 | 검증 내용 |
|---|---|
| `test_crud.py` | add / get / update / upsert / delete(id·where), 차원 불일치 거부, 컬렉션 생성·삭제 |
| `test_query.py` | 자기 자신 top-1, 거리 정렬, 브루트포스 대비 정확도, where / where_document 필터, 배치 질의, l2·ip·cosine |
| `test_config.py` | HNSW 파라미터 적용·변경, ef_search 변경 반영 조건 |
| `test_persistence.py` | 임베디드 재오픈 / 서버 재시작 후 데이터 유지 |
| `test_embedding.py` | 기본 임베딩 함수로 텍스트 의미 검색 |
| `test_korean_embedding.py` | multilingual-e5 로 한국어·한영 교차 의미 검색, 재오픈 시 임베딩 함수 복원 |
| `test_mcp_server.py` | MCP 도구 목록(읽기 전용), 컬렉션 목록·검색·필터·단건 조회 결과 형식, 오류(404·웹 서버 다운) 전달 |
| `test_web_api.py` | 웹 API: 컬렉션 CRUD, 한국어 검색·필터, 파일 가져오기(csv·text), 웹페이지 링크(본문 추출·리다이렉트·중복·교체·로컬 주소 차단·EUC-KR), 페이지 조회, 수정·삭제, Chroma 다운 시 503 |

`http` 모드 테스트는 conftest 가 빈 포트·임시 디렉터리로 `chroma.exe run` 을 띄우고 끝나면 종료한다.

## 벤치마크

```powershell
.\.venv\Scripts\python.exe bench\bench_chroma.py                                  # 50k x 128d
.\.venv\Scripts\python.exe bench\bench_chroma.py -n 200000 --dim 384 --ef-search 32 64 128 256
.\.venv\Scripts\python.exe bench\bench_chroma.py --data random                    # 최악 조건(균등 랜덤)
.\.venv\Scripts\python.exe bench\bench_chroma.py --mode http --port 8000          # 실행 중인 서버 대상
```

결과는 `bench\results\*.json` 에 저장된다. 참고값 (i7-1255U, 20k x 128d clustered, embedded, k=10):

| ef_search | recall@10 | p50 ms | p95 ms |
|---|---|---|---|
| 10 | 0.693 | 1.1 | 1.6 |
| 50 | 0.973 | 1.1 | 1.7 |
| 100 | 0.997 | 1.5 | 2.2 |
| 200 | 1.000 | 1.4 | 2.2 |

## 주의사항 (chromadb 1.5.9 에서 확인)

1. **`collection.modify()` 로 바꾼 `ef_search` 는 로드된 인덱스에 즉시 반영되지 않는다.**
   설정값은 저장되지만 클라이언트 재오픈(임베디드) 또는 서버 재시작 후 적용된다.
   → 튜닝 시 재오픈 필요. `test_config.py::test_ef_search_modify_takes_effect_after_reopen` 참고.
2. **`HttpClient` 는 넘겨받은 `Settings` 객체에 host/port 를 기록한다.**
   하나의 `Settings` 인스턴스를 여러 클라이언트가 공유하면 포트 충돌 오류가 난다 → 매번 새로 생성.
3. **임베딩 함수 없이(`embedding_function=None`) 만든 컬렉션에서 `documents` 만 update 하면 오류.**
   벡터를 재계산할 수 없으므로 `embeddings` 를 함께 넘겨야 한다.
4. **기본 임베딩 모델은 영어 전용.** 한국어는 위 "한국어 임베딩" 절의 `EmbeddingFunctionFactory.CreateEmbeddingFunction()` 을 쓴다.
5. 컬렉션 이름은 3~512자, `[a-zA-Z0-9._-]`, 영숫자로 시작·끝.
6. 기본 모델은 최초 실행 시 `%USERPROFILE%\.cache\chroma\onnx_models\` 로 다운로드된다(약 80MB).
   폐쇄망에서는 이 폴더를 그대로 복사하면 된다.
7. PowerShell 5.1 은 BOM 없는 UTF-8 `.ps1` 의 한글을 깨뜨리므로 스크립트는 UTF-8 **with BOM** 으로 저장한다.
