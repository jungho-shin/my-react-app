from vdb.Config.VdbConfigHelper import VdbConfigHelper
from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Embedding.MultilingualOnnxEmbeddingFunction import MultilingualOnnxEmbeddingFunction
from vdb.Factory.IFactory import IFactory


class EmbeddingFunctionFactory(IFactory):
    """모델 이름(VDB_EMBED)에 맞는 Chroma 임베딩 함수 생성.

    이 모듈을 import 하면 MultilingualOnnxEmbeddingFunction 이 Chroma 에 등록되어
    client.get_collection(...) 만으로 저장된 임베딩 함수가 복원된다.
    """

    @staticmethod
    def CreateEmbeddingFunction(model_name: str | None = None):
        """model_name 이 없으면 VDB_EMBED 환경변수(기본 e5-small)를 쓴다."""
        model_name = (model_name or VdbConfigHelper.GetEmbeddingModelName()).lower()
        if model_name == EmbeddingDefine.E_MODEL.DEFAULT:
            from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

            return DefaultEmbeddingFunction()
        return MultilingualOnnxEmbeddingFunction(model_name=model_name)
