from vdb.Config.VdbConfigHelper import VdbConfigHelper
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Dtos.VdbSettingsDto import VdbSettingsDto
from vdb.Factory.IFactory import IFactory


class VdbClientFactory(IFactory):
    """Chroma 클라이언트 생성 (임베디드 / HTTP 공통 진입점)."""

    factories = {
        VdbDefine.E_MODE.EMBEDDED: lambda settings: VdbClientFactory._CreatePersistentClient(settings),
        VdbDefine.E_MODE.HTTP: lambda settings: VdbClientFactory._CreateHttpClient(settings),
    }

    @staticmethod
    def CreateClient(settings: VdbSettingsDto | None = None):
        """settings 가 없으면 환경변수(VDB_MODE 등)에서 읽는다."""
        settings = settings or VdbConfigHelper.LoadSettings()
        return VdbClientFactory.factories[settings.GetMode()](settings)

    @staticmethod
    def _CreateChromaSettings():
        from chromadb.config import Settings

        # HttpClient 는 넘겨받은 Settings 객체에 host/port 를 기록하므로 매번 새로 만든다
        return Settings(anonymized_telemetry=False)

    @staticmethod
    def _CreatePersistentClient(settings: VdbSettingsDto):
        import chromadb

        settings.GetDataDir().mkdir(parents=True, exist_ok=True)
        return chromadb.PersistentClient(path=str(settings.GetDataDir()),
                                         settings=VdbClientFactory._CreateChromaSettings())

    @staticmethod
    def _CreateHttpClient(settings: VdbSettingsDto):
        import chromadb

        return chromadb.HttpClient(host=settings.GetHost(), port=settings.GetPort(),
                                   settings=VdbClientFactory._CreateChromaSettings())
