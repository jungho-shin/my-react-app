class IFactory:
    """Factory 공통 인터페이스."""
