"""Claude Code 가 VDB 를 검색 도구로 쓰게 하는 MCP 서버 (읽기 전용).

실행 중인 VDB 웹 서버(/api)를 호출한다. 임베딩 모델은 웹 서버에 이미 올라가 있으므로
MCP 서버는 가볍게 뜨고, 검색 결과를 LLM 이 읽기 좋은 텍스트로 돌려준다.

※ MCP 도구 함수(vdb_search 등)는 외부에 노출되는 도구 이름이므로 snake_case 를 쓴다(serving 영역과 같은 예외).
※ stdio 전송은 stdout 으로 통신하므로 이 모듈에서 print(stdout) 를 쓰지 않는다. 로그는 stderr 로만.
"""
import json
import os
import sys
from typing import Any, Dict, List

import httpx

from vdb.Defines.McpDefine import McpDefine


class VdbMcpServer:
    """사용:
        VdbMcpServer().Build().run("stdio")
        VdbMcpServer(httpClient=TestClient(app)).Build()   # 테스트: 웹 서버 없이 FastAPI 앱에 직접 연결
    """

    def __init__(self, web_url: str | None = None, httpClient: httpx.Client | None = None):
        self._webUrl = (web_url or os.getenv(McpDefine.E_ENV.VDB_WEB_URL) or McpDefine.DEFAULT_WEB_URL).rstrip("/")
        self._httpClient = httpClient or httpx.Client(base_url=self._webUrl, timeout=McpDefine.HTTP_TIMEOUT_SEC)

    def GetWebUrl(self) -> str:
        return self._webUrl

    def Build(self):
        from mcp.server.mcpserver import MCPServer
        from mcp.types import ToolAnnotations

        server = MCPServer(name=McpDefine.SERVER_NAME, title="VDB (Chroma vector search)",
                           instructions=McpDefine.INSTRUCTIONS, log_level="WARNING")
        readOnly = ToolAnnotations(read_only_hint=True, destructive_hint=False, open_world_hint=False)

        @server.tool(annotations=readOnly)
        def vdb_list_collections() -> str:
            """VDB 의 컬렉션 목록 (이름, 문서 수, 임베딩 모델, 설명). 검색 전에 어떤 컬렉션이 있는지 확인할 때 쓴다."""
            return self.ListCollections()

        @server.tool(annotations=readOnly)
        def vdb_search(collection: str, query: str, n_results: int = 5,
                       where: Dict[str, Any] | None = None, contains: str | None = None) -> str:
            """컬렉션에서 query 와 의미가 비슷한 문서 조각을 찾는다 (한국어·영어 문장 질의 가능).

            Args:
                collection: 컬렉션 이름 (vdb_list_collections 로 확인)
                query: 찾을 내용을 자연어 문장으로. 사용자의 질문을 그대로 넣어도 된다.
                n_results: 가져올 조각 수 (1~20, 기본 5)
                where: 메타데이터 필터. 예: {"category": "경제"}, {"year": {"$gte": 2024}},
                       {"$and": [{"category": "뉴스"}, {"lang": "ko"}]}
                contains: 본문에 이 문자열이 들어 있는 조각만
            """
            return self.Search(collection=collection, query=query, n_results=n_results, where=where, contains=contains)

        @server.tool(annotations=readOnly)
        def vdb_get_document(collection: str, doc_id: str) -> str:
            """문서 조각 1건의 전체 본문과 메타데이터. 검색 결과가 잘렸거나 앞뒤 맥락이 필요할 때 쓴다."""
            return self.GetDocument(collection=collection, doc_id=doc_id)

        return server

    ## ---- 도구 구현 (텍스트 반환) ----

    def ListCollections(self) -> str:
        collections = self._Request("GET", "/collections")["collections"]
        if not collections:
            return "컬렉션이 없습니다. VDB 웹 화면에서 컬렉션을 만들고 문서를 등록해야 합니다."
        lines = [f"컬렉션 {len(collections)}개:"]
        for col in collections:
            desc = f" — {col['description']}" if col.get("description") else ""
            lines.append(f"- {col['name']}: 문서 {col['count']}건, 모델 {col['model']}, 거리 {col['space']}{desc}")
        return "\n".join(lines)

    def Search(self, collection: str, query: str, n_results: int = 5,
               where: Dict[str, Any] | None = None, contains: str | None = None) -> str:
        nResults = max(1, min(int(n_results), McpDefine.MAX_RESULTS))
        body = {"query": query, "n_results": nResults, "where": where or None, "contains": contains or None}
        result = self._Request("POST", f"/collections/{self._Quote(collection)}/search", body=body)
        hits = result["hits"]
        header = f'검색 "{query}" — 컬렉션 {collection} ({result["model"]}/{result["space"]}), {len(hits)}건'
        if not hits:
            return f"{header}\n조건에 맞는 문서가 없습니다."
        return "\n\n".join([header] + [self._FormatHit(hit) for hit in hits])

    def GetDocument(self, collection: str, doc_id: str) -> str:
        doc = self._Request("GET", f"/collections/{self._Quote(collection)}/documents/{self._Quote(doc_id)}")
        meta = json.dumps(doc.get("metadata") or {}, ensure_ascii=False)
        return f"id: {doc['id']}\nmetadata: {meta}\n\n{doc.get('document') or ''}"

    ## ---- 내부 ----

    @staticmethod
    def _Quote(value: str) -> str:
        from urllib.parse import quote

        return quote(value, safe="")

    @staticmethod
    def _FormatHit(hit: Dict[str, Any]) -> str:
        meta = dict(hit.get("metadata") or {})
        score = f"유사도 {hit['similarity']:.3f}" if hit.get("similarity") is not None else f"거리 {hit['distance']:.4f}"
        labels: List[str] = [f"[{hit['rank']}] id={hit['id']}", score]
        for key in ("title", "source"):
            if meta.get(key):
                labels.append(f"{key}={meta.pop(key)}")
        document = hit.get("document") or ""
        if len(document) > McpDefine.MAX_DOC_CHARS:
            document = document[:McpDefine.MAX_DOC_CHARS] + " …(생략, vdb_get_document 로 전체 조회)"
        metaLine = f"\nmetadata: {json.dumps(meta, ensure_ascii=False)}" if meta else ""
        return f"{' | '.join(labels)}{metaLine}\n{document}"

    def _Request(self, method: str, path: str, body: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """웹 API 호출. 실패는 ToolError 로 던져 메시지가 Claude 에게 그대로 전달되게 한다
        (mcp 2.x 는 일반 예외의 메시지를 숨긴다)."""
        from mcp.server.mcpserver.exceptions import ToolError

        try:
            response = self._httpClient.request(method, f"{McpDefine.API_PREFIX}{path}", json=body)
        except httpx.TransportError as e:
            print(f"[VdbMcpServer] web server unreachable: {e}", file=sys.stderr)
            raise ToolError(f"VDB web server is not reachable at {self._webUrl} ({type(e).__name__}). "
                               f"Start it with scripts\\start_web.ps1") from None
        if response.status_code >= 400:
            try:
                message = response.json()["response"]["message"]
            except Exception:
                message = response.text[:300]
            raise ToolError(f"VDB API error {response.status_code}: {message}")
        return response.json()
