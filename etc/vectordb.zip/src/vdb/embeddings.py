"""다국어(한국어) 임베딩 함수 — PyTorch 없이 onnxruntime + tokenizers 로 동작.

지원 모델 (VDB_EMBED 환경변수 또는 get_embedding_function(name) 인자):
    e5-small : intfloat/multilingual-e5-small  384차원, ONNX ~470MB  (기본값, CPU 에서 가볍고 빠름)
    bge-m3   : BAAI/bge-m3                     1024차원, ONNX ~2.2GB (품질 우선, 느림)
    default  : Chroma 기본 all-MiniLM-L6-v2    384차원, 영어 전용

모델 파일은 최초 사용 시 Hugging Face 캐시(%USERPROFILE%\\.cache\\huggingface\\hub)로 다운로드된다.
폐쇄망에서는 그 폴더를 복사하고 HF_HUB_OFFLINE=1 을 설정하면 된다.

e5 계열은 문서에 "passage: ", 질의에 "query: " 접두어가 필요하다.
Chroma 가 add/upsert 시 __call__, query(query_texts=...) 시 embed_query 를 호출하므로 자동으로 처리된다.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List

import numpy as np
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings, Space
from chromadb.utils.embedding_functions import register_embedding_function

# Windows(개발자 모드 꺼짐)에서는 HF 캐시가 symlink 대신 복사본을 쓴다 — 동작엔 문제 없으므로 경고만 끔
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")


@dataclass(frozen=True)
class ModelSpec:
    repo: str
    dim: int
    pooling: str            # "mean" | "cls"
    query_prefix: str = ""
    passage_prefix: str = ""
    extra_files: tuple[str, ...] = ()


MODELS: Dict[str, ModelSpec] = {
    "e5-small": ModelSpec("intfloat/multilingual-e5-small", 384, "mean", "query: ", "passage: "),
    "bge-m3": ModelSpec("BAAI/bge-m3", 1024, "cls", extra_files=("onnx/model.onnx_data",)),
}


@register_embedding_function
class MultilingualOnnxEmbeddingFunction(EmbeddingFunction[Documents]):
    """한국어 포함 다국어 ONNX 임베딩 함수. 결과 벡터는 L2 정규화됨(cosine/ip 모두 사용 가능)."""

    def __init__(self, model: str = "e5-small", max_length: int = 512, batch_size: int = 32) -> None:
        if model not in MODELS:
            raise ValueError(f"model must be one of {list(MODELS)}, got {model!r}")
        self.model = model
        self.spec = MODELS[model]
        self.max_length = max_length
        self.batch_size = batch_size
        self._session = None
        self._tokenizer = None

    # ---- 지연 로딩 (컬렉션 설정 복원 시 모델을 바로 받지 않도록) ----
    def _load(self) -> None:
        if self._session is not None:
            return
        import onnxruntime as ort
        from huggingface_hub import hf_hub_download
        from tokenizers import Tokenizer

        for f in self.spec.extra_files:
            hf_hub_download(self.spec.repo, f)  # 외부 가중치 파일은 model.onnx 와 같은 폴더에 있어야 함
        model_path = hf_hub_download(self.spec.repo, "onnx/model.onnx")
        tok_path = hf_hub_download(self.spec.repo, "onnx/tokenizer.json")

        tok = Tokenizer.from_file(tok_path)
        tok.enable_truncation(max_length=self.max_length)
        tok.enable_padding()
        so = ort.SessionOptions()
        so.log_severity_level = 3
        self._session = ort.InferenceSession(model_path, so, providers=["CPUExecutionProvider"])
        self._input_names = {i.name for i in self._session.get_inputs()}
        self._tokenizer = tok

    def _embed(self, texts: List[str]) -> Embeddings:
        self._load()
        out: List[np.ndarray] = []
        for start in range(0, len(texts), self.batch_size):
            enc = self._tokenizer.encode_batch(texts[start:start + self.batch_size])
            ids = np.array([e.ids for e in enc], dtype=np.int64)
            mask = np.array([e.attention_mask for e in enc], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask}
            if "token_type_ids" in self._input_names:
                feed["token_type_ids"] = np.zeros_like(ids)
            hidden = self._session.run(None, feed)[0]  # (batch, seq, dim)
            if self.spec.pooling == "cls":
                vec = hidden[:, 0]
            else:
                m = mask[..., None].astype(np.float32)
                vec = (hidden * m).sum(axis=1) / np.clip(m.sum(axis=1), 1e-9, None)
            vec = vec / np.linalg.norm(vec, axis=1, keepdims=True)
            out.extend(vec.astype(np.float32))
        return out

    # ---- Chroma EmbeddingFunction 인터페이스 ----
    def __call__(self, input: Documents) -> Embeddings:
        return self._embed([self.spec.passage_prefix + t for t in input])

    def embed_query(self, input: Documents) -> Embeddings:
        return self._embed([self.spec.query_prefix + t for t in input])

    @staticmethod
    def name() -> str:
        return "vdb-multilingual-onnx"

    def default_space(self) -> Space:
        return "cosine"

    def supported_spaces(self) -> List[Space]:
        return ["cosine", "ip", "l2"]

    def get_config(self) -> Dict[str, Any]:
        return {"model": self.model, "max_length": self.max_length, "batch_size": self.batch_size}

    @staticmethod
    def build_from_config(config: Dict[str, Any]) -> "MultilingualOnnxEmbeddingFunction":
        return MultilingualOnnxEmbeddingFunction(**config)

    def validate_config_update(self, old_config: Dict[str, Any], new_config: Dict[str, Any]) -> None:
        if new_config.get("model", old_config.get("model")) != old_config.get("model"):
            raise ValueError("임베딩 모델은 변경할 수 없습니다(벡터 공간이 달라짐). 새 컬렉션을 만드세요.")


def get_embedding_function(name: str | None = None) -> EmbeddingFunction:
    """VDB_EMBED(기본 e5-small) 에 해당하는 임베딩 함수를 반환."""
    name = (name or os.getenv("VDB_EMBED", "e5-small")).lower()
    if name == "default":
        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
        return DefaultEmbeddingFunction()
    return MultilingualOnnxEmbeddingFunction(model=name)
