"""Chroma 클라이언트 팩토리 (임베디드 / HTTP 공통 진입점)."""
from __future__ import annotations

import chromadb
from chromadb.config import Settings as ChromaSettings

from .config import Settings, load_settings


def get_client(settings: Settings | None = None):
    s = settings or load_settings()
    chroma_settings = ChromaSettings(anonymized_telemetry=False)
    if s.mode == "http":
        return chromadb.HttpClient(host=s.host, port=s.port, settings=chroma_settings)
    s.data_dir.mkdir(parents=True, exist_ok=True)
    return chromadb.PersistentClient(path=str(s.data_dir), settings=chroma_settings)
