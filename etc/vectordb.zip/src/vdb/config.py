"""환경변수 기반 설정.

VDB_MODE      : embedded | http   (기본 embedded)
VDB_DATA_DIR  : 임베디드 모드 / 서버 데이터 경로 (기본 ./data/chroma)
VDB_HOST      : HTTP 서버 호스트 (기본 127.0.0.1)
VDB_PORT      : HTTP 서버 포트   (기본 8000)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    mode: str = "embedded"
    data_dir: Path = PROJECT_ROOT / "data" / "chroma"
    host: str = "127.0.0.1"
    port: int = 8000


def load_settings() -> Settings:
    mode = os.getenv("VDB_MODE", "embedded").lower()
    if mode not in ("embedded", "http"):
        raise ValueError(f"VDB_MODE must be 'embedded' or 'http', got {mode!r}")
    return Settings(
        mode=mode,
        data_dir=Path(os.getenv("VDB_DATA_DIR", str(PROJECT_ROOT / "data" / "chroma"))),
        host=os.getenv("VDB_HOST", "127.0.0.1"),
        port=int(os.getenv("VDB_PORT", "8000")),
    )
