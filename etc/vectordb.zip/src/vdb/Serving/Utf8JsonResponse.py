from fastapi.responses import JSONResponse


class Utf8JsonResponse(JSONResponse):
    """Content-Type 에 charset=utf-8 을 명시한 JSON 응답.

    Windows PowerShell 5.1 의 Invoke-RestMethod 는 charset 이 없으면 ISO-8859-1 로 읽어 한글이 깨진다.
    """

    media_type = "application/json; charset=utf-8"
