from fastapi import APIRouter

from vdb.Serving.Controller.IController import abController
from vdb.Serving.Models.SearchRequest import SearchRequest
from vdb.Serving.Models.SearchResponse import SearchResponse


class SearchController(abController):

    def build(self) -> APIRouter:
        router = APIRouter(prefix="/collections/{name}", tags=["search"])

        @router.post("/search", response_model=SearchResponse, summary="의미 검색")
        def search(name: str, request: SearchRequest):
            return self._vdbService.search(name=name, request=request)

        return router
