from fastapi import APIRouter

from vdb.Serving.Controller.IController import abController
from vdb.Serving.Models.StatusResponse import StatusResponse


class SystemController(abController):

    def build(self) -> APIRouter:
        router = APIRouter(tags=["system"])

        @router.get("/status", response_model=StatusResponse, summary="Chroma 연결 상태·선택 가능한 옵션")
        def get_status():
            return self._vdbService.get_status()

        return router
