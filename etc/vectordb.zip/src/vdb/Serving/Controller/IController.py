from abc import ABC, abstractmethod

from fastapi import APIRouter

from vdb.Serving.Service.VdbService import VdbService


class IController(ABC):

    @abstractmethod
    def build(self) -> APIRouter:
        """엔드포인트를 등록한 APIRouter 를 반환."""
        raise NotImplementedError


class abController(IController, ABC):
    """서비스를 주입받는 컨트롤러 기반 클래스."""

    def __init__(self, vdbService: VdbService):
        self._vdbService = vdbService
