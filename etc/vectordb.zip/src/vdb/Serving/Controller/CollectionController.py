from fastapi import APIRouter

from vdb.Serving.Controller.IController import abController
from vdb.Serving.Models.CollectionCreateRequest import CollectionCreateRequest
from vdb.Serving.Models.CollectionListResponse import CollectionListResponse
from vdb.Serving.Models.CollectionResponse import CollectionResponse
from vdb.Serving.Models.ResponseModel import ResponseModel


class CollectionController(abController):

    def build(self) -> APIRouter:
        router = APIRouter(prefix="/collections", tags=["collections"])

        @router.get("", response_model=CollectionListResponse, summary="컬렉션 목록")
        def list_collections():
            return CollectionListResponse(collections=self._vdbService.list_collections())

        @router.post("", response_model=CollectionResponse, status_code=201, summary="컬렉션 생성")
        def create_collection(request: CollectionCreateRequest):
            return CollectionResponse(collection=self._vdbService.create_collection(request))

        @router.get("/{name}", response_model=CollectionResponse, summary="컬렉션 정보")
        def get_collection(name: str):
            return CollectionResponse(collection=self._vdbService.get_collection_info(name))

        @router.delete("/{name}", response_model=ResponseModel, summary="컬렉션 삭제 (데이터 포함)")
        def delete_collection(name: str):
            self._vdbService.delete_collection(name)
            return ResponseModel()

        return router
