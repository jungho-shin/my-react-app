from fastapi import APIRouter, Query

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Serving.Controller.IController import abController
from vdb.Serving.Models.DocumentAddRequest import DocumentAddRequest
from vdb.Serving.Models.DocumentAddResponse import DocumentAddResponse
from vdb.Serving.Models.DocumentDeleteRequest import DocumentDeleteRequest
from vdb.Serving.Models.DocumentImportRequest import DocumentImportRequest
from vdb.Serving.Models.DocumentListResponse import DocumentListResponse
from vdb.Serving.Models.DocumentRecord import DocumentRecord
from vdb.Serving.Models.DocumentUpdateRequest import DocumentUpdateRequest
from vdb.Serving.Models.ResponseModel import ResponseModel
from vdb.Serving.Models.UrlImportRequest import UrlImportRequest
from vdb.Serving.Models.UrlImportResponse import UrlImportResponse


class DocumentController(abController):

    def build(self) -> APIRouter:
        router = APIRouter(prefix="/collections/{name}/documents", tags=["documents"])

        @router.get("", response_model=DocumentListResponse, summary="문서 목록 (페이지)")
        def list_documents(name: str, offset: int = Query(default=0, ge=0),
                           limit: int = Query(default=20, ge=1, le=ServingDefine.MAX_PAGE_SIZE),
                           contains: str | None = Query(default=None, description="본문 포함 문자열 필터")):
            return self._vdbService.list_documents(name=name, offset=offset, limit=limit, contains=contains or None)

        @router.post("", response_model=DocumentAddResponse, status_code=201, summary="문서 등록")
        def add_documents(name: str, request: DocumentAddRequest):
            ids = self._vdbService.add_documents(name=name, items=[d.model_dump() for d in request.documents])
            return DocumentAddResponse(count=len(ids), ids=ids)

        @router.post("/import", response_model=DocumentAddResponse, status_code=201,
                     summary="파일 내용 일괄 등록 (text | lines | jsonl | csv | html)")
        def import_documents(name: str, request: DocumentImportRequest):
            ids = self._vdbService.import_documents(name=name, request=request)
            return DocumentAddResponse(count=len(ids), ids=ids)

        @router.post("/url", response_model=UrlImportResponse, status_code=201,
                     summary="웹페이지 링크로 등록 (본문 추출 → 청크 분할)")
        def import_url(name: str, request: UrlImportRequest):
            return self._vdbService.import_url(name=name, request=request)

        @router.post("/delete", response_model=DocumentAddResponse, summary="여러 문서 삭제")
        def delete_documents(name: str, request: DocumentDeleteRequest):
            deleted = self._vdbService.delete_documents(name=name, ids=request.ids)
            return DocumentAddResponse(count=deleted)

        @router.get("/{doc_id:path}", response_model=DocumentRecord, summary="문서 1건 조회")
        def get_document(name: str, doc_id: str):
            return self._vdbService.get_document(name=name, doc_id=doc_id)

        @router.put("/{doc_id:path}", response_model=DocumentRecord, summary="문서 수정 (벡터 재계산)")
        def update_document(name: str, doc_id: str, request: DocumentUpdateRequest):
            return self._vdbService.update_document(name=name, doc_id=doc_id, request=request)

        @router.delete("/{doc_id:path}", response_model=ResponseModel, summary="문서 1건 삭제")
        def delete_document(name: str, doc_id: str):
            if not self._vdbService.delete_documents(name=name, ids=[doc_id]):
                raise LookupError(f"Document not found: {doc_id}")
            return ResponseModel()

        return router
