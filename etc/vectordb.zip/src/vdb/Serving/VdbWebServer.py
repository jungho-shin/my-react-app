"""FastAPI 웹 서버 조립 (API + 정적 프런트엔드).

※ serving 영역은 컨벤션 11절에 따라 snake_case 메서드를 쓴다.
"""
from typing import List

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError

from vdb.Config.VdbConfigHelper import VdbConfigHelper
from vdb.Defines.ServingDefine import ServingDefine
from vdb.Dtos.VdbSettingsDto import VdbSettingsDto
from vdb.Serving.Controller.CollectionController import CollectionController
from vdb.Serving.Controller.DocumentController import DocumentController
from vdb.Serving.Controller.IController import IController
from vdb.Serving.Controller.SearchController import SearchController
from vdb.Serving.Controller.SystemController import SystemController
from vdb.Serving.Models.ResponseHeader import ResponseHeader
from vdb.Serving.Models.ResponseModel import ResponseModel
from vdb.Serving.Service.VdbConflictError import VdbConflictError
from vdb.Serving.Service.VdbService import VdbService
from vdb.Serving.Utf8JsonResponse import Utf8JsonResponse


class VdbWebServer:
    """사용 예:
        app = VdbWebServer().build()                 # 환경변수(VDB_MODE 등)로 Chroma 접속
        app = VdbWebServer(settings=..., default_model="e5-small").build()
    """

    def __init__(self, settings: VdbSettingsDto | None = None, default_model: str | None = None,
                 serve_frontend: bool = True):
        self._settings = settings or VdbConfigHelper.LoadSettings()
        self._vdbService = VdbService(settings=self._settings,
                                      default_model=default_model or VdbConfigHelper.GetEmbeddingModelName())
        self._serveFrontend = serve_frontend
        self._controllers: List[IController] = []

    def get_service(self) -> VdbService:
        return self._vdbService

    def add_controller(self, controller: IController) -> "VdbWebServer":
        self._controllers.append(controller)
        return self

    def build(self) -> FastAPI:
        app = FastAPI(title=ServingDefine.APP_TITLE, docs_url=f"{ServingDefine.API_PREFIX}/docs",
                      openapi_url=f"{ServingDefine.API_PREFIX}/openapi.json",
                      default_response_class=Utf8JsonResponse)

        if not self._controllers:
            self.add_controller(SystemController(self._vdbService)) \
                .add_controller(CollectionController(self._vdbService)) \
                .add_controller(DocumentController(self._vdbService)) \
                .add_controller(SearchController(self._vdbService))
        for controller in self._controllers:
            app.include_router(controller.build(), prefix=ServingDefine.API_PREFIX)

        self._register_exception_handlers(app)

        ## API 라우트 뒤에 마운트해야 /api/* 가 정적 파일보다 우선한다
        if self._serveFrontend:
            from fastapi.staticfiles import StaticFiles

            app.mount("/", StaticFiles(directory=ServingDefine.FRONTEND_DIR, html=True), name="frontend")
        return app

    ## ---- 예외 → JSON 응답 ----

    @staticmethod
    def _error_response(status_code: int, code: str, message: str) -> Utf8JsonResponse:
        body = ResponseModel(response=ResponseHeader(code=code, message=message))
        return Utf8JsonResponse(status_code=status_code, content=body.model_dump())

    def _register_exception_handlers(self, app: FastAPI):
        import chromadb.errors as chromaErrors
        import httpx

        codes = ServingDefine.E_RESULT_CODE

        @app.exception_handler(RequestValidationError)
        async def on_validation_error(request: Request, exc: RequestValidationError):
            messages = [f"{'.'.join(str(p) for p in err.get('loc', [])[1:])}: {err.get('msg')}" for err in exc.errors()]
            return self._error_response(400, codes.BAD_REQUEST, "; ".join(messages))

        @app.exception_handler(chromaErrors.NotFoundError)
        @app.exception_handler(LookupError)
        async def on_not_found(request: Request, exc: Exception):
            return self._error_response(404, codes.NOT_FOUND, str(exc))

        @app.exception_handler(VdbConflictError)
        async def on_conflict(request: Request, exc: VdbConflictError):
            return self._error_response(409, codes.CONFLICT, str(exc))

        @app.exception_handler(chromaErrors.InvalidArgumentError)
        @app.exception_handler(ValueError)
        async def on_bad_request(request: Request, exc: Exception):
            return self._error_response(400, codes.BAD_REQUEST, str(exc))

        @app.exception_handler(ConnectionError)
        @app.exception_handler(httpx.TransportError)
        async def on_upstream_down(request: Request, exc: Exception):
            self._vdbService.reset_client()
            return self._error_response(503, codes.UPSTREAM_ERROR, f"Chroma server unavailable: {exc}")

        @app.exception_handler(chromaErrors.ChromaError)
        async def on_chroma_error(request: Request, exc: Exception):
            return self._error_response(502, codes.UPSTREAM_ERROR, f"{type(exc).__name__}: {exc}")
