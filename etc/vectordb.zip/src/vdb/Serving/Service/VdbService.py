"""웹 백엔드의 Chroma 작업 서비스.

※ serving 영역(Controller/Service/Server)은 컨벤션 11절에 따라 snake_case 메서드를 쓴다.
"""
import hashlib
import threading
import time
import uuid
from typing import Any, Dict, List
from urllib.parse import urlsplit

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Defines.ServingDefine import ServingDefine
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Dtos.VdbSettingsDto import VdbSettingsDto
from vdb.Embedding.MultilingualOnnxEmbeddingFunction import MultilingualOnnxEmbeddingFunction
from vdb.Factory.EmbeddingFunctionFactory import EmbeddingFunctionFactory
from vdb.Factory.VdbClientFactory import VdbClientFactory
from vdb.Serving.Models.CollectionCreateRequest import CollectionCreateRequest
from vdb.Serving.Models.CollectionInfo import CollectionInfo
from vdb.Serving.Models.DocumentImportRequest import DocumentImportRequest
from vdb.Serving.Models.DocumentListResponse import DocumentListResponse
from vdb.Serving.Models.DocumentRecord import DocumentRecord
from vdb.Serving.Models.DocumentUpdateRequest import DocumentUpdateRequest
from vdb.Serving.Models.SearchHit import SearchHit
from vdb.Serving.Models.SearchRequest import SearchRequest
from vdb.Serving.Models.SearchResponse import SearchResponse
from vdb.Serving.Models.StatusResponse import StatusResponse
from vdb.Serving.Models.UrlImportRequest import UrlImportRequest
from vdb.Serving.Models.UrlImportResponse import UrlImportResponse
from vdb.Serving.Service.VdbConflictError import VdbConflictError
from vdb.Utils.DocumentImportHelper import DocumentImportHelper
from vdb.Utils.MetadataHelper import MetadataHelper
from vdb.Utils.TextChunkHelper import TextChunkHelper
from vdb.Utils.WebPageFetcher import WebPageFetcher


class VdbService:
    """컬렉션·문서·검색 기능. Chroma 클라이언트는 처음 필요할 때 연결한다."""

    MODELS = [EmbeddingDefine.E_MODEL.E5_SMALL, EmbeddingDefine.E_MODEL.BGE_M3, EmbeddingDefine.E_MODEL.DEFAULT]
    SPACES = [VdbDefine.E_SPACE.COSINE, VdbDefine.E_SPACE.L2, VdbDefine.E_SPACE.IP]
    IMPORT_FORMATS = [ServingDefine.E_IMPORT_FORMAT.TEXT, ServingDefine.E_IMPORT_FORMAT.LINES,
                      ServingDefine.E_IMPORT_FORMAT.JSONL, ServingDefine.E_IMPORT_FORMAT.CSV,
                      ServingDefine.E_IMPORT_FORMAT.HTML]
    DESCRIPTION_KEY = "description"
    MODEL_NONE = "none"

    def __init__(self, settings: VdbSettingsDto, default_model: str):
        self._settings = settings
        self._defaultModel = default_model
        self._client = None
        self._clientLock = threading.Lock()

    ## ---- 내부 ----

    def _get_client(self):
        with self._clientLock:
            if self._client is None:
                try:
                    self._client = VdbClientFactory.CreateClient(self._settings)
                except Exception as e:
                    ## HttpClient 는 서버가 없으면 ValueError 를 던지므로 400 으로 오인되지 않게 바꾼다
                    raise ConnectionError(f"Cannot connect to chroma ({self._settings.GetTarget()}): {e}") from None
                print(f"[VdbService] Connected to chroma ({self._settings})")
            return self._client

    def reset_client(self):
        """연결 오류 후 다음 요청에서 다시 연결하도록 클라이언트를 버린다."""
        self._reset_client()

    def _reset_client(self):
        with self._clientLock:
            self._client = None

    def _get_collection(self, name: str):
        ## 저장된 설정의 임베딩 함수가 자동으로 복원된다 (vdb.Embedding 모듈 import 로 등록됨)
        return self._get_client().get_collection(name)

    @staticmethod
    def _get_model_name(collection) -> str:
        embeddingFunction = collection.configuration.get("embedding_function")
        if embeddingFunction is None:
            return VdbService.MODEL_NONE
        if isinstance(embeddingFunction, MultilingualOnnxEmbeddingFunction):
            return embeddingFunction.GetModelName()
        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

        if isinstance(embeddingFunction, DefaultEmbeddingFunction):
            return EmbeddingDefine.E_MODEL.DEFAULT
        return embeddingFunction.name()

    @staticmethod
    def _get_space(collection) -> str:
        configuration = collection.configuration
        for indexKey in ("hnsw", "spann"):
            indexConfig = configuration.get(indexKey) or {}
            if indexConfig.get("space"):
                return indexConfig["space"]
        return VdbDefine.E_SPACE.L2

    @staticmethod
    def _to_info(collection) -> CollectionInfo:
        metadata = collection.metadata or {}
        return CollectionInfo(name=collection.name, count=collection.count(),
                              model=VdbService._get_model_name(collection),
                              space=VdbService._get_space(collection),
                              description=str(metadata.get(VdbService.DESCRIPTION_KEY, "")))

    @staticmethod
    def _new_id() -> str:
        return uuid.uuid4().hex[:16]

    ## ---- 상태 ----

    def get_status(self) -> StatusResponse:
        chromaOk, version = True, ""
        try:
            client = self._get_client()
            client.heartbeat()
            version = client.get_version()
        except Exception as e:
            print(f"[VdbService] chroma unavailable: {type(e).__name__}: {e}")
            self._reset_client()
            chromaOk = False
        return StatusResponse(chroma_ok=chromaOk, chroma_mode=self._settings.GetMode(),
                              chroma_target=self._settings.GetTarget(), chroma_version=version,
                              models=self.MODELS, default_model=self._defaultModel, spaces=self.SPACES,
                              import_formats=self.IMPORT_FORMATS)

    ## ---- 컬렉션 ----

    def list_collections(self) -> List[CollectionInfo]:
        collections = self._get_client().list_collections()
        return sorted((self._to_info(c) for c in collections), key=lambda info: info.name)

    def get_collection_info(self, name: str) -> CollectionInfo:
        return self._to_info(self._get_collection(name))

    def create_collection(self, request: CollectionCreateRequest) -> CollectionInfo:
        if request.model not in self.MODELS:
            raise ValueError(f"Unknown model: {request.model!r} (available: {self.MODELS})")
        if request.space not in self.SPACES:
            raise ValueError(f"Unknown space: {request.space!r} (available: {self.SPACES})")

        client = self._get_client()
        if request.name in [c.name for c in client.list_collections()]:
            raise VdbConflictError(f"Collection already exists: {request.name}")

        metadata = {self.DESCRIPTION_KEY: request.description} if request.description else None
        collection = client.create_collection(
            request.name, metadata=metadata,
            embedding_function=EmbeddingFunctionFactory.CreateEmbeddingFunction(request.model),
            configuration={"hnsw": {"space": request.space}})
        print(f"[VdbService] Created collection {request.name} (model={request.model}, space={request.space})")
        return self._to_info(collection)

    def delete_collection(self, name: str):
        self._get_collection(name)  # 없으면 NotFoundError
        self._get_client().delete_collection(name)
        print(f"[VdbService] Deleted collection {name}")

    ## ---- 문서 ----

    def add_documents(self, name: str, items: List[Dict[str, Any]],
                      common_metadata: Dict[str, Any] | None = None) -> List[str]:
        """items: [{"id"?, "document", "metadata"?}, ...] 를 배치로 나눠 등록하고 id 목록을 반환."""
        if not items:
            raise ValueError("No documents to add")
        if len(items) > ServingDefine.MAX_IMPORT_ITEMS:
            raise ValueError(f"Too many documents: {len(items)} (max {ServingDefine.MAX_IMPORT_ITEMS})")

        collection = self._get_collection(name)

        ## 1) 정리·검증
        ids, documents, metadatas = [], [], []
        for index, item in enumerate(items):
            document = (item.get("document") or "").strip()
            if not document:
                raise ValueError(f"Document #{index + 1} is empty")
            ids.append(str(item.get("id") or "").strip() or self._new_id())
            documents.append(document)
            metadatas.append(MetadataHelper.Normalize(MetadataHelper.Merge(common_metadata, item.get("metadata"))))

        ## 2) ID 중복 검사 (Chroma 의 add 는 기존 ID 를 조용히 무시하므로 미리 막는다)
        if len(set(ids)) != len(ids):
            duplicated = sorted({docId for docId in ids if ids.count(docId) > 1})
            raise ValueError(f"Duplicate ids in request: {duplicated[:10]}")
        existing = []
        for start in range(0, len(ids), ServingDefine.MAX_PAGE_SIZE):
            existing += collection.get(ids=ids[start:start + ServingDefine.MAX_PAGE_SIZE], include=[])["ids"]
        if existing:
            raise VdbConflictError(f"Ids already exist: {existing[:10]}")

        ## 3) 배치 등록 (임베딩 계산 포함)
        batchSize = ServingDefine.ADD_BATCH_SIZE
        for start in range(0, len(ids), batchSize):
            end = start + batchSize
            collection.add(ids=ids[start:end], documents=documents[start:end], metadatas=metadatas[start:end])
        print(f"[VdbService] Added {len(ids)} documents to {name}")
        return ids

    def import_documents(self, name: str, request: DocumentImportRequest) -> List[str]:
        if request.chunk_overlap >= request.chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        items = DocumentImportHelper.Parse(content=request.content, import_format=request.format,
                                           source_name=request.source_name, chunk_size=request.chunk_size,
                                           chunk_overlap=request.chunk_overlap)
        if not items:
            raise ValueError("No documents found in the file")
        return self.add_documents(name=name, items=items, common_metadata=MetadataHelper.Normalize(request.metadata))

    def import_url(self, name: str, request: UrlImportRequest) -> UrlImportResponse:
        """웹페이지 본문을 가져와 청크로 등록. 같은 URL 은 replace=True 일 때만 다시 등록한다."""
        if request.chunk_overlap >= request.chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        collection = self._get_collection(name)  # 페이지를 받기 전에 컬렉션 존재 확인
        userMetadata = MetadataHelper.Normalize(request.metadata) or {}

        ## 1) 페이지 가져오기 → 청크 분할
        page = WebPageFetcher.Fetch(request.url)
        url = page.GetUrl()
        chunks = TextChunkHelper.Split(text=page.GetText(), chunk_size=request.chunk_size,
                                       chunk_overlap=request.chunk_overlap)

        ## 2) 같은 URL 은 같은 ID 가 되도록 (url-<해시>-<번호>)
        metaKey = ServingDefine.E_META_KEY
        urlHash = hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
        baseMetadata = {metaKey.TITLE: page.GetTitle()[:500], metaKey.DOMAIN: urlsplit(url).hostname,
                        metaKey.FETCHED_DATE: int(time.strftime("%Y%m%d")), **userMetadata}
        items = [{"id": f"{ServingDefine.URL_ID_PREFIX}-{urlHash}-{index:04d}", "document": chunk,
                  "metadata": {**baseMetadata, metaKey.SOURCE: url, metaKey.CHUNK_INDEX: index}}
                 for index, chunk in enumerate(chunks)]

        ## 3) 기존 등록분 처리
        existing = collection.get(where={metaKey.SOURCE: url}, include=[])["ids"]
        if existing and not request.replace:
            raise VdbConflictError(f"This URL is already registered ({len(existing)} chunks). "
                                   f"Enable 'replace' to fetch it again.")
        if existing:
            collection.delete(ids=existing)
            print(f"[VdbService] Removed {len(existing)} old chunks of {url}")

        ids = self.add_documents(name=name, items=items)
        return UrlImportResponse(count=len(ids), ids=ids, url=url, title=baseMetadata[metaKey.TITLE],
                                 chars=len(page.GetText()), replaced=len(existing))

    def list_documents(self, name: str, offset: int, limit: int, contains: str | None = None) -> DocumentListResponse:
        collection = self._get_collection(name)
        whereDocument = {"$contains": contains} if contains else None
        result = collection.get(offset=offset, limit=limit, where_document=whereDocument,
                                include=["documents", "metadatas"])
        ## 필터가 있으면 전체 개수를 따로 세야 한다 (ID 만 조회)
        total = len(collection.get(where_document=whereDocument, include=[])["ids"]) if contains \
            else collection.count()
        documents = [DocumentRecord(id=docId, document=doc, metadata=meta)
                     for docId, doc, meta in zip(result["ids"], result["documents"], result["metadatas"])]
        return DocumentListResponse(total=total, offset=offset, limit=limit, documents=documents)

    def get_document(self, name: str, doc_id: str) -> DocumentRecord:
        result = self._get_collection(name).get(ids=[doc_id], include=["documents", "metadatas"])
        if not result["ids"]:
            raise LookupError(f"Document not found: {doc_id}")
        return DocumentRecord(id=doc_id, document=result["documents"][0], metadata=result["metadatas"][0])

    def update_document(self, name: str, doc_id: str, request: DocumentUpdateRequest) -> DocumentRecord:
        current = self.get_document(name=name, doc_id=doc_id)
        newMetadata = MetadataHelper.Normalize(request.metadata) or {}

        ## Chroma 의 update 는 메타데이터를 병합하므로, 빠진 키는 None 으로 보내 삭제한다
        removedKeys = set(current.metadata or {}) - set(newMetadata)
        patch = {**newMetadata, **{key: None for key in removedKeys}}
        self._get_collection(name).update(ids=[doc_id], documents=[request.document.strip()],
                                          metadatas=[patch] if patch else None)
        return self.get_document(name=name, doc_id=doc_id)

    def delete_documents(self, name: str, ids: List[str]) -> int:
        collection = self._get_collection(name)
        existing = collection.get(ids=ids, include=[])["ids"]
        if existing:
            collection.delete(ids=existing)
        print(f"[VdbService] Deleted {len(existing)} documents from {name}")
        return len(existing)

    ## ---- 검색 ----

    def search(self, name: str, request: SearchRequest) -> SearchResponse:
        collection = self._get_collection(name)
        space = self._get_space(collection)
        model = self._get_model_name(collection)
        if model == self.MODEL_NONE:
            raise ValueError(f"Collection {name} has no embedding function; text search is not possible")

        started = time.perf_counter()
        hits = []
        count = collection.count()
        if count:
            result = collection.query(
                query_texts=[request.query.strip()], n_results=min(request.n_results, count),
                where=request.where or None,
                where_document={"$contains": request.contains} if request.contains else None,
                include=["documents", "metadatas", "distances"])
            for rank, (docId, doc, meta, distance) in enumerate(zip(
                    result["ids"][0], result["documents"][0], result["metadatas"][0], result["distances"][0]),
                    start=1):
                similarity = 1.0 - distance if space == VdbDefine.E_SPACE.COSINE else None
                hits.append(SearchHit(rank=rank, id=docId, document=doc, metadata=meta,
                                      distance=float(distance), similarity=similarity))
        elapsedMs = (time.perf_counter() - started) * 1000
        return SearchResponse(query=request.query, space=space, model=model,
                              elapsed_ms=round(elapsedMs, 1), hits=hits)
