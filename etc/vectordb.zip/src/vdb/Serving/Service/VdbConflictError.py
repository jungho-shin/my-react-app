class VdbConflictError(Exception):
    """이미 존재하는 컬렉션·문서 ID 와 충돌 (HTTP 409 로 변환)."""
