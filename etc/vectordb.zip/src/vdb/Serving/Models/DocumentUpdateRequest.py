from typing import Any, Dict

from pydantic import Field

from vdb.Serving.Models.RequestModel import RequestModel


class DocumentUpdateRequest(RequestModel):
    """문서 본문·메타데이터 교체 (본문이 바뀌면 벡터도 다시 계산)."""

    document: str = Field(min_length=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)
