from typing import List

from vdb.Serving.Models.ResponseModel import ResponseModel


class DocumentAddResponse(ResponseModel):
    count: int
    ids: List[str] = []
