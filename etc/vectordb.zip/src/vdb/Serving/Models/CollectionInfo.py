from pydantic import BaseModel


class CollectionInfo(BaseModel):
    name: str
    count: int
    model: str
    space: str
    description: str = ""
