from typing import List

from vdb.Serving.Models.DocumentRecord import DocumentRecord
from vdb.Serving.Models.ResponseModel import ResponseModel


class DocumentListResponse(ResponseModel):
    total: int
    offset: int
    limit: int
    documents: List[DocumentRecord] = []
