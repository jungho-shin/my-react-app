from typing import List

from vdb.Serving.Models.CollectionInfo import CollectionInfo
from vdb.Serving.Models.ResponseModel import ResponseModel


class CollectionListResponse(ResponseModel):
    collections: List[CollectionInfo] = []
