from vdb.Serving.Models.CollectionInfo import CollectionInfo
from vdb.Serving.Models.ResponseModel import ResponseModel


class CollectionResponse(ResponseModel):
    collection: CollectionInfo
