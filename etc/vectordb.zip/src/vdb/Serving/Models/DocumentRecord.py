from typing import Any, Dict

from pydantic import BaseModel


class DocumentRecord(BaseModel):
    id: str
    document: str | None = None
    metadata: Dict[str, Any] | None = None
