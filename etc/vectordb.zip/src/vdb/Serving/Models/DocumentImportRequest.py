from typing import Any, Dict

from pydantic import Field

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Serving.Models.RequestModel import RequestModel


class DocumentImportRequest(RequestModel):
    """파일 내용(텍스트)을 서버에서 파싱해 일괄 등록."""

    format: str = Field(description="text | lines | jsonl | csv | html")
    content: str = Field(min_length=1)
    source_name: str | None = Field(default=None, max_length=256, description="메타데이터 source 로 저장")
    chunk_size: int = Field(default=ServingDefine.DEFAULT_CHUNK_SIZE, ge=50, le=8000)
    chunk_overlap: int = Field(default=ServingDefine.DEFAULT_CHUNK_OVERLAP, ge=0, le=2000)
    metadata: Dict[str, Any] = Field(default_factory=dict, description="모든 문서에 공통으로 붙일 메타데이터")
