from pydantic import BaseModel, ConfigDict


class RequestModel(BaseModel):
    """요청 모델 기반 클래스. 정의되지 않은 필드는 거부한다(오타 조기 발견)."""

    model_config = ConfigDict(extra="forbid")
