from typing import Any, Dict

from pydantic import BaseModel


class SearchHit(BaseModel):
    rank: int
    id: str
    document: str | None = None
    metadata: Dict[str, Any] | None = None
    distance: float
    similarity: float | None = None  # cosine 공간일 때만 (1 - distance)
