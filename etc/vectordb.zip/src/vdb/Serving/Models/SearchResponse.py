from typing import List

from vdb.Serving.Models.ResponseModel import ResponseModel
from vdb.Serving.Models.SearchHit import SearchHit


class SearchResponse(ResponseModel):
    query: str
    space: str
    model: str
    elapsed_ms: float
    hits: List[SearchHit] = []
