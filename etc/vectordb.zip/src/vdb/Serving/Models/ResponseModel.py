from pydantic import BaseModel, Field

from vdb.Serving.Models.ResponseHeader import ResponseHeader


class ResponseModel(BaseModel):
    """응답 모델 기반 클래스."""

    response: ResponseHeader = Field(default_factory=ResponseHeader)
