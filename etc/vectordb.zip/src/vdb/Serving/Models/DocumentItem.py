from typing import Any, Dict

from pydantic import Field

from vdb.Serving.Models.RequestModel import RequestModel


class DocumentItem(RequestModel):
    """등록할 문서 1건. id 를 비우면 서버가 생성한다."""

    id: str | None = Field(default=None, max_length=256)
    document: str = Field(min_length=1)
    metadata: Dict[str, Any] = Field(default_factory=dict, description="값은 str / int / float / bool")
