from typing import Any, Dict

from pydantic import Field

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Serving.Models.RequestModel import RequestModel


class SearchRequest(RequestModel):
    query: str = Field(min_length=1)
    n_results: int = Field(default=5, ge=1, le=ServingDefine.MAX_N_RESULTS)
    where: Dict[str, Any] | None = Field(default=None, description='메타데이터 필터, 예: {"category": "경제"}')
    contains: str | None = Field(default=None, description="본문에 이 문자열이 포함된 문서만")
