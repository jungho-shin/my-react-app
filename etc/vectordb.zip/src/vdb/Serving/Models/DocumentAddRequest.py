from typing import List

from pydantic import Field

from vdb.Serving.Models.DocumentItem import DocumentItem
from vdb.Serving.Models.RequestModel import RequestModel


class DocumentAddRequest(RequestModel):
    documents: List[DocumentItem] = Field(min_length=1)
