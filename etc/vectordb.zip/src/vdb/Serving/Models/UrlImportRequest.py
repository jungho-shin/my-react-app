from typing import Any, Dict

from pydantic import Field

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Serving.Models.RequestModel import RequestModel


class UrlImportRequest(RequestModel):
    """웹페이지를 가져와 본문을 청크로 나눠 등록."""

    url: str = Field(min_length=4, max_length=2048)
    chunk_size: int = Field(default=ServingDefine.DEFAULT_CHUNK_SIZE, ge=50, le=8000)
    chunk_overlap: int = Field(default=ServingDefine.DEFAULT_CHUNK_OVERLAP, ge=0, le=2000)
    metadata: Dict[str, Any] = Field(default_factory=dict, description="모든 청크에 붙일 메타데이터 (title 지정 시 자동 제목 대신 사용)")
    replace: bool = Field(default=False, description="같은 URL 로 등록된 기존 청크를 지우고 다시 등록")
