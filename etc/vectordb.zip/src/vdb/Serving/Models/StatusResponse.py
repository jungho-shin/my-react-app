from typing import List

from vdb.Serving.Models.ResponseModel import ResponseModel


class StatusResponse(ResponseModel):
    chroma_ok: bool
    chroma_mode: str
    chroma_target: str
    chroma_version: str = ""
    models: List[str] = []
    default_model: str
    spaces: List[str] = []
    import_formats: List[str] = []
