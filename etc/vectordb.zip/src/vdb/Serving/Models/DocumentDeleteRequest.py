from typing import List

from pydantic import Field

from vdb.Serving.Models.RequestModel import RequestModel


class DocumentDeleteRequest(RequestModel):
    ids: List[str] = Field(min_length=1)
