from pydantic import Field

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Serving.Models.RequestModel import RequestModel


class CollectionCreateRequest(RequestModel):
    name: str = Field(min_length=3, max_length=512, pattern=r"^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?$",
                      description="3~512자, [a-zA-Z0-9._-], 영숫자로 시작·끝")
    model: str = Field(default=EmbeddingDefine.E_MODEL.E5_SMALL, description="e5-small | bge-m3 | default")
    space: str = Field(default=VdbDefine.E_SPACE.COSINE, description="cosine | l2 | ip")
    description: str = Field(default="", max_length=1000)
