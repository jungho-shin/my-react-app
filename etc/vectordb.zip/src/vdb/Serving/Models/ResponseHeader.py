from pydantic import BaseModel

from vdb.Defines.ServingDefine import ServingDefine


class ResponseHeader(BaseModel):
    """모든 응답에 포함되는 결과 헤더."""

    code: str = ServingDefine.E_RESULT_CODE.OK
    message: str = ""
