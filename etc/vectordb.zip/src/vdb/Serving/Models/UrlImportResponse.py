from vdb.Serving.Models.DocumentAddResponse import DocumentAddResponse


class UrlImportResponse(DocumentAddResponse):
    url: str
    title: str
    chars: int
    replaced: int = 0  # replace=true 로 지운 기존 청크 수
