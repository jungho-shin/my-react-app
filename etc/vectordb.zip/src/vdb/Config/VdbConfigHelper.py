"""환경변수 기반 설정 읽기.

    VDB_MODE      : embedded | http   (기본 embedded)
    VDB_DATA_DIR  : 임베디드 모드 / 서버 데이터 경로 (기본 ./data/chroma)
    VDB_HOST      : HTTP 서버 호스트 (기본 127.0.0.1)
    VDB_PORT      : HTTP 서버 포트   (기본 8000)
    VDB_EMBED     : 임베딩 모델     (기본 e5-small)
"""
import os

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Dtos.VdbSettingsDto import VdbSettingsDto


class VdbConfigHelper:

    @staticmethod
    def LoadSettings() -> VdbSettingsDto:
        """환경변수에서 접속 설정을 읽어 VdbSettingsDto 로 반환."""
        mode = os.getenv(VdbDefine.E_ENV.VDB_MODE, VdbDefine.E_MODE.EMBEDDED).lower()
        if mode not in (VdbDefine.E_MODE.EMBEDDED, VdbDefine.E_MODE.HTTP):
            raise ValueError(f"{VdbDefine.E_ENV.VDB_MODE} must be "
                             f"'{VdbDefine.E_MODE.EMBEDDED}' or '{VdbDefine.E_MODE.HTTP}', got {mode!r}")

        return VdbSettingsDto().SetDTO(
            mode=mode,
            data_dir=os.getenv(VdbDefine.E_ENV.VDB_DATA_DIR, str(VdbDefine.DEFAULT_DATA_DIR)),
            host=os.getenv(VdbDefine.E_ENV.VDB_HOST, VdbDefine.DEFAULT_HOST),
            port=int(os.getenv(VdbDefine.E_ENV.VDB_PORT, str(VdbDefine.DEFAULT_PORT))),
        )

    @staticmethod
    def GetEmbeddingModelName() -> str:
        return os.getenv(VdbDefine.E_ENV.VDB_EMBED, EmbeddingDefine.E_MODEL.E5_SMALL).lower()
