from typing import Tuple

from vdb.Dtos.IDto import IDTO


class EmbeddingModelSpecDto(IDTO):
    """ONNX 임베딩 모델 사양 (HF 저장소·차원·풀링·접두어)."""

    def __init__(self):
        super().__init__()
        self._repo = None
        self._dim = None
        self._pooling = None
        self._queryPrefix = None
        self._passagePrefix = None
        self._extraFiles = None

    def SetDTO(self, repo: str, dim: int, pooling: str, query_prefix: str = "", passage_prefix: str = "",
               extra_files: Tuple[str, ...] = ()) -> "EmbeddingModelSpecDto":
        self._repo = repo
        self._dim = dim
        self._pooling = pooling
        self._queryPrefix = query_prefix
        self._passagePrefix = passage_prefix
        self._extraFiles = tuple(extra_files)
        return self

    def GetRepo(self) -> str:
        return self._repo

    def GetDim(self) -> int:
        return self._dim

    def GetPooling(self) -> str:
        return self._pooling

    def GetQueryPrefix(self) -> str:
        return self._queryPrefix

    def GetPassagePrefix(self) -> str:
        return self._passagePrefix

    def GetExtraFiles(self) -> Tuple[str, ...]:
        """model.onnx 와 같은 폴더에 있어야 하는 외부 가중치 파일 목록."""
        return self._extraFiles

    def __repr__(self) -> str:
        return f"EmbeddingModelSpecDto(repo={self._repo}, dim={self._dim}, pooling={self._pooling})"
