from vdb.Dtos.IDto import IDTO


class WebPageDto(IDTO):
    """가져온 웹페이지 (최종 URL·제목·본문 텍스트)."""

    def __init__(self):
        super().__init__()
        self._url = None
        self._title = None
        self._text = None
        self._contentType = None

    def SetDTO(self, url: str, title: str, text: str, content_type: str) -> "WebPageDto":
        self._url = url
        self._title = title
        self._text = text
        self._contentType = content_type
        return self

    def GetUrl(self) -> str:
        return self._url

    def GetTitle(self) -> str:
        return self._title

    def GetText(self) -> str:
        return self._text

    def GetContentType(self) -> str:
        return self._contentType

    def __repr__(self) -> str:
        return f"WebPageDto(url={self._url}, title={self._title!r}, chars={len(self._text or '')})"
