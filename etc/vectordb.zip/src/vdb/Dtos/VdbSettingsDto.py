from pathlib import Path

from vdb.Defines.VdbDefine import VdbDefine
from vdb.Dtos.IDto import IDTO


class VdbSettingsDto(IDTO):
    """Chroma 접속 설정 (모드·데이터 경로·호스트·포트)."""

    def __init__(self):
        super().__init__()
        self._mode = None
        self._dataDir = None
        self._host = None
        self._port = None

    def SetDTO(self, mode: str, data_dir: Path, host: str, port: int) -> "VdbSettingsDto":
        self._mode = mode
        self._dataDir = Path(data_dir)
        self._host = host
        self._port = port
        return self

    def GetMode(self) -> str:
        return self._mode

    def GetDataDir(self) -> Path:
        return self._dataDir

    def GetHost(self) -> str:
        return self._host

    def GetPort(self) -> int:
        return self._port

    def IsHttpMode(self) -> bool:
        return self._mode == VdbDefine.E_MODE.HTTP

    def GetTarget(self) -> str:
        """접속 대상 표시용 문자열 (임베디드: 데이터 경로, HTTP: host:port)."""
        return f"{self._host}:{self._port}" if self.IsHttpMode() else str(self._dataDir)

    def __repr__(self) -> str:
        return f"VdbSettingsDto(mode={self._mode}, target={self.GetTarget()})"
