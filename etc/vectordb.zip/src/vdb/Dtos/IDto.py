from abc import ABC


class IDTO(ABC):
    """DTO 공통 인터페이스 (Haerujil24 common_lib.Dtos.IDto 와 같은 모양)."""
