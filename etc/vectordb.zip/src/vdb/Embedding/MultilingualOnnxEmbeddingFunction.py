"""한국어 포함 다국어 ONNX 임베딩 함수 (Chroma EmbeddingFunction 구현).

지원 모델 (EmbeddingDefine.E_MODEL):
    e5-small : intfloat/multilingual-e5-small  384차원, ONNX ~470MB  (기본값)
    bge-m3   : BAAI/bge-m3                     1024차원, ONNX ~2.2GB (품질 우선, 느림)

e5 계열은 문서에 "passage: ", 질의에 "query: " 접두어가 필요하다.
Chroma 가 add/upsert 시 __call__, query(query_texts=...) 시 embed_query 를 호출하므로 자동으로 처리된다.

※ __call__ / embed_query / name / get_config / build_from_config 등은 Chroma 가 정한
  인터페이스 이름이므로 컨벤션(PascalCase)의 예외로 그대로 둔다.
"""
from typing import Any, Dict, List

from chromadb.api.types import Documents, EmbeddingFunction, Embeddings, Space
from chromadb.utils.embedding_functions import register_embedding_function

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Defines.EmbeddingModelMeta import EmbeddingModelMeta
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Embedding.OnnxEncoder import OnnxEncoder
from vdb.Embedding.OnnxEncoderManager import OnnxEncoderManager


@register_embedding_function
class MultilingualOnnxEmbeddingFunction(EmbeddingFunction[Documents]):
    """결과 벡터는 L2 정규화됨 (cosine / ip 모두 사용 가능)."""

    def __init__(self, model_name: str = EmbeddingDefine.E_MODEL.E5_SMALL,
                 max_length: int = EmbeddingDefine.DEFAULT_MAX_LENGTH,
                 batch_size: int = EmbeddingDefine.DEFAULT_BATCH_SIZE):
        self._modelName = model_name
        self._modelSpec = EmbeddingModelMeta.GetSpec(model_name)  # 잘못된 이름은 여기서 바로 ValueError
        self._maxLength = max_length
        self._batchSize = batch_size

    def GetModelName(self) -> str:
        return self._modelName

    def GetDim(self) -> int:
        return self._modelSpec.GetDim()

    def _GetEncoder(self) -> OnnxEncoder:
        # 모델은 실제 임베딩 시점에 로드 (컬렉션 설정 복원만으로 다운로드하지 않도록)
        return OnnxEncoderManager.instance().GetEncoder(model_name=self._modelName, max_length=self._maxLength)

    def _Embed(self, texts: List[str], prefix: str) -> Embeddings:
        return self._GetEncoder().Encode(texts=[prefix + t for t in texts], batch_size=self._batchSize)

    ## ---- Chroma EmbeddingFunction 인터페이스 ----

    def __call__(self, input: Documents) -> Embeddings:
        return self._Embed(texts=input, prefix=self._modelSpec.GetPassagePrefix())

    def embed_query(self, input: Documents) -> Embeddings:
        return self._Embed(texts=input, prefix=self._modelSpec.GetQueryPrefix())

    @staticmethod
    def name() -> str:
        return EmbeddingDefine.EMBEDDING_FUNCTION_NAME

    def default_space(self) -> Space:
        return VdbDefine.E_SPACE.COSINE

    def supported_spaces(self) -> List[Space]:
        return [VdbDefine.E_SPACE.COSINE, VdbDefine.E_SPACE.IP, VdbDefine.E_SPACE.L2]

    def get_config(self) -> Dict[str, Any]:
        return {
            EmbeddingDefine.E_CONFIG_KEY.MODEL: self._modelName,
            EmbeddingDefine.E_CONFIG_KEY.MAX_LENGTH: self._maxLength,
            EmbeddingDefine.E_CONFIG_KEY.BATCH_SIZE: self._batchSize,
        }

    @staticmethod
    def build_from_config(config: Dict[str, Any]) -> "MultilingualOnnxEmbeddingFunction":
        return MultilingualOnnxEmbeddingFunction(
            model_name=config[EmbeddingDefine.E_CONFIG_KEY.MODEL],
            max_length=config.get(EmbeddingDefine.E_CONFIG_KEY.MAX_LENGTH, EmbeddingDefine.DEFAULT_MAX_LENGTH),
            batch_size=config.get(EmbeddingDefine.E_CONFIG_KEY.BATCH_SIZE, EmbeddingDefine.DEFAULT_BATCH_SIZE),
        )

    def validate_config_update(self, old_config: Dict[str, Any], new_config: Dict[str, Any]) -> None:
        modelKey = EmbeddingDefine.E_CONFIG_KEY.MODEL
        oldModel = old_config.get(modelKey)
        newModel = new_config.get(modelKey, oldModel)
        if newModel != oldModel:
            # 벡터 공간이 달라지므로 같은 컬렉션에서 모델을 바꿀 수 없다
            raise ValueError(f"Embedding model cannot be changed ({oldModel} -> {newModel}); "
                             f"create a new collection instead.")
