import threading
from typing import Dict, Tuple

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Defines.EmbeddingModelMeta import EmbeddingModelMeta
from vdb.Embedding.OnnxEncoder import OnnxEncoder
from vdb.Utils.Singleton import SingletonBase


class OnnxEncoderManager(SingletonBase):
    """로드된 OnnxEncoder 를 프로세스 단위로 공유.

    컬렉션을 여러 개 열거나 get_collection() 으로 임베딩 함수가 복원될 때마다
    수백 MB 모델을 다시 올리지 않도록 (모델 이름, max_length) 별로 1개만 유지한다.
    """

    def __init__(self):
        super().__init__()
        self._encoders: Dict[Tuple[str, int], OnnxEncoder] = {}
        self._lock = threading.Lock()

    def GetEncoder(self, model_name: str, max_length: int = EmbeddingDefine.DEFAULT_MAX_LENGTH) -> OnnxEncoder:
        key = (model_name, max_length)
        with self._lock:
            if key not in self._encoders:
                self._encoders[key] = OnnxEncoder(modelSpec=EmbeddingModelMeta.GetSpec(model_name),
                                                  max_length=max_length)
            return self._encoders[key]
