import threading
from typing import List

import numpy as np

from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Dtos.EmbeddingModelSpecDto import EmbeddingModelSpecDto


class OnnxEncoder:
    """ONNX 트랜스포머 인코더 — 토크나이즈 → 추론 → 풀링 → L2 정규화.

    PyTorch 없이 onnxruntime + tokenizers 로 동작한다. 모델 파일은 첫 Encode() 때
    Hugging Face 캐시(%USERPROFILE%\\.cache\\huggingface\\hub)로 다운로드된다.
    """

    def __init__(self, modelSpec: EmbeddingModelSpecDto, max_length: int = EmbeddingDefine.DEFAULT_MAX_LENGTH):
        self._modelSpec = modelSpec
        self._maxLength = max_length
        self._session = None
        self._tokenizer = None
        self._inputNames = set()
        self._loadLock = threading.Lock()

    def GetModelSpec(self) -> EmbeddingModelSpecDto:
        return self._modelSpec

    def IsLoaded(self) -> bool:
        return self._session is not None

    def Encode(self, texts: List[str], batch_size: int = EmbeddingDefine.DEFAULT_BATCH_SIZE) -> List[np.ndarray]:
        """문장 목록을 정규화된 float32 벡터 목록으로 변환."""
        self._Load()
        vectors: List[np.ndarray] = []
        for start in range(0, len(texts), batch_size):
            vectors.extend(self._EncodeBatch(texts[start:start + batch_size]))
        return vectors

    def _Load(self):
        if self.IsLoaded():
            return
        with self._loadLock:
            if self.IsLoaded():
                return
            import os

            # Windows(개발자 모드 꺼짐)에서는 HF 캐시가 symlink 대신 복사본을 쓴다 — 동작엔 문제 없으므로 경고만 끔
            os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

            import onnxruntime as ort
            from huggingface_hub import hf_hub_download
            from tokenizers import Tokenizer

            repo = self._modelSpec.GetRepo()
            print(f"[OnnxEncoder] Loading model: {repo}")

            ## 모델·토크나이저 다운로드 (외부 가중치 파일은 model.onnx 와 같은 폴더에 있어야 함)
            for extraFile in self._modelSpec.GetExtraFiles():
                hf_hub_download(repo_id=repo, filename=extraFile)
            modelPath = hf_hub_download(repo_id=repo, filename=EmbeddingDefine.ONNX_MODEL_FILE)
            tokenizerPath = hf_hub_download(repo_id=repo, filename=EmbeddingDefine.ONNX_TOKENIZER_FILE)

            ## 토크나이저 설정
            tokenizer = Tokenizer.from_file(tokenizerPath)
            tokenizer.enable_truncation(max_length=self._maxLength)
            tokenizer.enable_padding()

            ## 추론 세션 생성
            sessionOptions = ort.SessionOptions()
            sessionOptions.log_severity_level = 3
            session = ort.InferenceSession(modelPath, sessionOptions, providers=["CPUExecutionProvider"])

            self._inputNames = {i.name for i in session.get_inputs()}
            self._tokenizer = tokenizer
            self._session = session

    def _EncodeBatch(self, texts: List[str]) -> List[np.ndarray]:
        encodings = self._tokenizer.encode_batch(texts)
        inputIds = np.array([e.ids for e in encodings], dtype=np.int64)
        attentionMask = np.array([e.attention_mask for e in encodings], dtype=np.int64)

        feed = {"input_ids": inputIds, "attention_mask": attentionMask}
        if "token_type_ids" in self._inputNames:
            feed["token_type_ids"] = np.zeros_like(inputIds)
        hidden = self._session.run(None, feed)[0]  # (batch, seq, dim)

        vectors = self._Pool(hidden=hidden, attentionMask=attentionMask)
        vectors = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
        return list(vectors.astype(np.float32))

    def _Pool(self, hidden: np.ndarray, attentionMask: np.ndarray) -> np.ndarray:
        if self._modelSpec.GetPooling() == EmbeddingDefine.E_POOLING.CLS:
            return hidden[:, 0]
        mask = attentionMask[..., None].astype(np.float32)
        return (hidden * mask).sum(axis=1) / np.clip(mask.sum(axis=1), 1e-9, None)
