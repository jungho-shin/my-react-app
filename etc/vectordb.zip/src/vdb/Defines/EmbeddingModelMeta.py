from vdb.Defines.EmbeddingDefine import EmbeddingDefine
from vdb.Dtos.EmbeddingModelSpecDto import EmbeddingModelSpecDto


class EmbeddingModelMeta:
    """모델 이름 → 모델 사양 메타 테이블."""

    meta = {
        EmbeddingDefine.E_MODEL.E5_SMALL: EmbeddingModelSpecDto().SetDTO(
            repo="intfloat/multilingual-e5-small", dim=384, pooling=EmbeddingDefine.E_POOLING.MEAN,
            query_prefix="query: ", passage_prefix="passage: "),
        EmbeddingDefine.E_MODEL.BGE_M3: EmbeddingModelSpecDto().SetDTO(
            repo="BAAI/bge-m3", dim=1024, pooling=EmbeddingDefine.E_POOLING.CLS,
            extra_files=("onnx/model.onnx_data",)),
    }

    @staticmethod
    def IsContainKey(model_name: str) -> bool:
        return model_name in EmbeddingModelMeta.meta

    @staticmethod
    def GetSpec(model_name: str) -> EmbeddingModelSpecDto:
        if not EmbeddingModelMeta.IsContainKey(model_name):
            raise ValueError(f"Unknown embedding model: {model_name!r} (available: {list(EmbeddingModelMeta.meta)})")
        return EmbeddingModelMeta.meta[model_name]
