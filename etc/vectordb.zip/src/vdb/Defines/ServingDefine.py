from abc import ABC

from vdb.Defines.IDefine import IDefine
from vdb.Defines.VdbDefine import VdbDefine
from vdb.Enum.IENUM import IENUM


class ServingDefine(IDefine, ABC):
    """웹 백엔드(FastAPI) 관련 상수."""

    FRONTEND_DIR = VdbDefine.PROJECT_ROOT / "frontend"
    API_PREFIX = "/api"
    APP_TITLE = "VDB Web"

    DEFAULT_WEB_HOST = "127.0.0.1"
    DEFAULT_WEB_PORT = 8080

    ## 요청 크기 제한 (테스트 환경이지만 실수로 서버를 멈추지 않도록)
    MAX_N_RESULTS = 100
    MAX_PAGE_SIZE = 200
    MAX_IMPORT_ITEMS = 20000
    ADD_BATCH_SIZE = 64

    DEFAULT_CHUNK_SIZE = 500
    DEFAULT_CHUNK_OVERLAP = 50

    class E_ENV(IENUM):
        VDB_WEB_HOST = "VDB_WEB_HOST"
        VDB_WEB_PORT = "VDB_WEB_PORT"
        VDB_URL_USER_AGENT = "VDB_URL_USER_AGENT"  # 링크 가져오기 User-Agent (연락처 요구 사이트용)

    class E_IMPORT_FORMAT(IENUM):
        TEXT = "text"    # 긴 텍스트 → 청크로 분할
        LINES = "lines"  # 한 줄 = 문서 1개
        JSONL = "jsonl"  # 한 줄 = {"id"?, "document", "metadata"?}
        CSV = "csv"      # document 열 + 나머지 열은 메타데이터
        HTML = "html"    # 저장한 웹페이지 → 본문 추출 후 청크로 분할

    class E_RESULT_CODE(IENUM):
        OK = "OK"
        BAD_REQUEST = "BAD_REQUEST"
        NOT_FOUND = "NOT_FOUND"
        CONFLICT = "CONFLICT"
        UPSTREAM_ERROR = "UPSTREAM_ERROR"

    ## 웹페이지(URL) 가져오기
    URL_TIMEOUT_SEC = 15
    URL_MAX_BYTES = 5 * 1024 * 1024
    URL_MAX_REDIRECTS = 5
    URL_USER_AGENT = "Mozilla/5.0 (compatible; VDB-Web/1.0)"
    URL_ID_PREFIX = "url"
    URL_MIN_TEXT_LENGTH = 20

    class E_URL_SCHEME(IENUM):
        HTTP = "http"
        HTTPS = "https"

    ## 문서 메타데이터에 자동으로 붙이는 키
    class E_META_KEY(IENUM):
        SOURCE = "source"
        CHUNK_INDEX = "chunk_index"
        TITLE = "title"
        DOMAIN = "domain"
        FETCHED_DATE = "fetched_date"  # YYYYMMDD 정수 (범위 필터용)

    CSV_DOCUMENT_COLUMN = "document"
    CSV_ID_COLUMN = "id"
