from abc import ABC


class IDefine(ABC):
    """Define 클래스의 공통 인터페이스."""
