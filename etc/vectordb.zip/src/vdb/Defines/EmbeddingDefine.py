from abc import ABC

from vdb.Defines.IDefine import IDefine
from vdb.Enum.IENUM import IENUM


class EmbeddingDefine(IDefine, ABC):
    """임베딩 모델 관련 상수."""

    ## Chroma 에 등록되는 임베딩 함수 이름 — 컬렉션 설정에 저장되므로 바꾸면 기존 컬렉션을 못 연다
    EMBEDDING_FUNCTION_NAME = "vdb-multilingual-onnx"

    ONNX_MODEL_FILE = "onnx/model.onnx"
    ONNX_TOKENIZER_FILE = "onnx/tokenizer.json"
    DEFAULT_MAX_LENGTH = 512
    DEFAULT_BATCH_SIZE = 32

    class E_MODEL(IENUM):
        E5_SMALL = "e5-small"
        BGE_M3 = "bge-m3"
        DEFAULT = "default"  # Chroma 기본 all-MiniLM-L6-v2 (영어 전용)

    class E_POOLING(IENUM):
        MEAN = "mean"
        CLS = "cls"

    ## get_config() 로 컬렉션에 저장되는 키 — 기존 컬렉션 호환을 위해 값을 바꾸지 않는다
    class E_CONFIG_KEY(IENUM):
        MODEL = "model"
        MAX_LENGTH = "max_length"
        BATCH_SIZE = "batch_size"
