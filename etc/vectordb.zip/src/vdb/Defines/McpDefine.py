from abc import ABC

from vdb.Defines.IDefine import IDefine
from vdb.Enum.IENUM import IENUM


class McpDefine(IDefine, ABC):
    """Claude Code 용 MCP 서버 상수."""

    SERVER_NAME = "vdb"
    DEFAULT_WEB_URL = "http://127.0.0.1:8080"
    API_PREFIX = "/api"
    HTTP_TIMEOUT_SEC = 120  # 모델 첫 로딩·큰 검색 대비
    MAX_RESULTS = 20
    MAX_DOC_CHARS = 3000    # 검색 결과 1건당 본문 최대 길이 (컨텍스트 낭비 방지)

    class E_ENV(IENUM):
        VDB_WEB_URL = "VDB_WEB_URL"

    INSTRUCTIONS = (
        "사용자가 VDB(Chroma 벡터 DB)에 등록한 문서를 검색하는 도구다. "
        "사용자가 등록한 자료·문서·메모에 관한 질문이면 먼저 vdb_list_collections 로 컬렉션을 확인하고 "
        "vdb_search 로 관련 조각을 찾은 뒤, 찾은 내용만 근거로 답하라. "
        "답변에는 근거로 쓴 문서의 [번호]와 id 또는 source 를 밝히고, 검색 결과에 없는 내용은 추측하지 말고 없다고 말하라. "
        "결과가 부족하면 검색어를 바꾸거나 n_results 를 늘려 다시 검색하라."
    )
