from abc import ABC
from pathlib import Path

from vdb.Defines.IDefine import IDefine
from vdb.Enum.IENUM import IENUM


class VdbDefine(IDefine, ABC):
    """접속 모드·환경변수·기본값 상수."""

    PROJECT_ROOT = Path(__file__).resolve().parents[3]
    DEFAULT_DATA_DIR = PROJECT_ROOT / "data" / "chroma"
    DEFAULT_HOST = "127.0.0.1"
    DEFAULT_PORT = 8000

    class E_MODE(IENUM):
        EMBEDDED = "embedded"
        HTTP = "http"

    class E_ENV(IENUM):
        VDB_MODE = "VDB_MODE"
        VDB_DATA_DIR = "VDB_DATA_DIR"
        VDB_HOST = "VDB_HOST"
        VDB_PORT = "VDB_PORT"
        VDB_EMBED = "VDB_EMBED"

    class E_SPACE(IENUM):
        COSINE = "cosine"
        L2 = "l2"
        IP = "ip"
