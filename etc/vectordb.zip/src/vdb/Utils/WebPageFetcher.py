"""웹페이지를 가져와 본문 텍스트로 변환.

보안: 웹 서버가 사용자 대신 URL 에 접속하므로(SSRF), 이 PC 자신(127.0.0.1 등)·링크 로컬
(169.254.x.x, 클라우드 메타데이터)·멀티캐스트 등은 막는다. 특히 127.0.0.1 로 바인딩한 Chroma 서버를
웹을 통해 우회 접근하지 못하게 한다. 사내 문서를 가져올 수 있도록 사설망(192.168.x.x 등)은 허용한다.
"""
import ipaddress
import os
import re
import socket
from typing import Tuple
from urllib.parse import urljoin, urlsplit

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Dtos.WebPageDto import WebPageDto
from vdb.Utils.HtmlTextExtractor import HtmlTextExtractor


class WebPageFetcher:

    HTML_TYPES = ("text/html", "application/xhtml+xml")
    TEXT_TYPES = ("text/plain", "text/markdown", "text/x-markdown")
    REDIRECT_CODES = (301, 302, 303, 307, 308)
    CHARSET_ALIASES = {"euc-kr": "cp949", "ks_c_5601-1987": "cp949", "x-windows-949": "cp949", "ksc5601": "cp949"}
    _META_CHARSET = re.compile(rb"""<meta[^>]+charset\s*=\s*["']?\s*([a-zA-Z0-9_\-]+)""", re.IGNORECASE)

    @staticmethod
    def Fetch(url: str) -> WebPageDto:
        """URL 의 제목·본문을 가져온다. 사용자가 고칠 수 있는 문제는 ValueError 로 알린다."""
        import httpx

        currentUrl = WebPageFetcher.NormalizeUrl(url)
        userAgent = os.getenv(ServingDefine.E_ENV.VDB_URL_USER_AGENT) or ServingDefine.URL_USER_AGENT
        headers = {"User-Agent": userAgent, "Accept": "text/html,text/plain;q=0.9,*/*;q=0.5",
                   "Accept-Language": "ko,en;q=0.8"}
        try:
            with httpx.Client(follow_redirects=False, timeout=ServingDefine.URL_TIMEOUT_SEC, headers=headers) as client:
                ## 리다이렉트는 직접 따라가며 매 단계 주소를 검사한다
                for _ in range(ServingDefine.URL_MAX_REDIRECTS + 1):
                    WebPageFetcher._CheckHostAllowed(currentUrl)
                    with client.stream("GET", currentUrl) as response:
                        if response.status_code in WebPageFetcher.REDIRECT_CODES and "location" in response.headers:
                            currentUrl = WebPageFetcher.NormalizeUrl(urljoin(currentUrl, response.headers["location"]))
                            continue
                        if response.headers.get("cf-mitigated") == "challenge":
                            raise ValueError("Blocked by the site's bot protection (Cloudflare challenge, "
                                             f"HTTP {response.status_code}). Open the page in a browser, save it "
                                             "(Ctrl+S, .html) and use file upload instead.")
                        if response.status_code >= 400:
                            raise ValueError(f"Page returned HTTP {response.status_code}: {currentUrl}")
                        contentType = response.headers.get("content-type", "")
                        body = WebPageFetcher._ReadLimited(response)
                        return WebPageFetcher._ToPage(url=currentUrl, body=body, content_type=contentType)
        except httpx.HTTPError as e:
            ## TransportError 가 Chroma 연결 오류(503)로 오인되지 않도록 ValueError(400)로 바꾼다
            raise ValueError(f"Failed to fetch {currentUrl}: {type(e).__name__}: {e}") from None
        raise ValueError(f"Too many redirects (max {ServingDefine.URL_MAX_REDIRECTS}): {url}")

    @staticmethod
    def NormalizeUrl(url: str) -> str:
        url = (url or "").strip()
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
            url = f"{ServingDefine.E_URL_SCHEME.HTTPS}://{url}"
        parts = urlsplit(url)
        if parts.scheme.lower() not in (ServingDefine.E_URL_SCHEME.HTTP, ServingDefine.E_URL_SCHEME.HTTPS):
            raise ValueError(f"Only http/https URLs are allowed, got {parts.scheme!r}")
        if not parts.hostname:
            raise ValueError(f"Invalid URL: {url!r}")
        ## #fragment 는 서버에 전달되지 않으므로 제거 (같은 페이지 중복 등록 방지)
        return parts._replace(fragment="").geturl()

    @staticmethod
    def IsBlockedAddress(address: str) -> bool:
        ip = ipaddress.ip_address(address)
        if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        return ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved

    @staticmethod
    def _CheckHostAllowed(url: str):
        parts = urlsplit(url)
        port = parts.port or (443 if parts.scheme == ServingDefine.E_URL_SCHEME.HTTPS else 80)
        try:
            infos = socket.getaddrinfo(parts.hostname, port, proto=socket.IPPROTO_TCP)
        except socket.gaierror:
            raise ValueError(f"Cannot resolve host: {parts.hostname}") from None
        for info in infos:
            if WebPageFetcher.IsBlockedAddress(info[4][0]):
                raise ValueError(f"URL host is not allowed (local/reserved address): {parts.hostname}")

    @staticmethod
    def _ReadLimited(response) -> bytes:
        chunks, total = [], 0
        for chunk in response.iter_bytes():
            total += len(chunk)
            if total > ServingDefine.URL_MAX_BYTES:
                raise ValueError(f"Page is too large (max {ServingDefine.URL_MAX_BYTES // (1024 * 1024)}MB)")
            chunks.append(chunk)
        return b"".join(chunks)

    @staticmethod
    def _ToPage(url: str, body: bytes, content_type: str) -> WebPageDto:
        mimeType = content_type.split(";")[0].strip().lower()
        isHtml = mimeType in WebPageFetcher.HTML_TYPES or (not mimeType and b"<html" in body[:2048].lower())
        if not isHtml and mimeType not in WebPageFetcher.TEXT_TYPES:
            raise ValueError(f"Unsupported content type {mimeType or 'unknown'!r} (only HTML / plain text pages)")

        text = WebPageFetcher._Decode(body=body, content_type=content_type)
        if isHtml:
            title, text = HtmlTextExtractor.Extract(text)
        else:
            title = urlsplit(url).path.rsplit("/", 1)[-1] or urlsplit(url).hostname
        if len(text) < ServingDefine.URL_MIN_TEXT_LENGTH:
            raise ValueError("No readable text found on the page (it may require JavaScript or login)")
        return WebPageDto().SetDTO(url=url, title=title or urlsplit(url).hostname, text=text, content_type=mimeType)

    @staticmethod
    def _Decode(body: bytes, content_type: str) -> str:
        """헤더 charset → <meta charset> → utf-8 순으로 인코딩을 정한다 (EUC-KR 페이지 대응)."""
        charset, _ = WebPageFetcher._FindCharset(body=body, content_type=content_type)
        charset = WebPageFetcher.CHARSET_ALIASES.get(charset.lower(), charset)
        try:
            return body.decode(charset, errors="replace")
        except LookupError:
            return body.decode("utf-8", errors="replace")

    @staticmethod
    def _FindCharset(body: bytes, content_type: str) -> Tuple[str, str]:
        match = re.search(r"charset\s*=\s*[\"']?([a-zA-Z0-9_\-]+)", content_type, re.IGNORECASE)
        if match:
            return match.group(1), "header"
        match = WebPageFetcher._META_CHARSET.search(body[:4096])
        if match:
            return match.group(1).decode("ascii", errors="ignore"), "meta"
        return "utf-8", "default"
