import csv
import io
import json
from typing import Any, Dict, List

from vdb.Defines.ServingDefine import ServingDefine
from vdb.Utils.HtmlTextExtractor import HtmlTextExtractor
from vdb.Utils.TextChunkHelper import TextChunkHelper


class DocumentImportHelper:
    """업로드된 파일 내용을 {"id", "document", "metadata"} 목록으로 변환.

    반환 항목의 id 는 없을 수 있다(None → 서비스에서 자동 생성).
    """

    @staticmethod
    def Parse(content: str, import_format: str, source_name: str | None = None,
              chunk_size: int = ServingDefine.DEFAULT_CHUNK_SIZE,
              chunk_overlap: int = ServingDefine.DEFAULT_CHUNK_OVERLAP) -> List[Dict[str, Any]]:
        parsers = {
            ServingDefine.E_IMPORT_FORMAT.TEXT: lambda: DocumentImportHelper._ParseText(
                content=content, chunk_size=chunk_size, chunk_overlap=chunk_overlap),
            ServingDefine.E_IMPORT_FORMAT.LINES: lambda: DocumentImportHelper._ParseLines(content=content),
            ServingDefine.E_IMPORT_FORMAT.JSONL: lambda: DocumentImportHelper._ParseJsonl(content=content),
            ServingDefine.E_IMPORT_FORMAT.CSV: lambda: DocumentImportHelper._ParseCsv(content=content),
            ServingDefine.E_IMPORT_FORMAT.HTML: lambda: DocumentImportHelper._ParseHtml(
                content=content, chunk_size=chunk_size, chunk_overlap=chunk_overlap),
        }
        if import_format not in parsers:
            raise ValueError(f"Unknown import format: {import_format!r} (available: {list(parsers)})")

        items = parsers[import_format]()
        if source_name:
            for item in items:
                item["metadata"].setdefault(ServingDefine.E_META_KEY.SOURCE, source_name)
        return items

    @staticmethod
    def _NewItem(document: str, metadata: Dict[str, Any] | None = None, doc_id: str | None = None) -> Dict[str, Any]:
        return {"id": doc_id, "document": document, "metadata": dict(metadata or {})}

    @staticmethod
    def _ParseText(content: str, chunk_size: int, chunk_overlap: int) -> List[Dict[str, Any]]:
        chunks = TextChunkHelper.Split(text=content, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        return [DocumentImportHelper._NewItem(document=chunk, metadata={ServingDefine.E_META_KEY.CHUNK_INDEX: i})
                for i, chunk in enumerate(chunks)]

    @staticmethod
    def _ParseHtml(content: str, chunk_size: int, chunk_overlap: int) -> List[Dict[str, Any]]:
        """브라우저에서 저장한 웹페이지: 본문만 뽑아 청크로 나누고 제목을 메타데이터로 붙인다."""
        title, text = HtmlTextExtractor.Extract(content)
        items = DocumentImportHelper._ParseText(content=text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        if title:
            for item in items:
                item["metadata"][ServingDefine.E_META_KEY.TITLE] = title[:500]
        return items

    @staticmethod
    def _ParseLines(content: str) -> List[Dict[str, Any]]:
        return [DocumentImportHelper._NewItem(document=line.strip())
                for line in content.splitlines() if line.strip()]

    @staticmethod
    def _ParseJsonl(content: str) -> List[Dict[str, Any]]:
        items = []
        for lineNo, line in enumerate(content.splitlines(), start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"JSONL line {lineNo}: invalid JSON ({e.msg})") from None
            if not isinstance(row, dict) or not isinstance(row.get("document"), str):
                raise ValueError(f"JSONL line {lineNo}: object with string field 'document' is required")
            metadata = row.get("metadata") or {}
            if not isinstance(metadata, dict):
                raise ValueError(f"JSONL line {lineNo}: 'metadata' must be an object")
            docId = row.get("id")
            items.append(DocumentImportHelper._NewItem(document=row["document"], metadata=metadata,
                                                       doc_id=str(docId) if docId is not None else None))
        return items

    @staticmethod
    def _ParseCsv(content: str) -> List[Dict[str, Any]]:
        reader = csv.DictReader(io.StringIO(content.lstrip("﻿")))
        fieldNames = reader.fieldnames or []
        if ServingDefine.CSV_DOCUMENT_COLUMN not in fieldNames:
            raise ValueError(f"CSV header must contain a '{ServingDefine.CSV_DOCUMENT_COLUMN}' column, "
                             f"got {fieldNames}")
        items = []
        for row in reader:
            document = (row.get(ServingDefine.CSV_DOCUMENT_COLUMN) or "").strip()
            if not document:
                continue
            docId = (row.get(ServingDefine.CSV_ID_COLUMN) or "").strip() or None
            metadata = {k: DocumentImportHelper._CastCsvValue(v) for k, v in row.items()
                        if k and k not in (ServingDefine.CSV_DOCUMENT_COLUMN, ServingDefine.CSV_ID_COLUMN)
                        and v not in (None, "")}
            items.append(DocumentImportHelper._NewItem(document=document, metadata=metadata, doc_id=docId))
        return items

    @staticmethod
    def _CastCsvValue(value: str) -> Any:
        """CSV 는 모두 문자열이므로 숫자처럼 보이면 숫자로 바꿔 where 범위 필터($gt 등)를 쓸 수 있게 한다."""
        text = value.strip()
        for caster in (int, float):
            try:
                return caster(text)
            except ValueError:
                continue
        return text
