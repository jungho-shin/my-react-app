import re
from typing import List


class TextChunkHelper:
    """긴 텍스트를 임베딩하기 좋은 크기의 청크로 나눈다.

    문단(빈 줄) → 문장 → 글자 순으로 경계를 찾아 chunk_size 이하로 자르고,
    앞 청크의 끝 chunk_overlap 글자를 다음 청크 앞에 붙여 문맥이 끊기지 않게 한다.
    """

    _PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")
    _SENTENCE_PATTERN = re.compile(r"(?<=[.!?。])\s+|(?<=다\.)\s*|\n")

    @staticmethod
    def Split(text: str, chunk_size: int, chunk_overlap: int = 0) -> List[str]:
        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")
        if chunk_overlap < 0 or chunk_overlap >= chunk_size:
            raise ValueError(f"chunk_overlap must be in [0, chunk_size), got {chunk_overlap}")

        pieces = TextChunkHelper._SplitToPieces(text=text, chunk_size=chunk_size)
        return TextChunkHelper._MergePieces(pieces=pieces, chunk_size=chunk_size, chunk_overlap=chunk_overlap)

    @staticmethod
    def _SplitToPieces(text: str, chunk_size: int) -> List[str]:
        """chunk_size 를 넘지 않는 조각들로 분해."""
        pieces = []
        for paragraph in TextChunkHelper._PARAGRAPH_PATTERN.split(text):
            paragraph = paragraph.strip()
            if not paragraph:
                continue
            if len(paragraph) <= chunk_size:
                pieces.append(paragraph)
                continue
            for sentence in TextChunkHelper._SENTENCE_PATTERN.split(paragraph):
                sentence = (sentence or "").strip()
                if not sentence:
                    continue
                ## 문장 하나가 너무 길면 글자 단위로 자른다
                for start in range(0, len(sentence), chunk_size):
                    pieces.append(sentence[start:start + chunk_size])
        return pieces

    @staticmethod
    def _MergePieces(pieces: List[str], chunk_size: int, chunk_overlap: int) -> List[str]:
        """작은 조각을 chunk_size 까지 이어 붙이고, 청크 사이에 overlap 을 둔다."""
        chunks = []
        current = ""
        for piece in pieces:
            candidate = f"{current}\n{piece}" if current else piece
            if len(candidate) <= chunk_size:
                current = candidate
                continue
            chunks.append(current)
            tail = current[-chunk_overlap:] if chunk_overlap else ""
            current = f"{tail} {piece}".strip() if tail and len(tail) + 1 + len(piece) <= chunk_size else piece
        if current:
            chunks.append(current)
        return chunks
