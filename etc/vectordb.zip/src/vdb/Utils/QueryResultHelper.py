from typing import Any, Dict


class QueryResultHelper:
    """collection.query() 결과 출력용 정적 유틸."""

    @staticmethod
    def PrintQueryResult(result: Dict[str, Any], query_index: int = 0, indent: str = "  "):
        """질의 1개 분량의 결과를 'id  거리  문서' 형식으로 출력."""
        ids = result["ids"][query_index]
        documents = result["documents"][query_index]
        distances = result["distances"][query_index]
        idWidth = max((len(i) for i in ids), default=0)
        for docId, document, distance in zip(ids, documents, distances):
            print(f"{indent}{docId:<{idWidth}}  dist={distance:.4f}  {document}")
