"""싱글톤 기반 클래스 (Haerujil24 common_lib.Utils.Singleton 최소 복제)."""
import threading
from typing import Any, Dict


class SingletonBase:
    """반드시 Cls.instance(...) 로 생성한다. 직접 생성하면 RuntimeError."""

    _instances: Dict[type, Any] = {}
    _lock = threading.Lock()
    _creating = set()  # 현재 instance() 를 통해 생성 중인 클래스

    def __init__(self):
        cls = self.__class__
        if cls not in SingletonBase._creating:
            raise RuntimeError(f"{cls.__name__} must be created via {cls.__name__}.instance(...)")

    @classmethod
    def instance(cls, *args, **kwargs):
        inst = cls._instances.get(cls)
        if inst is not None:
            if args or kwargs:
                raise ValueError(f"{cls.__name__} singleton already created; don't pass args/kwargs again.")
            return inst

        with cls._lock:
            inst = cls._instances.get(cls)
            if inst is None:
                cls._creating.add(cls)
                try:
                    inst = cls(*args, **kwargs)
                    cls._instances[cls] = inst
                finally:
                    cls._creating.remove(cls)
        return inst

    @classmethod
    def reset_instance(cls):
        with cls._lock:
            cls._instances.pop(cls, None)

    @classmethod
    def reset_all(cls):
        with cls._lock:
            cls._instances.clear()

    def Initialize(self):
        """무거운 초기화는 생성자 대신 여기서 한다. 기본은 아무것도 하지 않음."""
