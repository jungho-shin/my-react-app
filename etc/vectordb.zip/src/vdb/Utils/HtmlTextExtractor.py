"""HTML → 본문 텍스트 추출 (표준 라이브러리 html.parser 만 사용).

※ handle_starttag / handle_endtag / handle_data 는 HTMLParser 가 정한 인터페이스 이름이므로
  컨벤션(PascalCase)의 예외로 그대로 둔다.
"""
import re
from html.parser import HTMLParser
from typing import List, Tuple


class HtmlTextExtractor(HTMLParser):
    """사용: title, text = HtmlTextExtractor.Extract(html)

    - script·style·nav·footer 등 본문이 아닌 영역은 버린다.
    - <article> / <main> 이 있고 충분히 길면 그 안의 텍스트만 쓴다.
    - 블록 태그 경계는 줄바꿈, 문단(p·h·li 등) 경계는 빈 줄로 바꿔 청크 분할이 문단을 따르게 한다.
    """

    SKIP_TAGS = {"script", "style", "noscript", "svg", "nav", "footer", "header", "aside", "form",
                 "iframe", "template", "button", "select", "canvas", "object"}
    PARAGRAPH_TAGS = {"p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote", "pre", "table", "section",
                      "article", "dd", "dt", "figcaption"}
    LINE_TAGS = {"br", "div", "tr", "ul", "ol", "dl", "hr", "main", "body"}
    VOID_TAGS = {"br", "hr", "img", "input", "meta", "link", "area", "base", "col", "embed", "source", "wbr"}
    MAIN_TAGS = {"article", "main"}
    MIN_MAIN_LENGTH = 200

    _SPACES = re.compile(r"[ \t\r\f\v ]+")
    _BLANK_LINES = re.compile(r"\n\s*\n\s*(\n\s*)+")

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self._skipDepth = 0
        self._mainDepth = 0
        self._inTitle = False
        self._title = ""
        self._ogTitle = ""
        self._bodyParts: List[str] = []
        self._mainParts: List[str] = []

    @staticmethod
    def Extract(html: str) -> Tuple[str, str]:
        """(제목, 본문 텍스트) 반환."""
        extractor = HtmlTextExtractor()
        extractor.feed(html)
        extractor.close()
        return extractor.GetTitle(), extractor.GetText()

    def GetTitle(self) -> str:
        return self._Clean(self._ogTitle or self._title).replace("\n", " ")

    def GetText(self) -> str:
        mainText = self._Clean("".join(self._mainParts))
        if len(mainText) >= self.MIN_MAIN_LENGTH:
            return mainText
        return self._Clean("".join(self._bodyParts))

    def _Clean(self, text: str) -> str:
        lines = [self._SPACES.sub(" ", line).strip() for line in text.split("\n")]
        return self._BLANK_LINES.sub("\n\n", "\n".join(lines)).strip()

    def _Append(self, text: str):
        self._bodyParts.append(text)
        if self._mainDepth:
            self._mainParts.append(text)

    ## ---- HTMLParser 인터페이스 ----

    def handle_starttag(self, tag, attrs):
        if tag == "meta":
            attrMap = dict(attrs)
            if attrMap.get("property") == "og:title" and attrMap.get("content"):
                self._ogTitle = attrMap["content"]
            return
        if tag in self.VOID_TAGS:
            if tag in ("br", "hr") and not self._skipDepth:
                self._Append("\n")
            return
        if tag in self.SKIP_TAGS:
            self._skipDepth += 1
            return
        if tag == "title":
            self._inTitle = True
        if tag in self.MAIN_TAGS:
            self._mainDepth += 1
        self._AppendBoundary(tag)

    def handle_endtag(self, tag):
        if tag in self.SKIP_TAGS:
            self._skipDepth = max(0, self._skipDepth - 1)
            return
        if tag == "title":
            self._inTitle = False
        self._AppendBoundary(tag)
        if tag in self.MAIN_TAGS:
            self._mainDepth = max(0, self._mainDepth - 1)

    def handle_data(self, data):
        if self._inTitle:
            self._title += data
            return
        if self._skipDepth:
            return
        self._Append(data.replace("\n", " "))

    def _AppendBoundary(self, tag: str):
        if self._skipDepth:
            return
        if tag in self.PARAGRAPH_TAGS:
            self._Append("\n\n")
        elif tag in self.LINE_TAGS or tag in ("td", "th"):
            self._Append("\n" if tag not in ("td", "th") else " ")
