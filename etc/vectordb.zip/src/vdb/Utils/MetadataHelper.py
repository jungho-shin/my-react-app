from typing import Any, Dict


class MetadataHelper:
    """Chroma 메타데이터 검증·정리."""

    ALLOWED_TYPES = (str, int, float, bool)
    MAX_KEY_LENGTH = 128

    @staticmethod
    def Normalize(metadata: Dict[str, Any] | None) -> Dict[str, Any] | None:
        """값 타입을 검사하고, 비어 있으면 None 을 반환한다.

        Chroma 는 빈 dict({}) 메타데이터를 거부하므로 None 으로 바꿔 넘긴다.
        """
        if not metadata:
            return None
        if not isinstance(metadata, dict):
            raise ValueError(f"metadata must be an object, got {type(metadata).__name__}")
        for key, value in metadata.items():
            if not isinstance(key, str) or not key.strip():
                raise ValueError("metadata key must be a non-empty string")
            if len(key) > MetadataHelper.MAX_KEY_LENGTH:
                raise ValueError(f"metadata key too long (max {MetadataHelper.MAX_KEY_LENGTH}): {key[:20]}...")
            if value is None or not isinstance(value, MetadataHelper.ALLOWED_TYPES):
                raise ValueError(f"metadata value for {key!r} must be str, int, float or bool, "
                                 f"got {type(value).__name__}")
        return dict(metadata)

    @staticmethod
    def Merge(base: Dict[str, Any] | None, override: Dict[str, Any] | None) -> Dict[str, Any]:
        """공통 메타데이터(base) 위에 문서별 메타데이터(override)를 덮어쓴다."""
        return {**(base or {}), **(override or {})}
