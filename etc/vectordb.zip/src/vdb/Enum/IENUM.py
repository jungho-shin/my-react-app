class IENUM:
    """문자열 상수 그룹의 기반 클래스 (Haerujil24 common_lib.Enum.IENUM 최소 복제)."""
