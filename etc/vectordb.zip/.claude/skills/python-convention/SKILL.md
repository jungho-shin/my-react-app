---
name: python-convention
description: Haerujil24 프로젝트(app/common_lib, app/dataset_builder, app/serving, app/training)의 Python 코드 컨벤션. 이 저장소에서 Python 코드를 새로 작성·수정·리뷰할 때, 클래스/메서드/변수 이름을 정할 때, 새 State·Process·Factory·Define·Dto·Protocol·Controller·Service를 추가할 때 반드시 사용한다. "컨벤션 맞춰서", "코드 스타일", "리뷰해줘" 같은 요청에도 사용한다.
---

# Haerujil24 Python 코드 컨벤션

이 문서는 저장소의 기존 소스에서 실제로 쓰이는 규칙을 정리한 것이다.
새 코드는 **주변 코드와 같은 모양**이 되도록 작성한다. 규칙이 애매하면 같은 패키지의 이웃 파일을 먼저 열어 보고 그 스타일을 따른다.

> 예외 영역: `app/serving`의 FastAPI 경계 코드(Controller/Service/Server)와 `ObjectStorage` 같은 파일시스템 유사 API는 snake_case/소문자 메서드를 쓴다. 해당 영역을 수정할 때는 그 영역의 스타일을 유지한다. (아래 "영역별 예외" 참고)

---

## 1. 파일 · 패키지 구조

- **파일 1개 = 대표 클래스 1개**, 파일명은 클래스명과 같은 PascalCase.
  - `StateController.py` → `class StateController`
  - 인터페이스와 그 추상 클래스(`IState` + `abState`)는 같은 파일에 둘 수 있다.
- 패키지(디렉터리)는 PascalCase: `Modules/`, `Defines/`, `Factory/`, `Collections/`, `MessageQueue/`.
- 패키지에는 빈 `__init__.py`를 둔다. `__init__.py`에서 re-export 하지 않는다.
- 테스트/실험 코드는 `TestCode/` 아래에 둔다. 파일명은 camelCase(`configTest.py`, `mpTest.py`).
- 진입점 스크립트는 snake_case 또는 camelCase 파일(`build_dataset.py`, `ServingServer.py`)에 `main()`을 둔다.

```
app/<service>/
  Defines/     # 상수·Enum·Define 클래스, StateFactory
  Factory/     # XxxFactory
  Modules/
    App/  Processes/  State/<Kind>State/  Protocol/  Utils/  Dtos/ ...
  TestCode/
  build_xxx.py # 진입점
app/common_lib/common_lib/  # 공용 라이브러리 (서비스 코드에 의존하지 않는다)
```

---

## 2. 네이밍

### 2.1 클래스

| 종류 | 규칙 | 예 |
|---|---|---|
| 인터페이스 | `I` + PascalCase, `ABC` 상속 | `IState`, `IApp`, `IController`, `IDTO`, `IBus` |
| 추상 기반 클래스 | `ab` + PascalCase, `(IXxx, ABC)` 상속 | `abState`, `abApp`, `abProtocol`, `abThreading`, `abMessageHandler` |
| 커스텀 컬렉션 | `c` + PascalCase | `cDict`, `cList` |
| Enum 성격 상수 그룹 | `E_` + 이름, `IENUM` 상속 | `E_JOB_STATE`, `E_SECTION`, `E_StateType`, `E_STATE` |
| Define 클래스 | `XxxDefine(IDefine, ABC)` 또는 `Defines` | `StateDefine`, `ConfigDefine`, `ProtocolDefine` |
| 구체 클래스 | 역할 접미사 사용 | `RunningState`, `WorkerProcess`, `ProcessFactory`, `StateController`, `ServingService`, `S3ConnectDto`, `JobProtocol`, `S3Utils`, `ConfigHelper`, `XxxManager` |

- 상태 클래스는 `<상태명>State` (`IdleState`, `BeginState`), 파일명은 상태명만 (`Idle.py`, `Begin.py`).
- 정적 유틸 모음은 `XxxUtils` / `XxxHelper` 클래스로 만들고 `@staticmethod`만 둔다. 모듈 수준 함수 대신 클래스로 묶는다.

### 2.2 메서드

| 종류 | 규칙 | 예 |
|---|---|---|
| public 메서드 | **PascalCase** (동사로 시작) | `GetState`, `SetParentProcess`, `ChangeState`, `IsContainKey`, `AppendState`, `CreateWorkerProcesss`, `Start`, `Stop`, `Proc`, `Invoke`, `Initialize` |
| private/내부 메서드 | `_` + PascalCase 또는 `_` + camelCase | `_Download`, `_Marking`, `_load`, `_downloadModel`, `_getStateController` |
| 템플릿 훅 (App 수명주기) | camelCase | `preProcessing`, `processing`, `postProcessing` |
| 직렬화 | camelCase | `toJson`, `fromJson` |
| 싱글톤 팩토리 | snake_case (SingletonBase 고정) | `instance`, `reset_instance`, `reset_all` |
| 플루언트 빌더 | `build` + PascalCase 또는 `Set...` | `buildSleepTime(...)` → `return self` |

자주 쓰는 동사 접두어: `Get` / `Set` / `Is` / `Has` / `Create` / `Append` / `Register` / `Put` / `Push` / `Pop` / `Start` / `Stop` / `Proc` / `Enter` / `Leave`.

### 2.3 변수 · 인자 · 멤버

- **멤버 변수는 항상 `self._camelCase`** (private 표기). 외부 접근은 `Get/Set` 메서드로 한다.
  - `self._stateController`, `self._jobQueue`, `self._currentStateID`, `self._configLoader`
- **로컬 변수는 camelCase**: `configLoader`, `stateController`, `jobProtocol`, `processName`, `messageChannelSet`.
- **인자**
  - 의존 객체(컨트롤러·핸들러·로더·커넥션)는 camelCase: `ipcController`, `messageHandler`, `configLoader`, `stateController`, `minioConnection`
  - 값(식별자·경로·이름·개수)은 snake_case: `state_id`, `channel_name`, `file_path`, `local_dir`, `process_count`, `parent_process`
- 상수는 UPPER_SNAKE 클래스 속성: `CONFIG_FILE_NAME = "config.ini"`.
- ID 약어는 대문자 유지: `GetStateID`, `_currentStateID`, `IPC_Controller`, `S3ConnectDto`.
- 컬렉션 변수는 `xxxLists` / `xxxs` 형태가 쓰인다: `processLists`, `workerProcessLists`, `channelDtos`.

---

## 3. 상수 · Enum · Define

- Python `enum.Enum` 대신 **`IENUM`을 상속한 문자열 상수 클래스**를 쓴다. 값은 문자열이며 보통 이름과 같다.
- 관련 상수는 `XxxDefine` 클래스 안에 **중첩 클래스**로 묶는다.
- Enum 멤버명: 설정 키·타입은 UPPER_SNAKE, 상태 이름은 PascalCase.

```python
from common_lib.Enum.IENUM import IENUM


class ConfigDefine:

    class E_SECTION(IENUM):
        APP = "APP"
        MINIO = "MINIO"

    class E_MINIO(IENUM):
        S3_ENDPOINT = "S3_ENDPOINT"
        S3_BUCKET = "S3_BUCKET"
```

```python
class StateDefine(IDefine, ABC):

    class E_StateType(IENUM):
        Consumer = "Consumer"
        Worker = "Worker"

    class WorkerState(IENUM):
        class E_STATE(E_BaseState):
            Begin = "Begin"
            Running = "Running"
```

- 설정값은 문자열 리터럴로 직접 읽지 말고 `ConfigDefine.E_SECTION.*` / `E_*` 키와 `ConfigHelper`를 통해 읽는다.

---

## 4. 클래스 설계 패턴

### 4.1 인터페이스 → 추상 클래스 → 구체 클래스

```python
from abc import ABC, abstractmethod
from typing import Any


class IState(ABC):

    @abstractmethod
    def Enter(self, stateEnterData: Any = None):
        raise NotImplementedError

    @abstractmethod
    def Leave(self):
        raise NotImplementedError


class abState(IState, ABC):

    def __init__(self, stateController, state_id):
        self._state_id = state_id
        self._stateController = stateController

    def GetStateController(self):
        return self._stateController
```

- 추상 메서드 본문은 `raise NotImplementedError` (`pass` 아님).
- 단일 상속은 `super().__init__(...)`, **다중 상속은 각 부모를 명시 호출**한다.

```python
class WorkerProcess(ConfigEventBusProcess, StateProcess):

    def __init__(self, ipcController, channelDtos, messageHandler, stateController=None, name="None"):
        ConfigEventBusProcess.__init__(self, ipcController=ipcController, channelDtos=channelDtos,
                                       messageHandler=messageHandler, name=name)
        StateProcess.__init__(self, stateController=stateController)
```

- 오버라이드에서 부모 동작이 필요하면 명시 호출: `ConfigEventBusProcess.PostInit(self)`.

### 4.2 싱글톤

- `common_lib.Utils.Singleton.SingletonBase`를 상속하고, **반드시 `Cls.instance(...)`로 생성**한다. 직접 생성하면 `RuntimeError`.
- 최초 생성 시에만 인자를 넘기고 이후엔 `Cls.instance()`만 호출한다.
- 무거운 초기화는 생성자 대신 `Initialize()`로 분리한다.

```python
configLoader = ConfigLoader.instance(config_file)   # 최초
ConfigLoader.instance().Get(section, key)           # 이후
InferenceManager.instance(config).Initialize()
```

### 4.3 Factory · 메타 테이블

- 타입 Enum → `Func(lambda ...)` 딕셔너리를 클래스 속성으로 두고, `@staticmethod Create...`에서 `.Invoke(...)` 한다.
- 콜백은 `common_lib.CallBack.CallBack`의 `Func`(반환값 있음) / `Action`(반환값 없음)으로 감싼다.

```python
class ProcessFactory(IFactory):

    class E_PROCESS_TYPE(IENUM):
        CONSUMER_PROCESS = "ConsumerProcess"

    factories = {
        E_PROCESS_TYPE.CONSUMER_PROCESS: Func(lambda ipcController, messageHandler: ConsumerProcess(...)),
    }

    @staticmethod
    def CreateConsumerProcess(ipcController, messageHandler):
        return ProcessFactory.factories[ProcessFactory.E_PROCESS_TYPE.CONSUMER_PROCESS].Invoke(ipcController, messageHandler)
```

- 새 State를 추가하면: `StateDefine`에 Enum 추가 → `Modules/State/<Kind>State/<Name>.py`에 `<Name>State(abState)` 작성 → `Defines/StateFactory.py`의 `StateMeta.meta`에 등록.

### 4.4 플루언트(체이닝) API

- 설정/추가 메서드는 `return self`로 체이닝을 지원한다.

```python
ipcController = IPC_Controller().Append(ChannelIPC(...)).Append(ChannelIPC(...))
self._multiProcess.Append(consumerProcess).AppendLists(workerProcessLists)
```

### 4.5 DTO · Protocol · REST 모델

- **DTO**: `IDTO` 상속, 생성자에서 필드를 `None`으로 초기화, `SetDTO(...)`/`SetDTOFromConfig(...)`가 `self` 반환. 민감정보가 있으면 `__repr__`에서 마스킹한다.
- **프로세스 간 메시지(Protocol)**: `@dataclasses.dataclass` + `abProtocol` 상속, `toJson()`/`fromJson()` 사용. 필드는 snake_case.
- **REST 요청/응답(serving)**: pydantic `BaseModel` 기반 `RequestModel`/`ResponseModel` 상속. 응답에는 `response: ResponseHeader` 헤더가 포함된다.

```python
@dataclasses.dataclass
class JobMarkProtocol(abProtocol):

    file_path: str
    job_state: str = E_JOB_STATE.PENDING

    def SetComplete(self):
        self.job_state = E_JOB_STATE.COMPLETED

    def IsComplete(self):
        return self.job_state == E_JOB_STATE.COMPLETED
```

### 4.6 App 수명주기

- 실행 단위 앱은 `abApp`을 상속하고 `preProcessing` → `processing` → `postProcessing`을 구현한다. `Run()`은 오버라이드하지 않는다.

---

## 5. import 규칙

- **절대 import만** 쓴다. 상대 import(`from . import`)는 쓰지 않는다.
  - 공용 라이브러리: `from common_lib.<Package>.<Module> import <Class>`
  - 서비스 내부: 서비스 루트 기준 `from Modules.State.State import abState`, `from Defines.Defines import Defines`
- 파일 상단 순서(그룹 사이 빈 줄 1줄): 표준 라이브러리 → 서드파티 → `common_lib` → 서비스 내부 모듈.
- **함수 내부 지역 import를 적극 사용한다.** 다음 경우엔 지역 import가 원칙이다.
  1. 순환 import를 피해야 할 때 (Factory ↔ Process ↔ State, EventBus ↔ MessageChannel 등)
  2. 무거운/플랫폼 의존 라이브러리 (`torch`, `ultralytics`, `cv2`, `ffmpeg`, `PIL`, `uvicorn`)
  3. multiprocessing `spawn` 자식 프로세스에서만 필요한 모듈
- 지역 import는 사용 직전, 해당 블록 맨 위에 둔다.

---

## 6. 타입 힌트

- public API의 인자·반환값에는 타입 힌트를 단다. 특히 DTO, 설정, 스토리지, Protocol, REST 계층.
- 사용 스타일: `Optional[str]`, `List[ChannelDTO]`, `Dict[type, Any]`, `ObjectStat | None`, `Iterable[str]`, `Sequence[tuple[str, str]]`.
- Python ≥ 3.10 (`common_lib/pyproject.toml`), `X | None` 문법 사용 가능.
- 순환 참조 때문에 import가 어려운 타입은 힌트를 생략하거나 문자열 힌트(`-> "ServingServer"`)를 쓴다.

---

## 7. 예외 처리

- 표준 예외를 의미에 맞게 던지고 메시지는 **영어 f-string**으로 쓴다.
  - `FileNotFoundError(f"Config file not found: {self.path}")`
  - `KeyError(f"Config not found: [{section}] {key}")`
  - `ValueError("func must not be None")`
  - `RuntimeError(f"{cls.__name__} must be created via {cls.__name__}.instance(...)")`
- 처리하지 못하는 예외는 bare `raise`로 다시 던진다. `raise e`보다 `raise`를 쓴다.
- 외부 라이브러리 에러는 코드값으로 분기한 뒤 나머지는 재던짐:

```python
except ClientError as e:
    code = e.response.get("Error", {}).get("Code", "")
    if code in ("404", "NoSuchKey", "NotFound"):
        return None
    raise
```

- `except Exception: pass`는 **정리(cleanup) 코드(`finally` 안의 임시파일 삭제 등)에서만** 허용한다.

---

## 8. 출력 · 로그

- 현재 `logging` 모듈을 쓰지 않고 `print`로 로그를 남긴다. 새 코드도 같은 형식을 따른다.
- 형식: `"<Class>::<Method> ..."` 또는 `"[<Class>] ..."`

```python
print("RunningState::Enter")
print(f"[InferenceManager] Loading model: {localModelPath} (device={self._device})")
```

- 시크릿(access key, secret key, token)은 출력하지 않는다.

---

## 9. 주석 · 문서화

- 주석과 docstring은 **한국어**로 쓴다. 예외 메시지는 영어.
- docstring은 `"""` 짧은 설명. 인자 설명이 필요하면 들여쓴 목록으로 적는다.
- 절차형 코드의 단계 구분은 `## 단계명` 또는 `# 1) 단계명` 형식을 쓴다.

```python
## 이미지 변환
self._TransForm(localOutDirPath=out_path, s3FilePath=tmpFileName)

## 이미지 업로드
S3Utils.UploadFolder(...)
```

- 함수 호출 시 인자가 2개 이상이면 키워드 인자를 우선 사용한다: `ChangeState(state_id=..., stateEnterData=...)`.

---

## 10. 진입점 · 멀티프로세스

```python
def main():
    from common_lib.Path.BasePath import BasePath
    from common_lib.Config.ConfigLoader import ConfigLoader
    from Defines.Defines import Defines

    config_file = BasePath.instance().File(Defines.CONFIG_FILE_NAME)
    configLoader = ConfigLoader.instance(config_file)
    ...


if __name__ == '__main__':
    import multiprocessing as mp
    mp.set_start_method("spawn", force=True)

    main()
```

- 멀티프로세스를 쓰는 진입점은 `spawn` 방식을 강제한다. 프로세스 간 전달 객체는 pickle 가능해야 한다.
- 경로는 `BasePath.instance()`의 `Path/Dir/File`, S3 키는 `S3PathUtil`로 만든다. 문자열 직접 결합을 피한다.

---

## 11. 영역별 예외 (기존 스타일 유지)

| 영역 | 스타일 |
|---|---|
| `app/serving` Controller/Service/Server | FastAPI 관례에 맞춘 snake_case 메서드 (`register`, `add_controller`, `build`, `infer`, `infer_vis`), 엔드포인트 함수도 snake_case |
| `common_lib/ObjectStorage` | 파일시스템 유사 소문자 API (`ls`, `walk`, `puts`, `get`, `stat`, `exists`, `delete`, `mkdir`) |
| `Modules/Extrator/ImageExtractor*` | ffmpeg 래퍼, snake_case 메서드 (`extract_fps`, `_get_rotation`) |
| `SingletonBase` | `instance`, `reset_instance`, `reset_all` |

이 영역 밖의 새 코드는 1~10의 규칙(PascalCase 메서드)을 따른다.

---

## 12. 새 코드에서 피할 것

기존 코드에 남아 있지만 새로 작성/수정하는 코드에서는 따르지 않는다.

- `== None`, `== False` 비교 → `is None`, `not x`
- 메서드/클래스 끝의 불필요한 `pass` (본문이 있으면 넣지 않는다. 빈 클래스에만 `pass`)
- 주석 처리된 죽은 코드 블록(`# def main(): ...`)을 커밋하지 않는다
- 콤마 앞 공백·괄호 안쪽 공백 (`f(a , b)`, `( x )`) → PEP 8 공백 (`f(a, b)`)
- 연속 빈 줄 3줄 이상 → 최상위 정의 사이 2줄, 메서드 사이 1줄
- 파일 시작의 빈 줄
- 오타가 있는 새 이름 (`Currnet`, `Chennel`, `Processs` 등). 기존 공개 이름의 오타는 호출부가 있으므로 별도 작업 없이 임의로 바꾸지 않는다.

---

## 작업 체크리스트

코드를 작성·수정한 뒤 확인한다.

- [ ] 파일명 = 클래스명 (PascalCase), 올바른 패키지에 위치
- [ ] `I`/`ab`/`E_`/`c` 접두어와 역할 접미사가 맞는가
- [ ] public 메서드 PascalCase, 멤버 `self._camelCase`, 로컬 camelCase, 값 인자 snake_case
- [ ] 상수는 `IENUM` 기반 Define 클래스에 정의했는가 (매직 문자열 없음)
- [ ] 싱글톤은 `.instance()`로만 접근하는가
- [ ] 절대 import, 순환·무거운 모듈은 지역 import
- [ ] 추상 메서드는 `raise NotImplementedError`, 다중 상속은 부모 `__init__` 명시 호출
- [ ] 예외 메시지는 영어 f-string, 주석은 한국어
- [ ] 12번 "피할 것" 항목이 없는가
- [ ] 영역별 예외(serving, ObjectStorage 등)에 해당하면 그 영역 스타일을 유지했는가
