"""VDB 웹 서버(백엔드 API + 프런트엔드) 진입점.

    python scripts/web_server.py                       # 127.0.0.1:8080, VDB_MODE 환경변수로 Chroma 접속
    python scripts/web_server.py --host 0.0.0.0        # 다른 PC 에서 접속 허용
    $env:VDB_MODE="http"; python scripts/web_server.py # 실행 중인 Chroma 서버(VDB_HOST:VDB_PORT)에 접속

보통은 scripts/start_web.ps1 로 Chroma 서버와 함께 띄운다.
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


def main():
    import uvicorn

    from vdb.Defines.ServingDefine import ServingDefine
    from vdb.Serving.VdbWebServer import VdbWebServer

    parser = argparse.ArgumentParser(description="VDB web server")
    parser.add_argument("--host", default=os.getenv(ServingDefine.E_ENV.VDB_WEB_HOST, ServingDefine.DEFAULT_WEB_HOST))
    parser.add_argument("--port", type=int,
                        default=int(os.getenv(ServingDefine.E_ENV.VDB_WEB_PORT, str(ServingDefine.DEFAULT_WEB_PORT))))
    args = parser.parse_args()

    webServer = VdbWebServer()
    app = webServer.build()
    print(f"[web_server] chroma={webServer.get_service().get_status().chroma_target} "
          f"-> http://{args.host}:{args.port}  (API 문서: /api/docs)")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == '__main__':
    main()
