﻿# start_server.ps1 로 띄운 Chroma 서버 종료
$Root = Split-Path -Parent $PSScriptRoot
$PidFile = Join-Path $Root "run\chroma.pid"
if (-not (Test-Path $PidFile)) { Write-Host "[chroma] PID 파일 없음 (실행 중 아님)"; exit 0 }
$procId = Get-Content $PidFile
$p = Get-Process -Id $procId -ErrorAction SilentlyContinue
if ($p) { Stop-Process -Id $procId -Force; Write-Host "[chroma] 종료 PID=$procId" } else { Write-Host "[chroma] 프로세스 없음 (PID=$procId)" }
Remove-Item $PidFile -Force
