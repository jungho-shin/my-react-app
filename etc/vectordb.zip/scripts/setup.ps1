﻿# Python 3.11 가상환경 생성 + 의존성 설치 (관리자 권한 불필요)
param([string]$PythonVersion = "3.11")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "[setup] venv 생성 (Python $PythonVersion)"
    py -$PythonVersion -m venv .venv
}
& .\.venv\Scripts\python.exe -m pip install --upgrade pip -q
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt -q
& .\.venv\Scripts\python.exe -c "import chromadb, sys; print('[setup] python', sys.version.split()[0], '/ chromadb', chromadb.__version__)"

Write-Host "[setup] 기본 임베딩 모델(all-MiniLM-L6-v2) 사전 다운로드"
& .\.venv\Scripts\python.exe -c "from chromadb.utils.embedding_functions import DefaultEmbeddingFunction as E; print('[setup] dim =', len(E()(['warmup'])[0]))"

Write-Host "[setup] 한국어(다국어) 임베딩 모델(multilingual-e5-small, ONNX ~470MB) 사전 다운로드"
& .\.venv\Scripts\python.exe -c "import sys; sys.path.insert(0, 'src'); from vdb import MultilingualOnnxEmbeddingFunction as E; print('[setup] dim =', len(E('e5-small')(['준비'])[0]))"
Write-Host "[setup] 완료"
