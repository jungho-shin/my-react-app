﻿# Chroma 서버 + 웹 서버(백엔드 API + 프런트엔드)를 백그라운드로 기동
#   브라우저 → 웹 서버(:8080) → Chroma 서버(127.0.0.1:8000)
# Chroma 가 꺼져 있으면 이 PC 전용(127.0.0.1)으로 먼저 띄운다. 사용자는 웹 서버로만 접속한다.
param(
    # 0.0.0.0 = 다른 PC 에서도 웹 접속 허용. 이 PC 전용: -WebHost 127.0.0.1
    [string]$WebHost = "0.0.0.0",
    [int]$WebPort = 8080,
    [int]$ChromaPort = 8000,
    [int]$TimeoutSec = 60
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$RunDir = Join-Path $Root "run"; $LogDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force $RunDir, $LogDir | Out-Null
$PidFile = Join-Path $RunDir "web.pid"

## 1) Chroma 서버
$chromaUp = $true
try { Invoke-RestMethod "http://127.0.0.1:${ChromaPort}/api/v2/heartbeat" -TimeoutSec 2 | Out-Null } catch { $chromaUp = $false }
if ($chromaUp) {
    Write-Host "[web] Chroma 서버 실행 중 (127.0.0.1:$ChromaPort)"
} else {
    & (Join-Path $PSScriptRoot "start_server.ps1") -BindHost 127.0.0.1 -Port $ChromaPort
}

## 2) 웹 서버
if (Test-Path $PidFile) {
    $old = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($old -and (Get-Process -Id $old -ErrorAction SilentlyContinue)) {
        Write-Host "[web] 이미 실행 중 (PID $old) http://127.0.0.1:${WebPort}"; exit 0
    }
    Remove-Item $PidFile -Force
}

$Python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "python.exe 없음. scripts\setup.ps1 을 먼저 실행하세요." }

# 자식 프로세스용 환경변수. 호출한 PowerShell 세션에 남지 않도록 끝나면 원래 값으로 되돌린다
$childEnv = @{ VDB_MODE = "http"; VDB_HOST = "127.0.0.1"; VDB_PORT = "$ChromaPort";
               PYTHONIOENCODING = "utf-8"; ANONYMIZED_TELEMETRY = "False" }
$savedEnv = @{}
foreach ($k in $childEnv.Keys) {
    $savedEnv[$k] = [Environment]::GetEnvironmentVariable($k, "Process")
    [Environment]::SetEnvironmentVariable($k, $childEnv[$k], "Process")
}
try {
    $proc = Start-Process -FilePath $Python `
        -ArgumentList @("`"$(Join-Path $Root 'scripts\web_server.py')`"", "--host", $WebHost, "--port", $WebPort) `
        -WorkingDirectory $Root `
        -RedirectStandardOutput (Join-Path $LogDir "web.out.log") `
        -RedirectStandardError  (Join-Path $LogDir "web.err.log") `
        -WindowStyle Hidden -PassThru
} finally {
    foreach ($k in $savedEnv.Keys) { [Environment]::SetEnvironmentVariable($k, $savedEnv[$k], "Process") }
}
$proc.Id | Set-Content $PidFile

$url = "http://127.0.0.1:${WebPort}/api/status"
$deadline = (Get-Date).AddSeconds($TimeoutSec)
while ((Get-Date) -lt $deadline) {
    if ($proc.HasExited) { throw "[web] 기동 실패 (exit $($proc.ExitCode)). logs\web.err.log 확인" }
    try { $r = Invoke-RestMethod -Uri $url -TimeoutSec 2 } catch { Start-Sleep -Milliseconds 500; continue }
    Write-Host "[web] 기동 완료 PID=$($proc.Id) chroma_ok=$($r.chroma_ok) (chroma $($r.chroma_target))"
    Write-Host "[web] 브라우저에서 열기: http://127.0.0.1:${WebPort}"
    if ($WebHost -eq "0.0.0.0") {
        $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } | Select-Object -ExpandProperty IPAddress
        Write-Host "[web] 다른 PC 에서 접속할 주소:"
        foreach ($ip in $ips) { Write-Host "         http://${ip}:${WebPort}" }
        Write-Host "[web] 주의: 로그인 기능이 없습니다. 신뢰할 수 있는 내부망에서만 사용하세요."
    }
    exit 0
}
throw "[web] ${TimeoutSec}초 내에 응답 없음. logs\web.err.log 확인"
