﻿# Chroma HTTP 서버를 백그라운드 프로세스로 기동 (Docker/WSL/서비스 등록 없음)
param(
    [string]$BindHost = "127.0.0.1",
    [int]$Port = 8000,
    [string]$DataDir = "",
    [int]$TimeoutSec = 60
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not $DataDir) { $DataDir = Join-Path $Root "data\chroma" }
$RunDir = Join-Path $Root "run"; $LogDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force $RunDir, $LogDir, $DataDir | Out-Null
$PidFile = Join-Path $RunDir "chroma.pid"

if (Test-Path $PidFile) {
    $old = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($old -and (Get-Process -Id $old -ErrorAction SilentlyContinue)) {
        Write-Host "[chroma] 이미 실행 중 (PID $old)"; exit 0
    }
    Remove-Item $PidFile -Force
}

$Exe = Join-Path $Root ".venv\Scripts\chroma.exe"
if (-not (Test-Path $Exe)) { throw "chroma.exe 없음. scripts\setup.ps1 을 먼저 실행하세요." }

$env:ANONYMIZED_TELEMETRY = "False"
$proc = Start-Process -FilePath $Exe `
    -ArgumentList @("run", "--path", "`"$DataDir`"", "--host", $BindHost, "--port", $Port) `
    -RedirectStandardOutput (Join-Path $LogDir "chroma.out.log") `
    -RedirectStandardError  (Join-Path $LogDir "chroma.err.log") `
    -WindowStyle Hidden -PassThru
$proc.Id | Set-Content $PidFile

$url = "http://${BindHost}:${Port}/api/v2/heartbeat"
$deadline = (Get-Date).AddSeconds($TimeoutSec)
while ((Get-Date) -lt $deadline) {
    if ($proc.HasExited) { throw "[chroma] 기동 실패 (exit $($proc.ExitCode)). logs\chroma.err.log 확인" }
    try { $r = Invoke-RestMethod -Uri $url -TimeoutSec 2; Write-Host "[chroma] 기동 완료 PID=$($proc.Id) $url -> $($r | ConvertTo-Json -Compress)"; exit 0 } catch { Start-Sleep -Milliseconds 500 }
}
throw "[chroma] ${TimeoutSec}초 내에 응답 없음"
