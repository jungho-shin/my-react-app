﻿# 전체 테스트 실행. 예) .\scripts\test.ps1 -m "not model"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
& .\.venv\Scripts\python.exe -m pytest @args
exit $LASTEXITCODE
