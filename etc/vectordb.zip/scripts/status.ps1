﻿param([string]$BindHost = "127.0.0.1", [int]$Port = 8000)
try {
    $hb = Invoke-RestMethod "http://${BindHost}:${Port}/api/v2/heartbeat" -TimeoutSec 2
    $ver = Invoke-RestMethod "http://${BindHost}:${Port}/api/v2/version" -TimeoutSec 2
    Write-Host "[chroma] UP  version=$ver heartbeat=$($hb | ConvertTo-Json -Compress)"
} catch { Write-Host "[chroma] DOWN ($BindHost`:$Port)"; exit 1 }
