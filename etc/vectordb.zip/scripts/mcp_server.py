"""Claude Code 용 VDB MCP 서버 진입점 (stdio).

Claude Code 가 .mcp.json 설정으로 직접 실행한다. 웹 서버(scripts/start_web.ps1)가 떠 있어야 검색된다.
    VDB_WEB_URL : 웹 서버 주소 (기본 http://127.0.0.1:8080)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


def main():
    from vdb.Mcp.VdbMcpServer import VdbMcpServer

    VdbMcpServer().Build().run("stdio")


if __name__ == '__main__':
    main()
