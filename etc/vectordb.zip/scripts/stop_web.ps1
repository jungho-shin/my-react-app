﻿# start_web.ps1 로 띄운 웹 서버 종료. -All 이면 Chroma 서버도 함께 종료
param([switch]$All)
$Root = Split-Path -Parent $PSScriptRoot
$PidFile = Join-Path $Root "run\web.pid"
if (Test-Path $PidFile) {
    $procId = Get-Content $PidFile
    $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
    if ($p) { taskkill /PID $procId /T /F | Out-Null; Write-Host "[web] 종료 PID=$procId (자식 프로세스 포함)" } else { Write-Host "[web] 프로세스 없음 (PID=$procId)" }
    Remove-Item $PidFile -Force
} else {
    Write-Host "[web] PID 파일 없음 (실행 중 아님)"
}
if ($All) { & (Join-Path $PSScriptRoot "stop_server.ps1") }
