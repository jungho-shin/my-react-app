"""다국어 ONNX 임베딩(multilingual-e5-small)으로 한국어 의미 검색."""
import uuid

import numpy as np
import pytest

from vdb.Embedding.MultilingualOnnxEmbeddingFunction import MultilingualOnnxEmbeddingFunction

pytestmark = pytest.mark.model

DOCS = {
    "pet": "고양이가 소파 위에서 낮잠을 자고 있다.",
    "rate": "한국은행이 물가 상승을 억제하기 위해 기준금리를 인상했다.",
    "space": "누리호가 인공위성을 지구 저궤도에 올려놓았다.",
    "food": "김치찌개는 돼지고기와 묵은지를 넣고 끓인다.",
}


@pytest.fixture(scope="module")
def ef():
    return MultilingualOnnxEmbeddingFunction("e5-small")


def test_vectors_are_normalized_and_prefixed(ef):
    p = np.array(ef(["테스트 문장"])[0])
    q = np.array(ef.embed_query(["테스트 문장"])[0])
    assert p.shape == (384,)
    assert abs(np.linalg.norm(p) - 1) < 1e-4
    assert not np.allclose(p, q)  # passage:/query: 접두어로 서로 다른 벡터


def test_korean_semantic_search(client, ef):
    name = f"ko-{uuid.uuid4().hex[:8]}"
    col = client.create_collection(name, embedding_function=ef, configuration={"hnsw": {"space": "cosine"}})
    try:
        col.add(ids=list(DOCS), documents=list(DOCS.values()))
        queries = ["반려동물이 자는 모습", "이자율 정책", "로켓 발사", "저녁 메뉴", "interest rate hike"]
        r = col.query(query_texts=queries, n_results=1)
        assert [ids[0] for ids in r["ids"]] == ["pet", "rate", "space", "food", "rate"]

        # 컬렉션 설정에 임베딩 함수가 저장되어 재오픈 시 자동 복원
        again = client.get_collection(name)
        assert again.query(query_texts=["우주"], n_results=1)["ids"][0] == ["space"]
    finally:
        client.delete_collection(name)


def test_model_change_rejected(ef):
    with pytest.raises(ValueError):
        ef.validate_config_update({"model": "e5-small"}, {"model": "bge-m3"})
