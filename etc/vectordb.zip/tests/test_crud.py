import pytest

from conftest import DIM, rand_vecs


def _seed(col, rng, n=20):
    ids = [f"id-{i}" for i in range(n)]
    col.add(
        ids=ids,
        embeddings=rand_vecs(rng, n),
        documents=[f"document number {i}" for i in range(n)],
        metadatas=[{"i": i, "group": "even" if i % 2 == 0 else "odd"} for i in range(n)],
    )
    return ids


def test_add_and_count(collection, rng):
    _seed(collection, rng)
    assert collection.count() == 20


def test_get_by_ids_returns_payload(collection, rng):
    _seed(collection, rng)
    got = collection.get(ids=["id-3", "id-7"], include=["documents", "metadatas", "embeddings"])
    by_id = dict(zip(got["ids"], got["metadatas"]))
    assert by_id == {"id-3": {"i": 3, "group": "odd"}, "id-7": {"i": 7, "group": "odd"}}
    assert len(got["embeddings"][0]) == DIM


def test_update_metadata_and_document(collection, rng):
    _seed(collection, rng)
    collection.update(ids=["id-1"], embeddings=rand_vecs(rng, 1),
                      metadatas=[{"i": 1, "group": "changed"}], documents=["new text"])
    got = collection.get(ids=["id-1"], include=["documents", "metadatas"])
    assert got["metadatas"][0]["group"] == "changed"
    assert got["documents"][0] == "new text"


def test_update_document_without_embedding_requires_ef(collection, rng):
    """임베딩 함수 없는 컬렉션에서 document 만 바꾸면 벡터를 재계산할 수 없어 오류가 나야 한다."""
    _seed(collection, rng, n=2)
    with pytest.raises(ValueError, match="embedding function"):
        collection.update(ids=["id-1"], documents=["new text"])


def test_update_metadata_only(collection, rng):
    _seed(collection, rng, n=2)
    collection.update(ids=["id-1"], metadatas=[{"i": 1, "group": "meta-only"}])
    assert collection.get(ids=["id-1"], include=["metadatas"])["metadatas"][0]["group"] == "meta-only"


def test_upsert_inserts_and_overwrites(collection, rng):
    _seed(collection, rng, n=5)
    collection.upsert(ids=["id-0", "id-new"], embeddings=rand_vecs(rng, 2),
                      metadatas=[{"v": 2}, {"v": 1}])
    assert collection.count() == 6
    assert collection.get(ids=["id-0"], include=["metadatas"])["metadatas"][0]["v"] == 2


def test_delete_by_id_and_where(collection, rng):
    _seed(collection, rng)
    collection.delete(ids=["id-0"])
    assert collection.count() == 19
    collection.delete(where={"group": "odd"})
    remaining = collection.get(include=["metadatas"])["metadatas"]
    assert len(remaining) == 9 and all(m["group"] == "even" for m in remaining)


def test_dimension_mismatch_rejected(collection, rng):
    _seed(collection, rng, n=2)
    with pytest.raises(Exception):
        collection.add(ids=["bad"], embeddings=[[0.1] * (DIM + 1)])


def test_collection_lifecycle(client):
    name = "lifecycle-test"
    client.get_or_create_collection(name, embedding_function=None)
    assert name in [c.name for c in client.list_collections()]
    client.delete_collection(name)
    assert name not in [c.name for c in client.list_collections()]
