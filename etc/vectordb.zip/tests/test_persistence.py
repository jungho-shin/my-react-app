import chromadb
import pytest
from chromadb.api.shared_system_client import SharedSystemClient

from conftest import no_telemetry, rand_vecs


def test_embedded_data_survives_client_reopen(tmp_path, rng):
    path = str(tmp_path / "persist")
    c1 = chromadb.PersistentClient(path=path, settings=no_telemetry())
    c1.create_collection("persist-me", embedding_function=None).add(
        ids=["a", "b"], embeddings=rand_vecs(rng, 2))
    del c1
    SharedSystemClient.clear_system_cache()  # 프로세스 내 캐시 제거 → 디스크에서 다시 로딩

    c2 = chromadb.PersistentClient(path=path, settings=no_telemetry())
    assert c2.get_collection("persist-me").count() == 2


@pytest.mark.server
def test_server_data_survives_restart(server_factory, rng):
    srv = server_factory().start()
    srv.client().create_collection("restart-me", embedding_function=None).add(
        ids=[str(i) for i in range(10)], embeddings=rand_vecs(rng, 10))
    srv.stop()
    srv.start()
    assert srv.client().get_collection("restart-me").count() == 10
