"""기본 임베딩 함수(ONNX all-MiniLM-L6-v2, 영어 모델)로 텍스트를 그대로 적재/검색."""
import uuid

import pytest

pytestmark = pytest.mark.model

DOCS = {
    "pets": "Cats and dogs are popular household pets.",
    "finance": "The central bank raised interest rates to fight inflation.",
    "space": "The rocket launched the satellite into low earth orbit.",
}


def test_text_semantic_search(client):
    col = client.create_collection(f"text-{uuid.uuid4().hex[:8]}")  # 기본 임베딩 함수
    try:
        col.add(ids=list(DOCS), documents=list(DOCS.values()))
        r = col.query(query_texts=["my kitten sleeps on the sofa", "stock market and money"],
                      n_results=1)
        assert [ids[0] for ids in r["ids"]] == ["pets", "finance"]
    finally:
        client.delete_collection(col.name)
