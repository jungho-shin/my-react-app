import numpy as np
import pytest

from conftest import rand_vecs


@pytest.fixture
def seeded(collection, rng):
    vecs = rand_vecs(rng, 200)
    collection.add(
        ids=[f"v{i}" for i in range(200)],
        embeddings=vecs,
        metadatas=[{"bucket": i % 4, "score": float(i)} for i in range(200)],
        documents=[("apple " if i % 10 == 0 else "") + f"item {i}" for i in range(200)],
    )
    return collection, np.array(vecs)


def test_self_query_returns_itself_first(seeded):
    col, vecs = seeded
    r = col.query(query_embeddings=[vecs[17].tolist()], n_results=3, include=["distances"])
    assert r["ids"][0][0] == "v17"
    assert r["distances"][0][0] == pytest.approx(0.0, abs=1e-4)


def test_results_sorted_by_distance(seeded):
    col, vecs = seeded
    r = col.query(query_embeddings=[vecs[0].tolist()], n_results=10, include=["distances"])
    d = r["distances"][0]
    assert d == sorted(d)


def test_matches_bruteforce_cosine(seeded, rng):
    col, vecs = seeded
    q = np.array(rand_vecs(rng, 1)[0])
    expected = {f"v{i}" for i in np.argsort(1 - vecs @ q)[:10]}
    r = col.query(query_embeddings=[q.tolist()], n_results=10)
    # 200건 규모에서 HNSW 는 사실상 정확해야 함 (recall@10 >= 0.9)
    assert len(set(r["ids"][0]) & expected) >= 9


def test_query_with_metadata_filter(seeded):
    col, vecs = seeded
    r = col.query(
        query_embeddings=[vecs[0].tolist()], n_results=20,
        where={"$and": [{"bucket": 1}, {"score": {"$lt": 100}}]}, include=["metadatas"],
    )
    metas = r["metadatas"][0]
    assert metas and all(m["bucket"] == 1 and m["score"] < 100 for m in metas)


def test_query_with_document_filter(seeded):
    col, vecs = seeded
    r = col.query(query_embeddings=[vecs[5].tolist()], n_results=50,
                  where_document={"$contains": "apple"}, include=["documents"])
    docs = r["documents"][0]
    assert len(docs) == 20 and all("apple" in d for d in docs)


def test_batch_query(seeded):
    col, vecs = seeded
    r = col.query(query_embeddings=vecs[:5].tolist(), n_results=1)
    assert [ids[0] for ids in r["ids"]] == [f"v{i}" for i in range(5)]


@pytest.mark.parametrize("space", ["l2", "ip", "cosine"])
def test_distance_spaces(client, rng, space):
    col = client.create_collection(f"space-{space}", configuration={"hnsw": {"space": space}},
                                   embedding_function=None)
    try:
        vecs = np.array(rand_vecs(rng, 50))
        col.add(ids=[str(i) for i in range(50)], embeddings=vecs.tolist())
        r = col.query(query_embeddings=[vecs[3].tolist()], n_results=1, include=["distances"])
        assert r["ids"][0][0] == "3"
        # Chroma 정의: l2 = 제곱 L2, ip = 1 - dot, cosine = 1 - cos  → 정규화 벡터 자기 자신은 0
        assert r["distances"][0][0] == pytest.approx(0.0, abs=1e-4)
    finally:
        client.delete_collection(col.name)
