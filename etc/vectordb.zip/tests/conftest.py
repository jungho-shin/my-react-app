"""공용 fixture.

- client         : embedded(PersistentClient) / http(HttpClient) 두 모드로 파라미터화
- collection     : 테스트마다 고유 이름의 컬렉션(cosine, 임베딩 함수 없음) 생성 후 삭제
- chroma_server  : 세션 단위로 chroma.exe 서버 프로세스를 임시 디렉터리/빈 포트로 기동
- server_factory : 독립 서버가 필요한 테스트(재시작 영속성 등)용
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

import chromadb
import httpx
import numpy as np
import pytest
from chromadb.config import Settings

DIM = 32
CHROMA_EXE = Path(sys.executable).parent / ("chroma.exe" if os.name == "nt" else "chroma")


def no_telemetry() -> Settings:
    # 주의: HttpClient 는 전달받은 Settings 객체에 host/port 를 기록(변경)하므로 매번 새로 생성해야 함
    return Settings(anonymized_telemetry=False)


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@dataclass
class ServerHandle:
    host: str
    port: int
    data_dir: Path
    proc: subprocess.Popen | None = None

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def start(self, timeout: float = 60.0) -> ServerHandle:
        log = open(self.data_dir.parent / f"chroma-{self.port}.log", "ab")
        env = {**os.environ, "ANONYMIZED_TELEMETRY": "False"}
        self.proc = subprocess.Popen(
            [str(CHROMA_EXE), "run", "--path", str(self.data_dir),
             "--host", self.host, "--port", str(self.port)],
            stdout=log, stderr=subprocess.STDOUT, env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError(f"chroma server exited with {self.proc.returncode}")
            try:
                if httpx.get(f"{self.url}/api/v2/heartbeat", timeout=1).status_code == 200:
                    return self
            except httpx.HTTPError:
                pass
            time.sleep(0.3)
        self.stop()
        raise TimeoutError("chroma server did not become ready")

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
        self.proc = None

    def client(self):
        return chromadb.HttpClient(host=self.host, port=self.port, settings=no_telemetry())


@pytest.fixture(scope="session")
def server_factory(tmp_path_factory):
    started: list[ServerHandle] = []

    def make(data_dir: Path | None = None) -> ServerHandle:
        d = data_dir or tmp_path_factory.mktemp("chroma-srv") / "data"
        d.mkdir(parents=True, exist_ok=True)
        h = ServerHandle("127.0.0.1", free_port(), d)
        started.append(h)
        return h

    yield make
    for h in started:
        h.stop()


@pytest.fixture(scope="session")
def chroma_server(server_factory):
    return server_factory().start()


@pytest.fixture(params=["embedded", pytest.param("http", marks=pytest.mark.server)])
def client(request, tmp_path):
    if request.param == "embedded":
        return chromadb.PersistentClient(path=str(tmp_path / "chroma"), settings=no_telemetry())
    return request.getfixturevalue("chroma_server").client()


@pytest.fixture
def collection(client):
    name = f"test-{uuid.uuid4().hex[:12]}"
    col = client.create_collection(
        name, configuration={"hnsw": {"space": "cosine"}}, embedding_function=None
    )
    yield col
    try:
        client.delete_collection(name)
    except Exception:
        pass


@pytest.fixture
def rng():
    return np.random.default_rng(42)


def rand_vecs(rng, n: int, dim: int = DIM) -> list[list[float]]:
    v = rng.standard_normal((n, dim)).astype(np.float32)
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    return v.tolist()
