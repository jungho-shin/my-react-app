import chromadb
import numpy as np
from chromadb.api.shared_system_client import SharedSystemClient

from conftest import no_telemetry


def test_hnsw_configuration_applied_and_modifiable(client):
    name = "hnsw-config"
    col = client.create_collection(
        name,
        configuration={"hnsw": {"space": "cosine", "ef_construction": 128,
                                "ef_search": 64, "max_neighbors": 24}},
        embedding_function=None,
    )
    try:
        hnsw = client.get_collection(name).configuration["hnsw"]
        assert (hnsw["space"], hnsw["ef_construction"], hnsw["ef_search"], hnsw["max_neighbors"]) \
            == ("cosine", 128, 64, 24)
        col.modify(configuration={"hnsw": {"ef_search": 256}})
        assert client.get_collection(name).configuration["hnsw"]["ef_search"] == 256
    finally:
        client.delete_collection(name)


def _recall(col, base, queries, k=10):
    gt = np.argsort(-(queries @ base.T), axis=1)[:, :k]
    hits = 0
    for q, truth in zip(queries, gt):
        ids = col.query(query_embeddings=[q], n_results=k, include=[])["ids"][0]
        hits += len({int(i) for i in ids} & set(truth.tolist()))
    return hits / (len(queries) * k)


def test_ef_search_modify_takes_effect_after_reopen(tmp_path):
    """chromadb 1.5.9: modify(ef_search) 는 저장만 되고, 로드된 인덱스에는 재오픈 후 반영된다.

    벤치마크/튜닝 시 ef_search 를 바꿨다면 클라이언트(또는 서버)를 다시 열어야 한다.
    """
    rng = np.random.default_rng(0)
    base = rng.standard_normal((5000, 64)).astype(np.float32)
    base /= np.linalg.norm(base, axis=1, keepdims=True)
    queries = base[:100] + 0.3 * rng.standard_normal((100, 64)).astype(np.float32)
    queries /= np.linalg.norm(queries, axis=1, keepdims=True)

    path = str(tmp_path / "ef")
    c = chromadb.PersistentClient(path=path, settings=no_telemetry())
    col = c.create_collection("ef-test", embedding_function=None,
                              configuration={"hnsw": {"space": "cosine", "ef_search": 10}})
    col.add(ids=[str(i) for i in range(len(base))], embeddings=base)
    col.modify(configuration={"hnsw": {"ef_search": 400}})

    SharedSystemClient.clear_system_cache()
    reopened = chromadb.PersistentClient(path=path, settings=no_telemetry()).get_collection("ef-test")
    assert reopened.configuration["hnsw"]["ef_search"] == 400
    assert _recall(reopened, base, queries) >= 0.98
