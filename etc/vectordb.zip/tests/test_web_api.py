"""웹 백엔드(FastAPI) 통합 테스트.

- 유틸(청크 분할·파일 파싱)은 모델 없이 실행
- API 테스트는 multilingual-e5-small 모델이 필요(model 마커)하며 embedded / http 두 모드로 실행
"""
from __future__ import annotations

import json
import socket

import pytest
from fastapi.testclient import TestClient

from vdb.Dtos.VdbSettingsDto import VdbSettingsDto
from vdb.Serving.VdbWebServer import VdbWebServer
from vdb.Utils.DocumentImportHelper import DocumentImportHelper
from vdb.Utils.TextChunkHelper import TextChunkHelper

DOCS = [
    {"id": "pet", "document": "고양이가 소파 위에서 낮잠을 자고 있다.", "metadata": {"category": "생활"}},
    {"id": "rate", "document": "한국은행이 물가 상승을 억제하기 위해 기준금리를 인상했다.",
     "metadata": {"category": "경제", "year": 2024}},
    {"id": "space", "document": "누리호가 인공위성을 지구 저궤도에 올려놓았다.", "metadata": {"category": "과학", "year": 2023}},
    {"id": "food", "document": "김치찌개는 돼지고기와 묵은지를 넣고 끓인다.", "metadata": {"category": "생활"}},
]


# ---------- 유틸 (모델 불필요) ----------

def test_chunk_split_respects_size_and_overlap():
    text = "\n\n".join(f"{i}번째 문단입니다. " * 20 for i in range(5))
    chunks = TextChunkHelper.Split(text, chunk_size=200, chunk_overlap=20)
    assert len(chunks) > 5
    assert all(len(c) <= 200 for c in chunks)
    assert "".join(chunks).count("4번째") >= 20


def test_chunk_split_rejects_bad_overlap():
    with pytest.raises(ValueError):
        TextChunkHelper.Split("abc", chunk_size=100, chunk_overlap=100)


def test_import_parse_formats():
    lines = DocumentImportHelper.Parse("첫 줄\n\n둘째 줄\n", "lines", source_name="a.txt")
    assert [i["document"] for i in lines] == ["첫 줄", "둘째 줄"]
    assert lines[0]["metadata"] == {"source": "a.txt"}

    csvItems = DocumentImportHelper.Parse("﻿id,document,category,year\nx1,문서1,경제,2024\n,문서2,,\n", "csv")
    assert csvItems[0] == {"id": "x1", "document": "문서1", "metadata": {"category": "경제", "year": 2024}}
    assert csvItems[1] == {"id": None, "document": "문서2", "metadata": {}}

    jsonl = '{"id": "j1", "document": "가", "metadata": {"k": 1}}\n{"document": "나"}\n'
    assert [i["id"] for i in DocumentImportHelper.Parse(jsonl, "jsonl")] == ["j1", None]

    with pytest.raises(ValueError, match="line 1"):
        DocumentImportHelper.Parse('{"text": "x"}', "jsonl")
    with pytest.raises(ValueError, match="document"):
        DocumentImportHelper.Parse("a,b\n1,2", "csv")


# ---------- API ----------

def _make_app(settings: VdbSettingsDto) -> TestClient:
    return TestClient(VdbWebServer(settings=settings, default_model="e5-small").build())


@pytest.fixture(params=["embedded", pytest.param("http", marks=pytest.mark.server)])
def web(request, tmp_path):
    if request.param == "embedded":
        settings = VdbSettingsDto().SetDTO(mode="embedded", data_dir=tmp_path / "chroma", host="", port=0)
    else:
        server = request.getfixturevalue("chroma_server")
        settings = VdbSettingsDto().SetDTO(mode="http", data_dir=tmp_path, host=server.host, port=server.port)
    with _make_app(settings) as client:
        yield client


@pytest.fixture
def col(web, request):
    name = f"web-{request.node.name.split('[')[0][-30:].replace('_', '-')}"
    res = web.post("/api/collections", json={"name": name, "model": "e5-small", "description": "테스트"})
    assert res.status_code == 201, res.text
    yield name
    web.delete(f"/api/collections/{name}")


def test_status_and_frontend(web):
    status = web.get("/api/status").json()
    assert status["chroma_ok"] is True
    assert "e5-small" in status["models"]
    page = web.get("/")
    assert page.status_code == 200 and "VDB Web" in page.text
    assert web.get("/app.js").status_code == 200


@pytest.mark.model
def test_collection_lifecycle(web, col):
    info = web.get(f"/api/collections/{col}").json()["collection"]
    assert info == {"name": col, "count": 0, "model": "e5-small", "space": "cosine", "description": "테스트"}
    assert col in [c["name"] for c in web.get("/api/collections").json()["collections"]]

    dup = web.post("/api/collections", json={"name": col})
    assert dup.status_code == 409 and dup.json()["response"]["code"] == "CONFLICT"
    assert web.post("/api/collections", json={"name": "a"}).status_code == 400
    assert web.post("/api/collections", json={"name": "abc", "model": "nope"}).status_code == 400
    assert web.get("/api/collections/no-such-col").status_code == 404


@pytest.mark.model
def test_add_and_search_korean(web, col):
    res = web.post(f"/api/collections/{col}/documents", json={"documents": DOCS})
    assert res.status_code == 201 and res.json()["count"] == 4

    hits = web.post(f"/api/collections/{col}/search", json={"query": "이자율 정책", "n_results": 2}).json()["hits"]
    assert hits[0]["id"] == "rate"
    assert hits[0]["similarity"] == pytest.approx(1 - hits[0]["distance"])
    assert hits[0]["metadata"] == {"category": "경제", "year": 2024}

    ## 메타데이터·본문 필터
    filtered = web.post(f"/api/collections/{col}/search",
                        json={"query": "반려동물", "where": {"category": "생활"}, "n_results": 10}).json()["hits"]
    assert {h["id"] for h in filtered} == {"pet", "food"}
    ranged = web.post(f"/api/collections/{col}/search",
                      json={"query": "뉴스", "where": {"year": {"$gte": 2024}}}).json()["hits"]
    assert [h["id"] for h in ranged] == ["rate"]
    contains = web.post(f"/api/collections/{col}/search", json={"query": "음식", "contains": "김치"}).json()["hits"]
    assert [h["id"] for h in contains] == ["food"]

    ## 잘못된 필터 / 중복 ID / 잘못된 메타데이터
    assert web.post(f"/api/collections/{col}/search", json={"query": "x", "where": {"$bad": 1}}).status_code == 400
    dupId = web.post(f"/api/collections/{col}/documents", json={"documents": [DOCS[0]]})
    assert dupId.status_code == 409
    badMeta = web.post(f"/api/collections/{col}/documents",
                       json={"documents": [{"document": "x", "metadata": {"k": {"nested": 1}}}]})
    assert badMeta.status_code == 400


@pytest.mark.model
def test_import_browse_update_delete(web, col):
    csvText = "document,category\n" + "\n".join(f"문서 {i} 번 내용,{'짝' if i % 2 == 0 else '홀'}" for i in range(25))
    res = web.post(f"/api/collections/{col}/documents/import",
                   json={"format": "csv", "content": csvText, "source_name": "data.csv", "metadata": {"batch": 1}})
    assert res.status_code == 201 and res.json()["count"] == 25

    longText = "\n\n".join("벡터 데이터베이스는 임베딩을 저장한다. " * 15 for _ in range(4))
    res = web.post(f"/api/collections/{col}/documents/import",
                   json={"format": "text", "content": longText, "chunk_size": 300, "chunk_overlap": 30})
    textCount = res.json()["count"]
    assert textCount >= 4

    ## 페이지 조회 + 본문 필터
    page = web.get(f"/api/collections/{col}/documents", params={"offset": 20, "limit": 10}).json()
    assert page["total"] == 25 + textCount and len(page["documents"]) == 10
    filtered = web.get(f"/api/collections/{col}/documents", params={"contains": "문서 1"}).json()
    assert filtered["total"] == 11  # 1, 10~19

    ## 수정: 빠진 메타데이터 키는 삭제되어야 한다
    target = web.get(f"/api/collections/{col}/documents", params={"limit": 1}).json()["documents"][0]
    assert target["metadata"]["source"] == "data.csv" and target["metadata"]["batch"] == 1
    updated = web.put(f"/api/collections/{col}/documents/{target['id']}",
                      json={"document": "수정된 문서", "metadata": {"category": "변경"}}).json()
    assert updated == {"id": target["id"], "document": "수정된 문서", "metadata": {"category": "변경"}}

    ## 삭제
    assert web.delete(f"/api/collections/{col}/documents/{target['id']}").status_code == 200
    assert web.get(f"/api/collections/{col}/documents/{target['id']}").status_code == 404
    assert web.delete(f"/api/collections/{col}/documents/{target['id']}").status_code == 404
    ids = [d["id"] for d in web.get(f"/api/collections/{col}/documents", params={"limit": 5}).json()["documents"]]
    assert web.post(f"/api/collections/{col}/documents/delete", json={"ids": ids + ["ghost"]}).json()["count"] == 5
    assert web.get(f"/api/collections/{col}").json()["collection"]["count"] == 25 + textCount - 6


def test_chroma_down_returns_503(tmp_path):
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    settings = VdbSettingsDto().SetDTO(mode="http", data_dir=tmp_path, host="127.0.0.1", port=port)
    with _make_app(settings) as client:
        assert client.get("/api/status").json()["chroma_ok"] is False
        res = client.get("/api/collections")
        assert res.status_code == 503
        assert res.json()["response"]["code"] == "UPSTREAM_ERROR"
        assert json.dumps(res.json())  # JSON 직렬화 가능


# ---------- 웹페이지 링크 등록 ----------

from vdb.Utils.HtmlTextExtractor import HtmlTextExtractor  # noqa: E402
from vdb.Utils.WebPageFetcher import WebPageFetcher  # noqa: E402

ARTICLE_HTML = """<!doctype html><html><head><title>사이트 제목</title>
<meta property="og:title" content="벡터 데이터베이스 소개"><style>.x{color:red}</style>
<script>var secret = "스크립트";</script></head>
<body><nav>홈 | 메뉴 | 로그인</nav>
<article><h1>벡터 데이터베이스</h1>
<p>벡터 데이터베이스는 임베딩 벡터를 저장하고 질문 벡터와 가장 비슷한 벡터를 빠르게 찾아 주는 데이터베이스다.</p>
<p>RAG 에서 검색(Retrieval)을 실제로 수행하는 부분이며, 검색 품질이 곧 답변 품질을 좌우한다.</p>
<p>대표적인 제품으로 Chroma, Pinecone, pgvector 등이 있고 HNSW 같은 근사 최근접 이웃 인덱스를 쓴다.</p>
</article><footer>Copyright 푸터</footer></body></html>"""


def test_html_extractor_keeps_article_only():
    title, text = HtmlTextExtractor.Extract(ARTICLE_HTML)
    assert title == "벡터 데이터베이스 소개"
    assert "임베딩 벡터를 저장" in text and "HNSW" in text
    for noise in ("스크립트", "메뉴", "푸터", "color:red"):
        assert noise not in text
    assert "\n\n" in text  # 문단 경계 유지


def test_url_guards():
    assert WebPageFetcher.NormalizeUrl("example.com/a#top") == "https://example.com/a"
    with pytest.raises(ValueError, match="http/https"):
        WebPageFetcher.NormalizeUrl("file:///C:/Windows/win.ini")
    for address in ("127.0.0.1", "::1", "169.254.169.254", "0.0.0.0", "::ffff:127.0.0.1"):
        assert WebPageFetcher.IsBlockedAddress(address), address
    assert not WebPageFetcher.IsBlockedAddress("192.168.0.10")
    ## 이 PC 의 Chroma 서버(127.0.0.1)를 웹 서버 경유로 건드릴 수 없어야 한다
    with pytest.raises(ValueError, match="not allowed"):
        WebPageFetcher.Fetch("http://127.0.0.1:8000/api/v2/heartbeat")
    with pytest.raises(ValueError, match="not allowed"):
        WebPageFetcher.Fetch("http://localhost:8000/")


def test_decode_euc_kr_by_meta_charset():
    html = '<html><head><meta charset="euc-kr"><title>제목</title></head><body><p>' + "한글 본문입니다. " * 5 + "</p></body></html>"
    page = WebPageFetcher._ToPage(url="http://x/a", body=html.encode("cp949"), content_type="text/html")
    assert page.GetTitle() == "제목" and "한글 본문입니다." in page.GetText()
    with pytest.raises(ValueError, match="Unsupported content type"):
        WebPageFetcher._ToPage(url="http://x/a.pdf", body=b"%PDF-1.7", content_type="application/pdf")


@pytest.fixture
def local_site(monkeypatch):
    """테스트용 로컬 웹 서버 (루프백 차단을 이 테스트에서만 해제)."""
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    pages = {"/article": ARTICLE_HTML.encode("utf-8")}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/blocked":
                self.send_response(403)
                self.send_header("cf-mitigated", "challenge")
                self.end_headers()
                self.wfile.write(b"<title>Just a moment...</title>")
                return
            if self.path == "/old":
                self.send_response(301)
                self.send_header("Location", "/article")
                self.end_headers()
                return
            body = pages.get(self.path)
            self.send_response(200 if body else 404)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(body or b"not found")

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    monkeypatch.setattr(WebPageFetcher, "IsBlockedAddress", staticmethod(lambda address: False))
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()


@pytest.mark.model
def test_import_url(web, col, local_site):
    path = f"/api/collections/{col}/documents/url"
    res = web.post(path, json={"url": f"{local_site}/old", "chunk_size": 120, "chunk_overlap": 10,
                               "metadata": {"category": "학습"}})
    assert res.status_code == 201, res.text
    body = res.json()
    assert body["url"] == f"{local_site}/article"  # 리다이렉트 후 최종 주소
    assert body["title"] == "벡터 데이터베이스 소개" and body["count"] >= 2

    meta = web.get(f"/api/collections/{col}/documents/{body['ids'][0]}").json()["metadata"]
    assert meta["source"] == body["url"] and meta["category"] == "학습" and meta["chunk_index"] == 0
    assert meta["domain"] == "127.0.0.1" and isinstance(meta["fetched_date"], int)

    hits = web.post(f"/api/collections/{col}/search", json={"query": "유사한 벡터 검색", "n_results": 1}).json()["hits"]
    assert hits[0]["id"].startswith("url-")

    ## 같은 URL 다시 → 409, replace → 교체
    assert web.post(path, json={"url": f"{local_site}/article", "chunk_size": 120, "chunk_overlap": 10}).status_code == 409
    again = web.post(path, json={"url": f"{local_site}/article", "chunk_size": 120, "chunk_overlap": 10,
                                 "replace": True}).json()
    assert again["replaced"] == body["count"] and again["ids"] == body["ids"]
    assert web.get(f"/api/collections/{col}").json()["collection"]["count"] == body["count"]

    ## 없는 페이지 / 막힌 주소는 400
    missing = web.post(path, json={"url": f"{local_site}/nope"})
    assert missing.status_code == 400 and "404" in missing.json()["response"]["message"]
    blocked = web.post(path, json={"url": f"{local_site}/blocked"})
    assert blocked.status_code == 400 and "bot protection" in blocked.json()["response"]["message"]


def test_import_parse_saved_html():
    items = DocumentImportHelper.Parse(ARTICLE_HTML, "html", source_name="page.html", chunk_size=120, chunk_overlap=10)
    assert len(items) >= 2
    assert all(i["metadata"]["title"] == "벡터 데이터베이스 소개" and i["metadata"]["source"] == "page.html" for i in items)
    assert not any("메뉴" in i["document"] or "스크립트" in i["document"] for i in items)
