"""Claude Code 용 MCP 서버 테스트.

FastAPI TestClient 를 MCP 서버의 HTTP 클라이언트로 넣어 웹 서버 프로세스 없이 전체 흐름을 검증한다.
"""
from __future__ import annotations

import asyncio
import socket

import pytest
from fastapi.testclient import TestClient
from mcp import Client

from vdb.Dtos.VdbSettingsDto import VdbSettingsDto
from vdb.Mcp.VdbMcpServer import VdbMcpServer
from vdb.Serving.VdbWebServer import VdbWebServer

DOCS = [
    {"id": "rate", "document": "한국은행이 물가 상승을 억제하기 위해 기준금리를 인상했다.",
     "metadata": {"category": "경제", "title": "금리 뉴스", "source": "news.txt"}},
    {"id": "pet", "document": "고양이가 소파 위에서 낮잠을 자고 있다.", "metadata": {"category": "생활"}},
    {"id": "space", "document": "누리호가 인공위성을 지구 저궤도에 올려놓았다.", "metadata": {"category": "과학"}},
]


def _call(server, tool: str, args: dict | None = None):
    async def run():
        async with Client(server) as client:
            return await client.call_tool(tool, args or {})

    result = asyncio.run(run())
    text = "\n".join(c.text for c in result.content if getattr(c, "text", None))
    return result.is_error, text


@pytest.fixture
def mcp_server(tmp_path):
    settings = VdbSettingsDto().SetDTO(mode="embedded", data_dir=tmp_path / "chroma", host="", port=0)
    with TestClient(VdbWebServer(settings=settings, default_model="e5-small", serve_frontend=False).build()) as web:
        yield VdbMcpServer(httpClient=web).Build(), web


def test_tools_are_listed_read_only(mcp_server):
    server, _ = mcp_server

    async def run():
        async with Client(server) as client:
            return await client.list_tools(), client.instructions

    tools, instructions = asyncio.run(run())
    names = {t.name for t in tools.tools}
    assert names == {"vdb_list_collections", "vdb_search", "vdb_get_document"}
    assert all(t.annotations and t.annotations.read_only_hint for t in tools.tools)
    assert "vdb_search" in (instructions or "")


def test_empty_collections_message(mcp_server):
    server, _ = mcp_server
    isError, text = _call(server, "vdb_list_collections")
    assert not isError and "컬렉션이 없습니다" in text


@pytest.mark.model
def test_rag_search_flow(mcp_server):
    server, web = mcp_server
    assert web.post("/api/collections", json={"name": "mcp-test", "description": "테스트용"}).status_code == 201
    assert web.post("/api/collections/mcp-test/documents", json={"documents": DOCS}).status_code == 201

    isError, text = _call(server, "vdb_list_collections")
    assert not isError and "mcp-test: 문서 3건, 모델 e5-small" in text and "테스트용" in text

    isError, text = _call(server, "vdb_search", {"collection": "mcp-test", "query": "이자율 정책", "n_results": 2})
    assert not isError
    assert text.splitlines()[0].startswith('검색 "이자율 정책" — 컬렉션 mcp-test')
    assert "[1] id=rate" in text and "title=금리 뉴스" in text and "source=news.txt" in text
    assert "기준금리를 인상했다" in text and '"category": "경제"' in text

    isError, text = _call(server, "vdb_search", {"collection": "mcp-test", "query": "동물",
                                                 "where": {"category": "과학"}, "n_results": 5})
    assert not isError and "id=space" in text and "id=pet" not in text

    isError, text = _call(server, "vdb_get_document", {"collection": "mcp-test", "doc_id": "pet"})
    assert not isError and text.startswith("id: pet") and "낮잠" in text


@pytest.mark.model
def test_errors_are_reported(mcp_server):
    server, _ = mcp_server
    isError, text = _call(server, "vdb_search", {"collection": "no-such", "query": "x"})
    assert isError and "404" in text


def test_web_server_down_message():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    server = VdbMcpServer(web_url=f"http://127.0.0.1:{port}").Build()
    isError, text = _call(server, "vdb_list_collections")
    assert isError and "not reachable" in text and "start_web.ps1" in text
