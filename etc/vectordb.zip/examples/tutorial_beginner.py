"""벡터 DB 입문 실습 — 위에서부터 한 단계씩 실행 결과를 보며 따라 하세요.

실행:  .\.venv\Scripts\python.exe examples\tutorial_beginner.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np  # noqa: E402

from vdb import get_client, get_embedding_function  # noqa: E402


def step(n, title):
    print(f"\n{'=' * 60}\n[{n}단계] {title}\n{'=' * 60}")


# ------------------------------------------------------------------
step(1, "임베딩: 문장을 숫자 목록(벡터)으로 바꾸기")
# ------------------------------------------------------------------
ef = get_embedding_function()          # 한국어 지원 모델 (multilingual-e5-small)
vec = ef(["고양이가 잠을 잔다"])[0]
print(f"문장 1개 → 숫자 {len(vec)}개짜리 벡터")
print(f"앞부분 5개: {np.round(vec[:5], 4)}")

# ------------------------------------------------------------------
step(2, "비슷한 뜻 = 가까운 벡터")
# ------------------------------------------------------------------
a, b, c = ef(["고양이가 잠을 잔다", "강아지가 낮잠을 자고 있다", "주식 시장이 폭락했다"])
print(f"'고양이…' vs '강아지…' 유사도: {np.dot(a, b):.3f}   ← 뜻이 비슷 → 높음")
print(f"'고양이…' vs '주식…'   유사도: {np.dot(a, c):.3f}   ← 뜻이 다름 → 낮음")
print("벡터 DB 는 이 '가까움'으로 검색하는 데이터베이스입니다.")

# ------------------------------------------------------------------
step(3, "DB 접속 + 컬렉션(=테이블) 만들기")
# ------------------------------------------------------------------
client = get_client()                  # 데이터는 data\chroma 폴더에 파일로 저장됨
NAME = "tutorial"
if NAME in [c.name for c in client.list_collections()]:
    client.delete_collection(NAME)     # 실습을 여러 번 돌려도 깨끗하게 시작
col = client.create_collection(
    NAME,
    embedding_function=ef,                       # 문서를 넣으면 자동으로 벡터로 변환
    configuration={"hnsw": {"space": "cosine"}},  # 거리 계산 방식: 코사인
)
print(f"컬렉션 '{col.name}' 생성. 현재 문서 수 = {col.count()}")

# ------------------------------------------------------------------
step(4, "문서 넣기 (add)")
# ------------------------------------------------------------------
col.add(
    ids=["faq-1", "faq-2", "faq-3", "faq-4", "faq-5", "faq-6"],   # 각 문서의 고유 이름(필수)
    documents=[                                                    # 실제 텍스트
        "비밀번호를 잊어버렸다면 로그인 화면의 '비밀번호 찾기'를 누르세요.",
        "배송은 결제 후 보통 2~3일이 걸립니다.",
        "환불은 상품 수령 후 7일 이내에 신청할 수 있습니다.",
        "회원 탈퇴는 마이페이지 > 설정 메뉴에서 할 수 있습니다.",
        "해외 배송은 지원하지 않습니다.",
        "포인트는 결제 금액의 1%가 적립됩니다.",
    ],
    metadatas=[                                                    # 부가 정보(필터용, 선택)
        {"category": "계정"}, {"category": "배송"}, {"category": "결제"},
        {"category": "계정"}, {"category": "배송"}, {"category": "결제"},
    ],
)
print(f"문서 수 = {col.count()}")


def show(res):
    for doc_id, doc, dist in zip(res["ids"][0], res["documents"][0], res["distances"][0]):
        print(f"  {doc_id}  거리={dist:.3f}  {doc}")


# ------------------------------------------------------------------
step(5, "의미 검색 (query) — 단어가 달라도 뜻으로 찾는다")
# ------------------------------------------------------------------
q = "암호가 기억이 안 나요"
print(f"질문: {q}   (문서에는 '암호'라는 단어가 없음)")
show(col.query(query_texts=[q], n_results=2))
print("→ 거리(distance)가 작을수록 더 비슷한 문서입니다.")

q = "물건 언제 와요?"
print(f"\n질문: {q}")
show(col.query(query_texts=[q], n_results=2))

# ------------------------------------------------------------------
step(6, "필터 검색 (where) — 메타데이터 조건 + 의미 검색")
# ------------------------------------------------------------------
q = "돈 돌려받고 싶어요"
print(f"질문: {q}   조건: category == '결제'")
show(col.query(query_texts=[q], n_results=2, where={"category": "결제"}))

# ------------------------------------------------------------------
step(7, "조회 / 수정 / 삭제")
# ------------------------------------------------------------------
print("get  :", col.get(ids=["faq-2"])["documents"])
col.update(ids=["faq-2"], documents=["배송은 결제 후 보통 1~2일이 걸립니다."])
print("update 후:", col.get(ids=["faq-2"])["documents"])
col.delete(ids=["faq-5"])
print(f"delete 후 문서 수 = {col.count()}")

# ------------------------------------------------------------------
step(8, "다시 열기 — 데이터는 파일로 남아 있다")
# ------------------------------------------------------------------
client2 = get_client()
col2 = client2.get_collection(NAME)   # 임베딩 모델 설정도 함께 복원됨
print(f"다시 연 컬렉션 문서 수 = {col2.count()}")
show(col2.query(query_texts=["탈퇴하고 싶어요"], n_results=1))

client.delete_collection(NAME)
print("\n실습 끝! (tutorial 컬렉션은 삭제했습니다)")
