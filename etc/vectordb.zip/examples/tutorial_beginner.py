"""벡터 DB 입문 실습 — 단계별 실행 결과를 보며 따라 하세요.

    실행:  .\\.venv\\Scripts\\python.exe examples\\tutorial_beginner.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

COLLECTION_NAME = "tutorial"
FAQ_IDS = ["faq-1", "faq-2", "faq-3", "faq-4", "faq-5", "faq-6"]
FAQ_DOCUMENTS = [
    "비밀번호를 잊어버렸다면 로그인 화면의 '비밀번호 찾기'를 누르세요.",
    "배송은 결제 후 보통 2~3일이 걸립니다.",
    "환불은 상품 수령 후 7일 이내에 신청할 수 있습니다.",
    "회원 탈퇴는 마이페이지 > 설정 메뉴에서 할 수 있습니다.",
    "해외 배송은 지원하지 않습니다.",
    "포인트는 결제 금액의 1%가 적립됩니다.",
]
FAQ_METADATAS = [
    {"category": "계정"}, {"category": "배송"}, {"category": "결제"},
    {"category": "계정"}, {"category": "배송"}, {"category": "결제"},
]


class TutorialPrinter:
    """실습 출력용 정적 유틸."""

    @staticmethod
    def PrintStep(step_no: int, title: str):
        print(f"\n{'=' * 60}\n[{step_no}단계] {title}\n{'=' * 60}")


def main():
    import numpy as np

    from vdb.Defines.VdbDefine import VdbDefine
    from vdb.Factory.EmbeddingFunctionFactory import EmbeddingFunctionFactory
    from vdb.Factory.VdbClientFactory import VdbClientFactory
    from vdb.Utils.QueryResultHelper import QueryResultHelper

    # 1) 임베딩: 문장을 숫자 목록(벡터)으로 바꾸기
    TutorialPrinter.PrintStep(step_no=1, title="임베딩: 문장을 숫자 목록(벡터)으로 바꾸기")
    embeddingFunction = EmbeddingFunctionFactory.CreateEmbeddingFunction()  # 한국어 지원 모델 (multilingual-e5-small)
    vector = embeddingFunction(["고양이가 잠을 잔다"])[0]
    print(f"문장 1개 → 숫자 {len(vector)}개짜리 벡터")
    print(f"앞부분 5개: {np.round(vector[:5], 4)}")

    # 2) 비슷한 뜻 = 가까운 벡터
    TutorialPrinter.PrintStep(step_no=2, title="비슷한 뜻 = 가까운 벡터")
    catVector, dogVector, stockVector = embeddingFunction(
        ["고양이가 잠을 잔다", "강아지가 낮잠을 자고 있다", "주식 시장이 폭락했다"])
    print(f"'고양이…' vs '강아지…' 유사도: {np.dot(catVector, dogVector):.3f}   ← 뜻이 비슷 → 높음")
    print(f"'고양이…' vs '주식…'   유사도: {np.dot(catVector, stockVector):.3f}   ← 뜻이 다름 → 낮음")
    print("벡터 DB 는 이 '가까움'으로 검색하는 데이터베이스입니다.")

    # 3) DB 접속 + 컬렉션(=테이블) 만들기
    TutorialPrinter.PrintStep(step_no=3, title="DB 접속 + 컬렉션(=테이블) 만들기")
    client = VdbClientFactory.CreateClient()  # 데이터는 data\chroma 폴더에 파일로 저장됨
    if COLLECTION_NAME in [c.name for c in client.list_collections()]:
        client.delete_collection(COLLECTION_NAME)  # 실습을 여러 번 돌려도 깨끗하게 시작
    collection = client.create_collection(
        COLLECTION_NAME,
        embedding_function=embeddingFunction,                              # 문서를 넣으면 자동으로 벡터로 변환
        configuration={"hnsw": {"space": VdbDefine.E_SPACE.COSINE}},       # 거리 계산 방식: 코사인
    )
    print(f"컬렉션 '{collection.name}' 생성. 현재 문서 수 = {collection.count()}")

    # 4) 문서 넣기 (add)
    TutorialPrinter.PrintStep(step_no=4, title="문서 넣기 (add)")
    collection.add(
        ids=FAQ_IDS,              # 각 문서의 고유 이름(필수)
        documents=FAQ_DOCUMENTS,  # 실제 텍스트
        metadatas=FAQ_METADATAS,  # 부가 정보(필터용, 선택)
    )
    print(f"문서 수 = {collection.count()}")

    # 5) 의미 검색 (query) — 단어가 달라도 뜻으로 찾는다
    TutorialPrinter.PrintStep(step_no=5, title="의미 검색 (query) — 단어가 달라도 뜻으로 찾는다")
    query = "암호가 기억이 안 나요"
    print(f"질문: {query}   (문서에는 '암호'라는 단어가 없음)")
    QueryResultHelper.PrintQueryResult(collection.query(query_texts=[query], n_results=2))
    print("→ 거리(distance)가 작을수록 더 비슷한 문서입니다.")

    query = "물건 언제 와요?"
    print(f"\n질문: {query}")
    QueryResultHelper.PrintQueryResult(collection.query(query_texts=[query], n_results=2))

    # 6) 필터 검색 (where) — 메타데이터 조건 + 의미 검색
    TutorialPrinter.PrintStep(step_no=6, title="필터 검색 (where) — 메타데이터 조건 + 의미 검색")
    query = "돈 돌려받고 싶어요"
    print(f"질문: {query}   조건: category == '결제'")
    QueryResultHelper.PrintQueryResult(
        collection.query(query_texts=[query], n_results=2, where={"category": "결제"}))

    # 7) 조회 / 수정 / 삭제
    TutorialPrinter.PrintStep(step_no=7, title="조회 / 수정 / 삭제")
    print("get  :", collection.get(ids=["faq-2"])["documents"])
    collection.update(ids=["faq-2"], documents=["배송은 결제 후 보통 1~2일이 걸립니다."])
    print("update 후:", collection.get(ids=["faq-2"])["documents"])
    collection.delete(ids=["faq-5"])
    print(f"delete 후 문서 수 = {collection.count()}")

    # 8) 다시 열기 — 데이터는 파일로 남아 있다
    TutorialPrinter.PrintStep(step_no=8, title="다시 열기 — 데이터는 파일로 남아 있다")
    reopenedClient = VdbClientFactory.CreateClient()
    reopened = reopenedClient.get_collection(COLLECTION_NAME)  # 임베딩 모델 설정도 함께 복원됨
    print(f"다시 연 컬렉션 문서 수 = {reopened.count()}")
    QueryResultHelper.PrintQueryResult(reopened.query(query_texts=["탈퇴하고 싶어요"], n_results=1))

    client.delete_collection(COLLECTION_NAME)
    print("\n실습 끝! (tutorial 컬렉션은 삭제했습니다)")


if __name__ == "__main__":
    main()
