"""한국어 의미 검색 예제 (multilingual-e5-small, ONNX, CPU).

    임베디드:  python examples/korean_search.py
    서버 모드: $env:VDB_MODE="http"; python examples/korean_search.py
    모델 변경: $env:VDB_EMBED="bge-m3"   (1024차원, 약 2.2GB 다운로드)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

COLLECTION_NAME = "korean-demo"
DOCS = {
    "pet": ("고양이가 소파 위에서 낮잠을 자고 있다.", {"cat": "생활"}),
    "rate": ("한국은행이 물가 상승을 억제하기 위해 기준금리를 인상했다.", {"cat": "경제"}),
    "space": ("누리호가 인공위성을 지구 저궤도에 올려놓았다.", {"cat": "과학"}),
    "food": ("김치찌개는 돼지고기와 묵은지를 넣고 끓인다.", {"cat": "생활"}),
    "vdb": ("벡터 데이터베이스는 임베딩 간 유사도로 문서를 검색한다.", {"cat": "IT"}),
}
QUERIES = ["반려동물이 자는 모습", "이자율 정책", "로켓 발사 성공", "저녁 메뉴 추천", "semantic search engine"]


def main():
    from vdb.Defines.VdbDefine import VdbDefine
    from vdb.Factory.EmbeddingFunctionFactory import EmbeddingFunctionFactory
    from vdb.Factory.VdbClientFactory import VdbClientFactory
    from vdb.Utils.QueryResultHelper import QueryResultHelper

    client = VdbClientFactory.CreateClient()
    embeddingFunction = EmbeddingFunctionFactory.CreateEmbeddingFunction()

    ## 컬렉션 초기화 + 적재
    if COLLECTION_NAME in [c.name for c in client.list_collections()]:
        client.delete_collection(COLLECTION_NAME)
    collection = client.create_collection(
        COLLECTION_NAME, embedding_function=embeddingFunction,
        configuration={"hnsw": {"space": VdbDefine.E_SPACE.COSINE}})
    collection.add(ids=list(DOCS), documents=[d for d, _ in DOCS.values()],
                   metadatas=[m for _, m in DOCS.values()])

    ## 배치 의미 검색
    result = collection.query(query_texts=QUERIES, n_results=2)
    for queryIndex, query in enumerate(QUERIES):
        print(f"\n질의: {query}")
        QueryResultHelper.PrintQueryResult(result, query_index=queryIndex)

    ## 메타데이터 필터 + 의미 검색
    result = collection.query(query_texts=["먹을 것"], n_results=2, where={"cat": "생활"})
    print(f"\n필터(cat=생활) + '먹을 것' -> {result['ids'][0]}")

    ## 재오픈 — 컬렉션에 임베딩 함수 설정이 저장되어 있어 embedding_function 을 넘기지 않아도 된다
    reopened = client.get_collection(COLLECTION_NAME)
    print(f"재오픈 후 질의 -> {reopened.query(query_texts=['우주 개발'], n_results=1)['ids'][0]}")

    client.delete_collection(COLLECTION_NAME)


if __name__ == "__main__":
    main()
