"""Chroma 퀵스타트: 텍스트 적재 → 의미 검색 → 메타데이터 필터 → 수정/삭제.

임베디드 모드(기본):  python examples/quickstart.py
서버 모드:            $env:VDB_MODE="http"; python examples/quickstart.py   (scripts/start_server.ps1 먼저 실행)
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from vdb import get_client, load_settings  # noqa: E402

DOCS = [
    ("doc-1", "Chroma is an open-source embedding database.", {"topic": "db", "year": 2023}),
    ("doc-2", "HNSW is a graph-based approximate nearest neighbor algorithm.", {"topic": "algorithm", "year": 2016}),
    ("doc-3", "Cosine similarity measures the angle between two vectors.", {"topic": "math", "year": 2010}),
    ("doc-4", "Retrieval augmented generation combines search with LLMs.", {"topic": "rag", "year": 2020}),
    ("doc-5", "Python is a popular language for data science.", {"topic": "lang", "year": 2015}),
]


def show(title, res):
    print(f"\n== {title}")
    for i, d, dist in zip(res["ids"][0], res["documents"][0], res["distances"][0]):
        print(f"  {i}  dist={dist:.4f}  {d}")


def main():
    s = load_settings()
    print(f"[mode] {s.mode}  ({s.data_dir if s.mode == 'embedded' else f'{s.host}:{s.port}'})")
    client = get_client(s)

    # 기본 임베딩 함수(all-MiniLM-L6-v2, ONNX, CPU) 사용 — 텍스트만 넣으면 자동 임베딩
    col = client.get_or_create_collection("quickstart", configuration={"hnsw": {"space": "cosine"}})
    col.upsert(ids=[d[0] for d in DOCS], documents=[d[1] for d in DOCS], metadatas=[d[2] for d in DOCS])
    print(f"[count] {col.count()}")

    show("의미 검색: 'vector search graph index'",
         col.query(query_texts=["vector search graph index"], n_results=3))

    show("필터 검색: year >= 2018",
         col.query(query_texts=["database for AI apps"], n_results=3, where={"year": {"$gte": 2018}}))

    show("문서 내용 필터: contains 'vectors'",
         col.query(query_texts=["math"], n_results=3, where_document={"$contains": "vectors"}))

    col.update(ids=["doc-5"], metadatas=[{"topic": "lang", "year": 2024}])
    col.delete(ids=["doc-3"])
    print(f"\n[after update/delete] count={col.count()} doc-5={col.get(ids=['doc-5'])['metadatas'][0]}")

    client.delete_collection("quickstart")
    print("[cleanup] collection 'quickstart' deleted")


if __name__ == "__main__":
    main()
