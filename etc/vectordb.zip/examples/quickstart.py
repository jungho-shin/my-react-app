"""Chroma 퀵스타트: 텍스트 적재 → 의미 검색 → 메타데이터 필터 → 수정/삭제.

    임베디드 모드(기본):  python examples/quickstart.py
    서버 모드:            $env:VDB_MODE="http"; python examples/quickstart.py   (scripts/start_server.ps1 먼저 실행)

기본 임베딩 함수(all-MiniLM-L6-v2, ONNX, CPU, 영어 전용)를 사용한다.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

COLLECTION_NAME = "quickstart"
DOCS = [
    ("doc-1", "Chroma is an open-source embedding database.", {"topic": "db", "year": 2023}),
    ("doc-2", "HNSW is a graph-based approximate nearest neighbor algorithm.", {"topic": "algorithm", "year": 2016}),
    ("doc-3", "Cosine similarity measures the angle between two vectors.", {"topic": "math", "year": 2010}),
    ("doc-4", "Retrieval augmented generation combines search with LLMs.", {"topic": "rag", "year": 2020}),
    ("doc-5", "Python is a popular language for data science.", {"topic": "lang", "year": 2015}),
]


def main():
    from vdb.Config.VdbConfigHelper import VdbConfigHelper
    from vdb.Defines.VdbDefine import VdbDefine
    from vdb.Factory.VdbClientFactory import VdbClientFactory
    from vdb.Utils.QueryResultHelper import QueryResultHelper

    settings = VdbConfigHelper.LoadSettings()
    print(f"[mode] {settings.GetMode()}  ({settings.GetTarget()})")
    client = VdbClientFactory.CreateClient(settings)

    ## 컬렉션 생성 + 적재 (텍스트만 넣으면 기본 임베딩 함수가 자동 임베딩)
    collection = client.get_or_create_collection(
        COLLECTION_NAME, configuration={"hnsw": {"space": VdbDefine.E_SPACE.COSINE}})
    collection.upsert(ids=[d[0] for d in DOCS], documents=[d[1] for d in DOCS], metadatas=[d[2] for d in DOCS])
    print(f"[count] {collection.count()}")

    ## 의미 검색
    print("\n== 의미 검색: 'vector search graph index'")
    QueryResultHelper.PrintQueryResult(
        collection.query(query_texts=["vector search graph index"], n_results=3))

    ## 메타데이터 필터 검색
    print("\n== 필터 검색: year >= 2018")
    QueryResultHelper.PrintQueryResult(
        collection.query(query_texts=["database for AI apps"], n_results=3, where={"year": {"$gte": 2018}}))

    ## 문서 내용 필터 검색
    print("\n== 문서 내용 필터: contains 'vectors'")
    QueryResultHelper.PrintQueryResult(
        collection.query(query_texts=["math"], n_results=3, where_document={"$contains": "vectors"}))

    ## 수정 / 삭제
    collection.update(ids=["doc-5"], metadatas=[{"topic": "lang", "year": 2024}])
    collection.delete(ids=["doc-3"])
    doc5Metadata = collection.get(ids=["doc-5"])["metadatas"][0]
    print(f"\n[after update/delete] count={collection.count()} doc-5={doc5Metadata}")

    client.delete_collection(COLLECTION_NAME)
    print(f"[cleanup] collection '{COLLECTION_NAME}' deleted")


if __name__ == "__main__":
    main()
